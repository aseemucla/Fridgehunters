import { withRouter } from 'next/router'
import Layout from '../components/MyLayout.js'
import fetchh from 'isomorphic-unfetch'
import urlname from '../components/urlname.js'

class RecipeList extends React.Component{

  constructor(props){
    super(props);
    this.addEndorsement = this.addEndorsement.bind(this);

    var listtext = this.props.listtext;
    this.state = {
      recipes: []
    }

    fetch(urlname + "/?desiredMethod=FIND&ulist=" + this.props.listtext).then(response => response.text()).then(datas => {
      var data = JSON.parse("[" + datas  + "]")
      console.log("Show data fetched. Count: " + JSON.stringify(data))
      this.setState({
        recipes: data
      })
    })
  }

  addEndorsement(event){

  }

  render(){
    return (
      <div>
      {
        this.state.recipes.map(recipe => ( <div key={recipe.name}>
          <h1>{recipe.name}</h1>
          <h2>{recipe.ingredients}</h2>
          <h3>{recipe.description}</h3>
          <h4>{recipe.endorse}</h4>
          <button key2={recipe.name} onClick={this.addEndorsement}>Add endorsement!</button>
          </div>)
        )
      }
      </div>
    )
  }
}

const First =  (props) => (
  <Layout>
    <RecipeList listtext={props.listtext} />
  </Layout>
)

First.getInitialProps = async function (context) {
  const listtext = context.query.ingredlist
  console.log(listtext)
  return {listtext: listtext}
}

export default First