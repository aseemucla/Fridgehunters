import Layout from '../components/MyLayout.js'
import Link from 'next/link'


//var mysql = require('mysql');


class Dropdown extends React.Component{
	constructor(props){
	  super(props)
	  this.state = {
	    listOpen: false,
	    headerTitle: this.props.title
	  }
	}

	handleClickOutside(){
	  this.setState({
	    listOpen: false
	  })
	}

	toggleList(){
	  this.setState(prevState => ({
	    listOpen: !prevState.listOpen
	  }))
	}

	render(){
		return(
			<div className="dd-wrapper">
		    <div className="dd-header" onClick={() => this.toggleList()}>
		        <div className="dd-header-title">{this.state.headerTitle}</div>
		        {this.state.listOpen
		          ? <FontAwesome name="angle-up" size="2x"/>
		          : <FontAwesome name="angle-down" size="2x"/>
		        }
		    </div>
		    </div>
		);
	}
}

/*var con = mysql.createConnection({
  host: "localhost",
  user: "yourusername",
  password: "yourpassword"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
});*/

class Main extends React.Component{
	constructor(props) {
	    super(props);
	    this.state = {

	    };
 	}

 	render() {
 		return (
	    	<div classname="main" />
	    );
	}
}


const Index = () => (
  <Layout>
  	<Dropdown/>
  </Layout>
)

export default Index