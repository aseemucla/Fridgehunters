webpackHotUpdate(6,{

/***/ "./components/Header.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style__ = __webpack_require__("./node_modules/styled-jsx/style.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__("./node_modules/react/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_next_link__ = __webpack_require__("./node_modules/next/link.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_next_link___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_next_link__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__material_ui_core_AppBar__ = __webpack_require__("./node_modules/@material-ui/core/AppBar/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__material_ui_core_AppBar___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3__material_ui_core_AppBar__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__material_ui_core_Toolbar__ = __webpack_require__("./node_modules/@material-ui/core/Toolbar/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__material_ui_core_Toolbar___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4__material_ui_core_Toolbar__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__material_ui_core_Button__ = __webpack_require__("./node_modules/@material-ui/core/Button/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__material_ui_core_Button___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5__material_ui_core_Button__);
var _jsxFileName = "C:\\Users\\Aseem\\React Projects\\Fridgehunters\\components\\Header.js";





 //import "typeface-lobster";

var linkStyle = {
  marginRight: 15,
  border: '2px solid #DDD'
};

var Header = function Header() {
  return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 14
    },
    className: "jsx-187386659"
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("h1", {
    align: "center",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 15
    },
    className: "jsx-187386659"
  }, "Fridgehunters"), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a, {
    styleId: "187386659",
    css: "@import url('https://fonts.googleapis.com/css?family=Lobster');@fontface{font-family:'Lobster',cursive;src:url('https://fonts.googleapis.com/css?family=Lobster');}h1.jsx-187386659{font-family:\"Lobster\",Times,serif;font-size:54px;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbXBvbmVudHNcXEhlYWRlci5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFjc0QsQUFFdUUsQUFHN0IsQUFLSyw4QkFIdkMsSUFLQSxlQUFDLHdDQUxBIiwiZmlsZSI6ImNvbXBvbmVudHNcXEhlYWRlci5qcyIsInNvdXJjZVJvb3QiOiJDOlxcVXNlcnNcXEFzZWVtXFxSZWFjdCBQcm9qZWN0c1xcRnJpZGdlaHVudGVycyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluaydcclxuaW1wb3J0IEFwcEJhciBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9BcHBCYXInO1xyXG5pbXBvcnQgVG9vbGJhciBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9Ub29sYmFyJztcclxuaW1wb3J0IEJ1dHRvbiBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9CdXR0b24nO1xyXG4vL2ltcG9ydCBcInR5cGVmYWNlLWxvYnN0ZXJcIjtcclxuXHJcbmNvbnN0IGxpbmtTdHlsZSA9IHtcclxuICBtYXJnaW5SaWdodDogMTUsXHJcbiAgYm9yZGVyOiAnMnB4IHNvbGlkICNEREQnXHJcbn1cclxuXHJcbmNvbnN0IEhlYWRlciA9ICgpID0+IHtcclxuICAgIHJldHVybihcclxuICAgIDxkaXY+XHJcbiAgICBcdDxoMSBhbGlnbj1cImNlbnRlclwiPkZyaWRnZWh1bnRlcnM8L2gxPjxzdHlsZSBqc3g+e2BcclxuICAgICAgICBAaW1wb3J0IHVybCgnaHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbS9jc3M/ZmFtaWx5PUxvYnN0ZXInKTtcclxuXHJcbiAgICAgICAgQGZvbnRmYWNlIHtcclxuICAgICAgICAgIGZvbnQtZmFtaWx5OiAnTG9ic3RlcicsIGN1cnNpdmU7XHJcbiAgICAgICAgICBzcmM6IHVybCgnaHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbS9jc3M/ZmFtaWx5PUxvYnN0ZXInKVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaDEge1xyXG4gICAgICAgICAgZm9udC1mYW1pbHk6IFwiTG9ic3RlclwiLCBUaW1lcywgc2VyaWY7XHJcbiAgICAgICAgICBmb250LXNpemU6IDU0cHhcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgIGB9PC9zdHlsZT5cclxuICAgICAgPEFwcEJhciBwb3NpdGlvbj1cInN0YXRpY1wiPlxyXG4gICAgICAgIDxUb29sYmFyICBzdHlsZT17e2p1c3RpZnlDb250ZW50OiAnY2VudGVyJ319PlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8TGluayBocmVmPVwiL2hvdFwiPlxyXG4gICAgICAgICAgICA8QnV0dG9uIHN0eWxlPXt7IGZvbnRXZWlnaHQ6IFwiYm9sZFwiLCBmb250U2l6ZTogXCIxNnB4XCIgIH19PkhPVDwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG5cclxuICAgICAgICAgIDxMaW5rIGhyZWY9XCIvXCI+XHJcbiAgICAgICAgICAgIDxCdXR0b24gc3R5bGU9e3sgZm9udFdlaWdodDogXCJib2xkXCIsIGZvbnRTaXplOiBcIjE2cHhcIiAgfX0+SE9NRTwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG5cclxuICAgICAgICAgIDxMaW5rIGhyZWY9XCIvY3JlYXRlXCI+XHJcbiAgICAgICAgICAgIDxCdXR0b24gc3R5bGU9e3sgZm9udFdlaWdodDogXCJib2xkXCIsIGZvbnRTaXplOiBcIjE2cHhcIiB9fT5DUkVBVEU8L0J1dHRvbj5cclxuICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvVG9vbGJhcj5cclxuICAgICAgPC9BcHBCYXI+XHJcbiAgICAgICAgXHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEhlYWRlciJdfQ== */\n/*@ sourceURL=components\\Header.js */"
  }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__material_ui_core_AppBar___default.a, {
    position: "static",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    }
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__material_ui_core_Toolbar___default.a, {
    style: {
      justifyContent: 'center'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 30
    }
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31
    },
    className: "jsx-187386659"
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_next_link___default.a, {
    href: "/hot",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 32
    }
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__material_ui_core_Button___default.a, {
    style: {
      fontWeight: "bold",
      fontSize: "16px"
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 33
    }
  }, "HOT")), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_next_link___default.a, {
    href: "/",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 36
    }
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__material_ui_core_Button___default.a, {
    style: {
      fontWeight: "bold",
      fontSize: "16px"
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 37
    }
  }, "HOME")), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_next_link___default.a, {
    href: "/create",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 40
    }
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__material_ui_core_Button___default.a, {
    style: {
      fontWeight: "bold",
      fontSize: "16px"
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    }
  }, "CREATE"))))));
};

/* harmony default export */ __webpack_exports__["a"] = (Header);

/***/ }),

/***/ "./node_modules/@material-ui/core/Button/index.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__("./node_modules/@babel/runtime/helpers/builtin/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function get() {
    return _Button.default;
  }
});

var _Button = _interopRequireDefault(__webpack_require__("./node_modules/@material-ui/core/Button/Button.js"));

/***/ }),

/***/ "./pages/create.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style__ = __webpack_require__("./node_modules/styled-jsx/style.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__("./node_modules/react/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_next_router__ = __webpack_require__("./node_modules/next/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_next_router___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_next_router__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__components_MyLayout_js__ = __webpack_require__("./components/MyLayout.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_isomorphic_unfetch__ = __webpack_require__("./node_modules/isomorphic-unfetch/browser.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_isomorphic_unfetch___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_isomorphic_unfetch__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_next_link__ = __webpack_require__("./node_modules/next/link.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_next_link___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_next_link__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__components_urlname_js__ = __webpack_require__("./components/urlname.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__material_ui_core_Button__ = __webpack_require__("./node_modules/@material-ui/core/Button/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__material_ui_core_Button___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7__material_ui_core_Button__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__material_ui_core_TextField__ = __webpack_require__("./node_modules/@material-ui/core/TextField/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__material_ui_core_TextField___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_8__material_ui_core_TextField__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__material_ui_core_List__ = __webpack_require__("./node_modules/@material-ui/core/List/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__material_ui_core_List___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_9__material_ui_core_List__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__material_ui_core_ListItem__ = __webpack_require__("./node_modules/@material-ui/core/ListItem/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__material_ui_core_ListItem___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_10__material_ui_core_ListItem__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__material_ui_core_ListItemText__ = __webpack_require__("./node_modules/@material-ui/core/ListItemText/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__material_ui_core_ListItemText___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_11__material_ui_core_ListItemText__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__material_ui_core_Divider__ = __webpack_require__("./node_modules/@material-ui/core/Divider/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__material_ui_core_Divider___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_12__material_ui_core_Divider__);
var _jsxFileName = "C:\\Users\\Aseem\\React Projects\\Fridgehunters\\pages\\create.js";



function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }













var Listing =
/*#__PURE__*/
function (_React$Component) {
  _inherits(Listing, _React$Component);

  function Listing(props) {
    var _this;

    _classCallCheck(this, Listing);

    _this = _possibleConstructorReturn(this, (Listing.__proto__ || Object.getPrototypeOf(Listing)).call(this, props));
    console.log(_this.props.textValue);
    _this.state = {
      list: []
    };
    return _this;
  }

  _createClass(Listing, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var _this2 = this;

      __WEBPACK_IMPORTED_MODULE_4_isomorphic_unfetch___default()(__WEBPACK_IMPORTED_MODULE_6__components_urlname_js__["a" /* default */] + "/?desiredMethod=SUGGEST&uname=" + this.props.textValue).then(function (response) {
        return response.text();
      }).then(function (data) {
        console.log("Show data fetched. Count: " + data);
        var datalist = data.split(",");

        if (data == "") {
          _this2.setState({
            list: []
          });
        } else {
          _this2.setState({
            list: datalist
          });
        }
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        align: "center",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 47
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__material_ui_core_List___default.a, {
        component: "nav",
        style: {
          width: 250
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 48
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_12__material_ui_core_Divider___default.a, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 48
        }
      }), this.state.list.map(function (ingred) {
        return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
          key: ingred,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 49
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_10__material_ui_core_ListItem___default.a, {
          button: true,
          onClick: _this3.props.onClicker,
          customtext: ingred,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 50
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_11__material_ui_core_ListItemText___default.a, {
          primary: ingred,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 51
          }
        })), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_12__material_ui_core_Divider___default.a, {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 53
          }
        }));
      })));
    }
  }]);

  return Listing;
}(__WEBPACK_IMPORTED_MODULE_1_react___default.a.Component);

var Creator =
/*#__PURE__*/
function (_React$Component2) {
  _inherits(Creator, _React$Component2);

  function Creator(props) {
    var _this4;

    _classCallCheck(this, Creator);

    _this4 = _possibleConstructorReturn(this, (Creator.__proto__ || Object.getPrototypeOf(Creator)).call(this, props));
    _this4.state = {
      listOpen: false,
      textValue: "",
      ingredtextlist: [],
      name: "",
      description: "",
      buttonInfo: "Add recipe!",
      errorInfo: ""
    };
    _this4.showMenu = _this4.showMenu.bind(_assertThisInitialized(_this4));
    _this4.closeMenu = _this4.closeMenu.bind(_assertThisInitialized(_this4));
    _this4.RemoveIngred = _this4.RemoveIngred.bind(_assertThisInitialized(_this4));
    _this4.addIngredient = _this4.addIngredient.bind(_assertThisInitialized(_this4));
    _this4.changeName = _this4.changeName.bind(_assertThisInitialized(_this4));
    _this4.changeDescription = _this4.changeDescription.bind(_assertThisInitialized(_this4));
    _this4.createRecipe = _this4.createRecipe.bind(_assertThisInitialized(_this4));
    return _this4;
  }

  _createClass(Creator, [{
    key: "showMenu",
    value: function showMenu(event) {
      var _this5 = this;

      this.setState({
        buttonInfo: "Add recipe!",
        errorInfo: ""
      });

      if (this.state.listOpen) {
        this.setState({
          listOpen: false
        }, function () {
          document.removeEventListener('click', _this5.closeMenu);
        });
      } else {
        this.setState({
          textValue: event.target.value,
          listOpen: true
        }, function () {
          document.addEventListener('click', _this5.closeMenu);
        });
      }
    }
  }, {
    key: "RemoveIngred",
    value: function RemoveIngred(event) {
      var index = +this.state.ingredtextlist.indexOf(event.target.getAttribute('key2'));
      var changedArray = this.state.ingredtextlist.slice();
      changedArray.splice(index, 1);
      this.setState(function (prevState, props) {
        return {
          ingredtextlist: changedArray
        };
      });
    }
  }, {
    key: "addIngredient",
    value: function addIngredient(event) {
      var _this6 = this;

      event.persist();
      var custom = event.currentTarget.getAttribute('customtext');
      var tmparr = this.state.ingredtextlist.slice().concat([custom]);

      if (event.currentTarget.id == "addButton") {
        if (this.state.ingredtextlist.findIndex(function (ing) {
          return ing == _this6.state.textValue;
        }) == -1) {
          //this.setState((prevState, props) => {return {ingredlist: prevState.ingredlist.concat([(
          //<h1 onClick={this.RemoveIngred} key={this.state.textValue}>{this.state.textValue}</h1>
          //)])}})
          tmparr = this.state.ingredtextlist.slice().concat([this.state.textValue]);
          console.log(this.state.textValue + "UTUT");
          this.setState(function (prevState, props) {
            return {
              ingredtextlist: tmparr
            };
          });
        }
      } else {
        this.setState({
          listOpen: false
        }, function () {
          document.removeEventListener('click', _this6.closeMenu);
        }); //if(this.state.ingredlist.findIndex(ing => ing.key == event.target.getAttribute('customtext')) == -1){

        if (this.state.ingredtextlist.findIndex(function (ing) {
          return ing == custom;
        }) == -1) {
          //this.setState((prevState, props) => {return {ingredlist: prevState.ingredlist.concat([(
          //<h1 onClick={this.RemoveIngred} key={event.target.getAttribute('customtext')}>{event.target.getAttribute('customtext')}</h1>
          //)])}})
          this.setState(function (prevState, props) {
            return {
              ingredtextlist: tmparr
            };
          });
        }
      }
    }
  }, {
    key: "closeMenu",
    value: function closeMenu(event) {
      var _this7 = this;

      if (!this.dropdownMenu.contains(event.target)) {
        this.setState({
          listOpen: false
        }, function () {
          document.removeEventListener('click', _this7.closeMenu);
        });
      }
    }
  }, {
    key: "changeName",
    value: function changeName(event) {
      this.setState({
        buttonInfo: "Add recipe!",
        errorInfo: ""
      });
      this.setState({
        name: event.currentTarget.value
      });
    }
  }, {
    key: "changeDescription",
    value: function changeDescription(event) {
      this.setState({
        buttonInfo: "Add recipe!",
        errorInfo: ""
      });
      this.setState({
        description: event.currentTarget.value
      });
    }
  }, {
    key: "createRecipe",
    value: function createRecipe() {
      var _this8 = this;

      if (this.state.name == "" || this.state.description == "" || this.state.ingredtextlist == []) {
        this.setState({
          errorInfo: "One or more fields is left blank. Try again."
        });
        return;
      }

      __WEBPACK_IMPORTED_MODULE_4_isomorphic_unfetch___default()(__WEBPACK_IMPORTED_MODULE_6__components_urlname_js__["a" /* default */] + "/?desiredMethod=ADDRECIPE&uname=" + this.state.name + "&ulist=" + this.state.ingredtextlist.toString() + "&udesc=" + this.state.description).then(function (response) {
        return response.text();
      }).then(function (data) {
        if (data == "Recipe exists") {
          _this8.setState({
            errorInfo: "Recipe name exists. Try again."
          });
        } else {
          console.log("Added recipe " + data);

          _this8.setState({
            buttonInfo: "Recipe added!"
          });
        }
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this9 = this;

      return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 207
        },
        className: "jsx-3083821483"
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        align: "center",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 208
        },
        className: "jsx-3083821483"
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("form", {
        name: "nameForm",
        onSubmit: function onSubmit(event) {
          return _this9.showMenu(event);
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 209
        },
        className: "jsx-3083821483"
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("label", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 210
        },
        className: "jsx-3083821483"
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("h3", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 211
        },
        className: "jsx-3083821483"
      }, "Recipe name"), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__material_ui_core_TextField___default.a, {
        onKeyPress: function onKeyPress(e) {
          if (e.key === 'Enter') e.preventDefault();
        },
        onChange: function onChange(event) {
          return _this9.changeName(event);
        },
        margin: "normal",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 212
        }
      }))), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 216
        },
        className: "jsx-3083821483"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 216
        },
        className: "jsx-3083821483"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("form", {
        name: "addForm",
        onSubmit: function onSubmit(event) {
          return _this9.showMenu(event);
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 218
        },
        className: "jsx-3083821483"
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("label", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 219
        },
        className: "jsx-3083821483"
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("h3", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 220
        },
        className: "jsx-3083821483"
      }, "Add ingredients"), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__material_ui_core_TextField___default.a, {
        onKeyPress: function onKeyPress(e) {
          if (e.key === 'Enter') e.preventDefault();
        },
        onChange: function onChange(event) {
          return _this9.showMenu(event);
        },
        margin: "normal",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 221
        }
      }))), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__material_ui_core_Button___default.a, {
        variant: "contained",
        color: "secondary",
        onClick: this.addIngredient,
        id: "addButton",
        style: {
          fontFamily: "Gentium Book Basic",
          fontWeight: "bold",
          fontSize: '16px'
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 226
        }
      }, "Pick ingredient"), this.state.listOpen ? __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        ref: function ref(element) {
          _this9.dropdownMenu = element;
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 231
        },
        className: "jsx-3083821483" + " " + "menu"
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(Listing, {
        textValue: this.state.textValue,
        onClicker: this.addIngredient,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 234
        }
      })) : __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 238
        },
        className: "jsx-3083821483"
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 238
        },
        className: "jsx-3083821483"
      })), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        "class": "inline",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 244
        },
        className: "jsx-3083821483"
      }, this.state.ingredtextlist.map(function (ingred) {
        return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__material_ui_core_Button___default.a, {
          variant: "outlined",
          onClick: _this9.RemoveIngred,
          key: ingred,
          key2: ingred,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 247
          }
        }, ingred);
      })), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 251
        },
        className: "jsx-3083821483"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 251
        },
        className: "jsx-3083821483"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 251
        },
        className: "jsx-3083821483"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("h3", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 254
        },
        className: "jsx-3083821483"
      }, "Enter recipe"), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__material_ui_core_TextField___default.a, {
        style: {
          width: 300
        },
        multiline: true,
        rows: 5,
        onChange: function onChange(event) {
          return _this9.changeDescription(event);
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 255
        }
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 257
        },
        className: "jsx-3083821483"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 257
        },
        className: "jsx-3083821483"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 257
        },
        className: "jsx-3083821483"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("h4", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 258
        },
        className: "jsx-3083821483"
      }, this.state.errorInfo), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__material_ui_core_Button___default.a, {
        variant: "contained",
        style: {
          fontFamily: "Montserrat",
          fontWeight: "bold",
          fontSize: '20px'
        },
        color: "primary",
        onClick: this.createRecipe,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 260
        }
      }, this.state.buttonInfo)), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a, {
        styleId: "3083821483",
        css: "h3.jsx-3083821483{font-family:\"Gentium Book Basic\",Times,serif;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBhZ2VzXFxjcmVhdGUuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBcVF3QixBQUswRCw2Q0FDakQiLCJmaWxlIjoicGFnZXNcXGNyZWF0ZS5qcyIsInNvdXJjZVJvb3QiOiJDOlxcVXNlcnNcXEFzZWVtXFxSZWFjdCBQcm9qZWN0c1xcRnJpZGdlaHVudGVycyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHdpdGhSb3V0ZXIgfSBmcm9tICduZXh0L3JvdXRlcidcclxuaW1wb3J0IExheW91dCBmcm9tICcuLi9jb21wb25lbnRzL015TGF5b3V0LmpzJ1xyXG5pbXBvcnQgZmV0Y2ggZnJvbSAnaXNvbW9ycGhpYy11bmZldGNoJ1xyXG5pbXBvcnQgTGluayBmcm9tICduZXh0L2xpbmsnXHJcbmltcG9ydCB1cmxuYW1lIGZyb20gJy4uL2NvbXBvbmVudHMvdXJsbmFtZS5qcydcclxuaW1wb3J0IEJ1dHRvbiBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9CdXR0b24nO1xyXG5pbXBvcnQgVGV4dEZpZWxkIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL1RleHRGaWVsZCc7XHJcbmltcG9ydCBMaXN0IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0xpc3QnO1xyXG5pbXBvcnQgTGlzdEl0ZW0gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvTGlzdEl0ZW0nO1xyXG5pbXBvcnQgTGlzdEl0ZW1UZXh0IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0xpc3RJdGVtVGV4dCc7XHJcbmltcG9ydCBEaXZpZGVyIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0RpdmlkZXInO1xyXG5cclxuXHJcbmNsYXNzIExpc3RpbmcgZXh0ZW5kcyBSZWFjdC5Db21wb25lbnR7XHJcbiAgY29uc3RydWN0b3IocHJvcHMpe1xyXG4gICAgICBzdXBlcihwcm9wcylcclxuICAgICAgY29uc29sZS5sb2codGhpcy5wcm9wcy50ZXh0VmFsdWUpXHJcbiAgICAgIHRoaXMuc3RhdGUgPSB7XHJcbiAgICAgICAgbGlzdDogW10sXHJcbiAgICAgIH1cclxuICB9XHJcblxyXG4gIGNvbXBvbmVudFdpbGxNb3VudCgpe1xyXG4gICAgZmV0Y2godXJsbmFtZSArIFwiLz9kZXNpcmVkTWV0aG9kPVNVR0dFU1QmdW5hbWU9XCIgKyB0aGlzLnByb3BzLnRleHRWYWx1ZSkudGhlbihyZXNwb25zZSA9PiByZXNwb25zZS50ZXh0KCkpLnRoZW4oZGF0YSA9PiB7XHJcbiAgICAgIGNvbnNvbGUubG9nKFwiU2hvdyBkYXRhIGZldGNoZWQuIENvdW50OiBcIiArIGRhdGEpXHJcbiAgICAgIHZhciBkYXRhbGlzdCA9IGRhdGEuc3BsaXQoXCIsXCIpO1xyXG4gICAgICBpZihkYXRhID09IFwiXCIpe1xyXG4gICAgICAgIHRoaXMuc2V0U3RhdGUoe1xyXG4gICAgICAgIFxyXG4gICAgICAgICAgICBsaXN0OiBbXVxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICAgIGVsc2V7XHJcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSh7XHJcbiAgICAgICAgXHJcbiAgICAgICAgICAgIGxpc3Q6IGRhdGFsaXN0XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICB9KVxyXG4gICAgXHJcbiAgICAgIFxyXG4gIH1cclxuXHJcbiAgcmVuZGVyKCl7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgYWxpZ249XCJjZW50ZXJcIj5cclxuICAgICAgICA8TGlzdCBjb21wb25lbnQ9XCJuYXZcIiAgc3R5bGUgPSB7e3dpZHRoOiAyNTB9fT48RGl2aWRlciAvPlxyXG4gICAgICAgICAge3RoaXMuc3RhdGUubGlzdC5tYXAoKGluZ3JlZCkgPT4gKDxkaXYga2V5PXtpbmdyZWR9PlxyXG4gICAgICAgICAgICA8TGlzdEl0ZW0gYnV0dG9uIG9uQ2xpY2s9e3RoaXMucHJvcHMub25DbGlja2VyfSBjdXN0b210ZXh0PXtpbmdyZWR9PlxyXG4gICAgICAgICAgICAgICAgICA8TGlzdEl0ZW1UZXh0IHByaW1hcnk9e2luZ3JlZH0gLz5cclxuICAgICAgICAgICAgICA8L0xpc3RJdGVtPlxyXG4gICAgICAgICAgICAgIDxEaXZpZGVyIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICA8L0xpc3Q+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApXHJcbiAgfVxyXG4gIFxyXG59XHJcblxyXG5jbGFzcyBDcmVhdG9yIGV4dGVuZHMgUmVhY3QuQ29tcG9uZW50e1xyXG5cclxuICBjb25zdHJ1Y3Rvcihwcm9wcyl7XHJcbiAgICBzdXBlcihwcm9wcyk7XHJcbiAgICB0aGlzLnN0YXRlID0ge1xyXG4gICAgICBsaXN0T3BlbjogZmFsc2UsXHJcbiAgICAgIHRleHRWYWx1ZTogXCJcIixcclxuICAgICAgaW5ncmVkdGV4dGxpc3Q6IFtdLFxyXG4gICAgICBuYW1lOiBcIlwiLFxyXG4gICAgICBkZXNjcmlwdGlvbjogXCJcIixcclxuICAgICAgYnV0dG9uSW5mbzogXCJBZGQgcmVjaXBlIVwiLFxyXG4gICAgICBlcnJvckluZm86IFwiXCJcclxuICAgIH1cclxuXHJcbiAgICB0aGlzLnNob3dNZW51ID0gdGhpcy5zaG93TWVudS5iaW5kKHRoaXMpO1xyXG4gICAgdGhpcy5jbG9zZU1lbnUgPSB0aGlzLmNsb3NlTWVudS5iaW5kKHRoaXMpO1xyXG4gICAgdGhpcy5SZW1vdmVJbmdyZWQgPSB0aGlzLlJlbW92ZUluZ3JlZC5iaW5kKHRoaXMpO1xyXG4gICAgdGhpcy5hZGRJbmdyZWRpZW50ID0gdGhpcy5hZGRJbmdyZWRpZW50LmJpbmQodGhpcyk7XHJcbiAgICB0aGlzLmNoYW5nZU5hbWUgPSB0aGlzLmNoYW5nZU5hbWUuYmluZCh0aGlzKTtcclxuICAgIHRoaXMuY2hhbmdlRGVzY3JpcHRpb24gPSB0aGlzLmNoYW5nZURlc2NyaXB0aW9uLmJpbmQodGhpcyk7XHJcbiAgICB0aGlzLmNyZWF0ZVJlY2lwZSA9IHRoaXMuY3JlYXRlUmVjaXBlLmJpbmQodGhpcyk7XHJcbiAgfVxyXG5cclxuICBzaG93TWVudShldmVudCl7XHJcbiAgICB0aGlzLnNldFN0YXRlKHtcclxuICAgICAgYnV0dG9uSW5mbzogXCJBZGQgcmVjaXBlIVwiLFxyXG4gICAgICBlcnJvckluZm86IFwiXCJcclxuICAgIH0pXHJcbiAgICBpZih0aGlzLnN0YXRlLmxpc3RPcGVuKXtcclxuICAgICAgdGhpcy5zZXRTdGF0ZSh7IGxpc3RPcGVuOiBmYWxzZSB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgdGhpcy5jbG9zZU1lbnUpO1xyXG4gICAgICAgIH0pOyAgXHJcbiAgICB9XHJcbiAgICBlbHNle1xyXG4gICAgICAgIHRoaXMuc2V0U3RhdGUoe1xyXG4gICAgICAgICAgdGV4dFZhbHVlOiBldmVudC50YXJnZXQudmFsdWUsXHJcbiAgICAgICAgICBsaXN0T3BlbjogdHJ1ZVxyXG4gICAgICAgIH0sICAoKSA9PiB7XHJcbiAgICAgICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIHRoaXMuY2xvc2VNZW51KTtcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgUmVtb3ZlSW5ncmVkKGV2ZW50KXtcclxuICAgIHZhciBpbmRleCA9ICsodGhpcy5zdGF0ZS5pbmdyZWR0ZXh0bGlzdC5pbmRleE9mKGV2ZW50LnRhcmdldC5nZXRBdHRyaWJ1dGUoJ2tleTInKSkpO1xyXG4gICAgdmFyIGNoYW5nZWRBcnJheSA9IHRoaXMuc3RhdGUuaW5ncmVkdGV4dGxpc3Quc2xpY2UoKTtcclxuICAgIGNoYW5nZWRBcnJheS5zcGxpY2UoaW5kZXgsIDEpO1xyXG4gICAgdGhpcy5zZXRTdGF0ZSgocHJldlN0YXRlLCBwcm9wcykgPT4ge3JldHVybiB7aW5ncmVkdGV4dGxpc3Q6IGNoYW5nZWRBcnJheX19KVxyXG4gIH1cclxuXHJcbiAgYWRkSW5ncmVkaWVudChldmVudCl7XHJcbiAgICBldmVudC5wZXJzaXN0KCk7XHJcbiAgICB2YXIgY3VzdG9tID0gZXZlbnQuY3VycmVudFRhcmdldC5nZXRBdHRyaWJ1dGUoJ2N1c3RvbXRleHQnKVxyXG4gICAgdmFyIHRtcGFyciA9IHRoaXMuc3RhdGUuaW5ncmVkdGV4dGxpc3Quc2xpY2UoKS5jb25jYXQoW2N1c3RvbV0pO1xyXG5cclxuICAgIGlmKGV2ZW50LmN1cnJlbnRUYXJnZXQuaWQgPT0gXCJhZGRCdXR0b25cIil7XHJcbiAgICAgIGlmKHRoaXMuc3RhdGUuaW5ncmVkdGV4dGxpc3QuZmluZEluZGV4KGluZyA9PiBpbmcgPT0gdGhpcy5zdGF0ZS50ZXh0VmFsdWUpID09IC0xKXtcclxuICAgICAgICAvL3RoaXMuc2V0U3RhdGUoKHByZXZTdGF0ZSwgcHJvcHMpID0+IHtyZXR1cm4ge2luZ3JlZGxpc3Q6IHByZXZTdGF0ZS5pbmdyZWRsaXN0LmNvbmNhdChbKFxyXG4gICAgICAgICAgLy88aDEgb25DbGljaz17dGhpcy5SZW1vdmVJbmdyZWR9IGtleT17dGhpcy5zdGF0ZS50ZXh0VmFsdWV9Pnt0aGlzLnN0YXRlLnRleHRWYWx1ZX08L2gxPlxyXG4gICAgICAgIC8vKV0pfX0pXHJcblxyXG4gICAgICAgIHRtcGFyciA9IHRoaXMuc3RhdGUuaW5ncmVkdGV4dGxpc3Quc2xpY2UoKS5jb25jYXQoW3RoaXMuc3RhdGUudGV4dFZhbHVlXSk7XHJcbiAgICAgICAgY29uc29sZS5sb2codGhpcy5zdGF0ZS50ZXh0VmFsdWUgKyBcIlVUVVRcIilcclxuXHJcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSgocHJldlN0YXRlLCBwcm9wcykgPT4ge3JldHVybiB7aW5ncmVkdGV4dGxpc3Q6IHRtcGFycn19KVxyXG4gICAgICB9XHJcblxyXG4gICAgICBcclxuICAgIH1cclxuXHJcbiAgICBlbHNle1xyXG4gICAgICB0aGlzLnNldFN0YXRlKHsgbGlzdE9wZW46IGZhbHNlIH0sICgpID0+IHtcclxuICAgICAgICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignY2xpY2snLCB0aGlzLmNsb3NlTWVudSk7XHJcbiAgICAgICAgfSk7ICBcclxuICAgICAgICAvL2lmKHRoaXMuc3RhdGUuaW5ncmVkbGlzdC5maW5kSW5kZXgoaW5nID0+IGluZy5rZXkgPT0gZXZlbnQudGFyZ2V0LmdldEF0dHJpYnV0ZSgnY3VzdG9tdGV4dCcpKSA9PSAtMSl7XHJcbiAgICAgICAgaWYodGhpcy5zdGF0ZS5pbmdyZWR0ZXh0bGlzdC5maW5kSW5kZXgoaW5nID0+IGluZyA9PSBjdXN0b20pID09IC0xKXtcclxuICAgICAgICAvL3RoaXMuc2V0U3RhdGUoKHByZXZTdGF0ZSwgcHJvcHMpID0+IHtyZXR1cm4ge2luZ3JlZGxpc3Q6IHByZXZTdGF0ZS5pbmdyZWRsaXN0LmNvbmNhdChbKFxyXG4gICAgICAgIC8vPGgxIG9uQ2xpY2s9e3RoaXMuUmVtb3ZlSW5ncmVkfSBrZXk9e2V2ZW50LnRhcmdldC5nZXRBdHRyaWJ1dGUoJ2N1c3RvbXRleHQnKX0+e2V2ZW50LnRhcmdldC5nZXRBdHRyaWJ1dGUoJ2N1c3RvbXRleHQnKX08L2gxPlxyXG4gICAgICAgIC8vKV0pfX0pXHJcblxyXG4gICAgICAgIHRoaXMuc2V0U3RhdGUoKHByZXZTdGF0ZSwgcHJvcHMpID0+IHtyZXR1cm4ge2luZ3JlZHRleHRsaXN0OiB0bXBhcnJ9fSlcclxuICAgICAgfVxyXG4gICAgICBcclxuICAgICAgXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjbG9zZU1lbnUoZXZlbnQpIHtcclxuICAgIFxyXG4gICAgICBpZiAoIXRoaXMuZHJvcGRvd25NZW51LmNvbnRhaW5zKGV2ZW50LnRhcmdldCkpIHtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLnNldFN0YXRlKHsgbGlzdE9wZW46IGZhbHNlIH0sICgpID0+IHtcclxuICAgICAgICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgdGhpcy5jbG9zZU1lbnUpO1xyXG4gICAgICAgIH0pOyAgXHJcbiAgICAgICAgXHJcbiAgICAgIH1cclxuICB9XHJcblxyXG4gIGNoYW5nZU5hbWUoZXZlbnQpe1xyXG4gICAgdGhpcy5zZXRTdGF0ZSh7XHJcbiAgICAgIGJ1dHRvbkluZm86IFwiQWRkIHJlY2lwZSFcIixcclxuICAgICAgZXJyb3JJbmZvOiBcIlwiXHJcbiAgICB9KVxyXG4gICAgdGhpcy5zZXRTdGF0ZSh7XHJcbiAgICAgIG5hbWU6IGV2ZW50LmN1cnJlbnRUYXJnZXQudmFsdWVcclxuICAgIH0pXHJcbiAgfVxyXG5cclxuICBjaGFuZ2VEZXNjcmlwdGlvbihldmVudCl7XHJcbiAgICB0aGlzLnNldFN0YXRlKHtcclxuICAgICAgYnV0dG9uSW5mbzogXCJBZGQgcmVjaXBlIVwiLFxyXG4gICAgICBlcnJvckluZm86IFwiXCJcclxuICAgIH0pXHJcbiAgICB0aGlzLnNldFN0YXRlKHtcclxuICAgICAgZGVzY3JpcHRpb246IGV2ZW50LmN1cnJlbnRUYXJnZXQudmFsdWVcclxuICAgIH0pXHJcbiAgfVxyXG5cclxuICBjcmVhdGVSZWNpcGUoKXtcclxuICAgIGlmKHRoaXMuc3RhdGUubmFtZSA9PSBcIlwiIHx8IHRoaXMuc3RhdGUuZGVzY3JpcHRpb24gPT0gXCJcIiB8fCB0aGlzLnN0YXRlLmluZ3JlZHRleHRsaXN0ID09IFtdKXtcclxuICAgICAgdGhpcy5zZXRTdGF0ZSh7XHJcbiAgICAgICAgZXJyb3JJbmZvOiBcIk9uZSBvciBtb3JlIGZpZWxkcyBpcyBsZWZ0IGJsYW5rLiBUcnkgYWdhaW4uXCJcclxuICAgICAgfSlcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIGZldGNoKHVybG5hbWUgKyBcIi8/ZGVzaXJlZE1ldGhvZD1BRERSRUNJUEUmdW5hbWU9XCIgKyB0aGlzLnN0YXRlLm5hbWUgKyBcIiZ1bGlzdD1cIiArIHRoaXMuc3RhdGUuaW5ncmVkdGV4dGxpc3QudG9TdHJpbmcoKSArIFwiJnVkZXNjPVwiICsgdGhpcy5zdGF0ZS5kZXNjcmlwdGlvbikudGhlbihyZXNwb25zZSA9PiByZXNwb25zZS50ZXh0KCkpLnRoZW4oZGF0YSA9PiB7XHJcbiAgICAgIGlmKGRhdGEgPT0gXCJSZWNpcGUgZXhpc3RzXCIpe1xyXG4gICAgICAgIHRoaXMuc2V0U3RhdGUoe1xyXG4gICAgICAgICAgZXJyb3JJbmZvOiBcIlJlY2lwZSBuYW1lIGV4aXN0cy4gVHJ5IGFnYWluLlwiXHJcbiAgICAgICAgfSlcclxuICAgICAgfVxyXG4gICAgICBlbHNle1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiQWRkZWQgcmVjaXBlIFwiICsgZGF0YSlcclxuICAgICAgICB0aGlzLnNldFN0YXRlKHtcclxuICAgICAgICAgIGJ1dHRvbkluZm86IFwiUmVjaXBlIGFkZGVkIVwiXHJcbiAgICAgICAgfSlcclxuICAgICAgfVxyXG4gICAgICBcclxuICAgIH0pXHJcbiAgfVxyXG5cclxuICByZW5kZXIoKXtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXY+XHJcbiAgICAgIDxkaXYgYWxpZ249XCJjZW50ZXJcIj5cclxuICAgICAgPGZvcm0gbmFtZT1cIm5hbWVGb3JtXCIgb25TdWJtaXQ9eyhldmVudCkgPT4gdGhpcy5zaG93TWVudShldmVudCl9PlxyXG4gICAgICAgIDxsYWJlbD5cclxuICAgICAgICAgIDxoMz5SZWNpcGUgbmFtZTwvaDM+IFxyXG4gICAgICAgICAgPFRleHRGaWVsZCAgb25LZXlQcmVzcz17ZSA9PiB7aWYgKGUua2V5ID09PSAnRW50ZXInKSBlLnByZXZlbnREZWZhdWx0KCk7fX0gb25DaGFuZ2U9eyhldmVudCkgPT4gdGhpcy5jaGFuZ2VOYW1lKGV2ZW50KX0gbWFyZ2luPVwibm9ybWFsXCIgLz5cclxuICAgICAgICA8L2xhYmVsPlxyXG4gICAgICA8L2Zvcm0+XHJcblxyXG4gICAgICA8YnIvPjxici8+XHJcblxyXG4gICAgICA8Zm9ybSBuYW1lPVwiYWRkRm9ybVwiIG9uU3VibWl0PXsoZXZlbnQpID0+IHRoaXMuc2hvd01lbnUoZXZlbnQpfT5cclxuICAgICAgICA8bGFiZWw+XHJcbiAgICAgICAgICAgIDxoMz5BZGQgaW5ncmVkaWVudHM8L2gzPlxyXG4gICAgICAgICAgICA8VGV4dEZpZWxkICBvbktleVByZXNzPXtlID0+IHtpZiAoZS5rZXkgPT09ICdFbnRlcicpIGUucHJldmVudERlZmF1bHQoKTt9fSBvbkNoYW5nZT17KGV2ZW50KSA9PiB0aGlzLnNob3dNZW51KGV2ZW50KX0gbWFyZ2luPVwibm9ybWFsXCIgLz5cclxuICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICBcclxuICAgICAgPC9mb3JtPlxyXG5cclxuICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiY29udGFpbmVkXCIgY29sb3I9XCJzZWNvbmRhcnlcIiBvbkNsaWNrPXt0aGlzLmFkZEluZ3JlZGllbnR9IGlkPVwiYWRkQnV0dG9uXCIgIHN0eWxlPXt7IGZvbnRGYW1pbHk6IFwiR2VudGl1bSBCb29rIEJhc2ljXCIsIGZvbnRXZWlnaHQ6IFwiYm9sZFwiLCBmb250U2l6ZTogJzE2cHgnIH19PlBpY2sgaW5ncmVkaWVudDwvQnV0dG9uPlxyXG4gICAgICBcclxuICAgICAgeyBcclxuICAgICAgICB0aGlzLnN0YXRlLmxpc3RPcGVuIFxyXG4gICAgICAgID8oXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZW51XCIgcmVmPXsoZWxlbWVudCkgPT4ge1xyXG4gICAgICAgICAgdGhpcy5kcm9wZG93bk1lbnUgPSBlbGVtZW50O1xyXG4gICAgICAgIH19PlxyXG4gICAgICAgICAgPExpc3RpbmcgdGV4dFZhbHVlPXt0aGlzLnN0YXRlLnRleHRWYWx1ZX0gb25DbGlja2VyPXt0aGlzLmFkZEluZ3JlZGllbnR9Lz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICApXHJcbiAgICAgICAgOihcclxuICAgICAgICA8ZGl2Pjxici8+PC9kaXY+XHJcbiAgICAgICAgKVxyXG4gICAgICB9XHJcblxyXG4gICAgICBcclxuICAgICAgXHJcbiAgICAgIDxkaXYgY2xhc3M9XCJpbmxpbmVcIj5cclxuICAgICAge1xyXG4gICAgICAgIHRoaXMuc3RhdGUuaW5ncmVkdGV4dGxpc3QubWFwKGluZ3JlZCA9PiAoXHJcbiAgICAgICAgICA8QnV0dG9uICB2YXJpYW50PVwib3V0bGluZWRcIiBvbkNsaWNrPXt0aGlzLlJlbW92ZUluZ3JlZH0ga2V5PXtpbmdyZWR9IGtleTI9e2luZ3JlZH0+e2luZ3JlZH08L0J1dHRvbj5cclxuICAgICAgICApXHJcbiAgICAgICAgKVxyXG4gICAgICB9XHJcbiAgICAgIDwvZGl2Pjxici8+PGJyLz48YnIvPlxyXG5cclxuXHJcbiAgICAgIDxoMz5FbnRlciByZWNpcGU8L2gzPiBcclxuICAgICAgPFRleHRGaWVsZCAgc3R5bGU9e3t3aWR0aDogMzAwfX0gbXVsdGlsaW5lPXt0cnVlfSByb3dzPXs1fSBvbkNoYW5nZT17KGV2ZW50KSA9PiB0aGlzLmNoYW5nZURlc2NyaXB0aW9uKGV2ZW50KX0gLz5cclxuXHJcbiAgICAgIDxici8+PGJyLz48YnIvPlxyXG4gICAgICA8aDQ+e3RoaXMuc3RhdGUuZXJyb3JJbmZvfTwvaDQ+XHJcblxyXG4gICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJjb250YWluZWRcIiBzdHlsZT17e2ZvbnRGYW1pbHk6IFwiTW9udHNlcnJhdFwiLCBmb250V2VpZ2h0OiBcImJvbGRcIiwgZm9udFNpemU6ICcyMHB4JyB9fSBjb2xvcj1cInByaW1hcnlcIiBvbkNsaWNrPXt0aGlzLmNyZWF0ZVJlY2lwZX0+e3RoaXMuc3RhdGUuYnV0dG9uSW5mb308L0J1dHRvbj5cclxuXHJcbiAgICAgIDwvZGl2PjxzdHlsZSBqc3g+e2BcclxuIFxyXG5cclxuICAgICAgICBoMyB7XHJcbiAgICAgICAgICBmb250LWZhbWlseTogXCJHZW50aXVtIEJvb2sgQmFzaWNcIiwgVGltZXMsIHNlcmlmO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgYH08L3N0eWxlPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIClcclxuICB9XHJcbn1cclxuXHJcbmNvbnN0IEZpcnN0ID0gIChwcm9wcykgPT4gKFxyXG4gIDxMYXlvdXQ+XHJcbiAgICA8Q3JlYXRvci8+XHJcbiAgPC9MYXlvdXQ+XHJcbilcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEZpcnN0Il19 */\n/*@ sourceURL=pages\\create.js */"
      }));
    }
  }]);

  return Creator;
}(__WEBPACK_IMPORTED_MODULE_1_react___default.a.Component);

var First = function First(props) {
  return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__components_MyLayout_js__["a" /* default */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 276
    }
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(Creator, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 277
    }
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (First);
    (function (Component, route) {
      if(!Component) return
      if (false) return
      module.hot.accept()
      Component.__route = route

      if (module.hot.status() === 'idle') return

      var components = next.router.components
      for (var r in components) {
        if (!components.hasOwnProperty(r)) continue

        if (components[r].Component.__route === route) {
          next.router.update(r, Component)
        }
      }
    })(typeof __webpack_exports__ !== 'undefined' ? __webpack_exports__.default : (module.exports.default || module.exports), "/create")
  
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__("./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=6.ec4f1f000ba4fa9339b0.hot-update.js.map