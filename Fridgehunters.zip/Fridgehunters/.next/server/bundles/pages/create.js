module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 5);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./components/Header.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style__ = __webpack_require__("styled-jsx/style");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_next_link__ = __webpack_require__("next/link");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_next_link___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_next_link__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__material_ui_core_AppBar__ = __webpack_require__("@material-ui/core/AppBar");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__material_ui_core_AppBar___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3__material_ui_core_AppBar__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__material_ui_core_Toolbar__ = __webpack_require__("@material-ui/core/Toolbar");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__material_ui_core_Toolbar___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4__material_ui_core_Toolbar__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__material_ui_core_Button__ = __webpack_require__("@material-ui/core/Button");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__material_ui_core_Button___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5__material_ui_core_Button__);
var _jsxFileName = "C:\\Users\\Aseem\\React Projects\\Fridgehunters\\components\\Header.js";





 //import "typeface-lobster";

var linkStyle = {
  marginRight: 15,
  border: '2px solid #DDD'
};

var Header = function Header() {
  return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 14
    },
    className: "jsx-620698464"
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("h1", {
    align: "center",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 15
    },
    className: "jsx-620698464"
  }, "Fridgehunters"), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a, {
    styleId: "620698464",
    css: "h1.jsx-620698464{font-family:\"Lobster\",Times,serif;font-size:54px;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbXBvbmVudHNcXEhlYWRlci5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFjc0QsQUFJK0Msa0NBRXZDLGVBQUMiLCJmaWxlIjoiY29tcG9uZW50c1xcSGVhZGVyLmpzIiwic291cmNlUm9vdCI6IkM6XFxVc2Vyc1xcQXNlZW1cXFJlYWN0IFByb2plY3RzXFxGcmlkZ2VodW50ZXJzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJ1xyXG5pbXBvcnQgQXBwQmFyIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0FwcEJhcic7XHJcbmltcG9ydCBUb29sYmFyIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL1Rvb2xiYXInO1xyXG5pbXBvcnQgQnV0dG9uIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0J1dHRvbic7XHJcbi8vaW1wb3J0IFwidHlwZWZhY2UtbG9ic3RlclwiO1xyXG5cclxuY29uc3QgbGlua1N0eWxlID0ge1xyXG4gIG1hcmdpblJpZ2h0OiAxNSxcclxuICBib3JkZXI6ICcycHggc29saWQgI0RERCdcclxufVxyXG5cclxuY29uc3QgSGVhZGVyID0gKCkgPT4ge1xyXG4gICAgcmV0dXJuKFxyXG4gICAgPGRpdj5cclxuICAgIFx0PGgxIGFsaWduPVwiY2VudGVyXCI+RnJpZGdlaHVudGVyczwvaDE+PHN0eWxlIGpzeD57YFxyXG5cclxuICAgICAgICBoMSB7XHJcbiAgICAgICAgICBmb250LWZhbWlseTogXCJMb2JzdGVyXCIsIFRpbWVzLCBzZXJpZjtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogNTRweFxyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgYH08L3N0eWxlPlxyXG4gICAgICA8QXBwQmFyIHBvc2l0aW9uPVwic3RhdGljXCI+XHJcbiAgICAgICAgPFRvb2xiYXIgIHN0eWxlPXt7anVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInfX0+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxMaW5rIGhyZWY9XCIvaG90XCI+XHJcbiAgICAgICAgICAgIDxCdXR0b24gc3R5bGU9e3sgZm9udFdlaWdodDogXCJib2xkXCIsIGZvbnRTaXplOiBcIjE2cHhcIiAgfX0+SE9UPC9CdXR0b24+XHJcbiAgICAgICAgICA8L0xpbms+XHJcblxyXG4gICAgICAgICAgPExpbmsgaHJlZj1cIi9cIj5cclxuICAgICAgICAgICAgPEJ1dHRvbiBzdHlsZT17eyBmb250V2VpZ2h0OiBcImJvbGRcIiwgZm9udFNpemU6IFwiMTZweFwiICB9fT5IT01FPC9CdXR0b24+XHJcbiAgICAgICAgICA8L0xpbms+XHJcblxyXG4gICAgICAgICAgPExpbmsgaHJlZj1cIi9jcmVhdGVcIj5cclxuICAgICAgICAgICAgPEJ1dHRvbiBzdHlsZT17eyBmb250V2VpZ2h0OiBcImJvbGRcIiwgZm9udFNpemU6IFwiMTZweFwiIH19PkNSRUFURTwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Ub29sYmFyPlxyXG4gICAgICA8L0FwcEJhcj5cclxuICAgICAgICBcclxuICAgIDwvZGl2PlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgSGVhZGVyIl19 */\n/*@ sourceURL=components\\Header.js */"
  }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__material_ui_core_AppBar___default.a, {
    position: "static",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 23
    }
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__material_ui_core_Toolbar___default.a, {
    style: {
      justifyContent: 'center'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24
    }
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 25
    },
    className: "jsx-620698464"
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_next_link___default.a, {
    href: "/hot",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 26
    }
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__material_ui_core_Button___default.a, {
    style: {
      fontWeight: "bold",
      fontSize: "16px"
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 27
    }
  }, "HOT")), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_next_link___default.a, {
    href: "/",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 30
    }
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__material_ui_core_Button___default.a, {
    style: {
      fontWeight: "bold",
      fontSize: "16px"
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31
    }
  }, "HOME")), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_next_link___default.a, {
    href: "/create",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 34
    }
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__material_ui_core_Button___default.a, {
    style: {
      fontWeight: "bold",
      fontSize: "16px"
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 35
    }
  }, "CREATE"))))));
};

/* harmony default export */ __webpack_exports__["a"] = (Header);

/***/ }),

/***/ "./components/MyLayout.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__Header__ = __webpack_require__("./components/Header.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__meta__ = __webpack_require__("./components/meta.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__material_ui_core_styles__ = __webpack_require__("@material-ui/core/styles");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__material_ui_core_styles___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3__material_ui_core_styles__);
var _jsxFileName = "C:\\Users\\Aseem\\React Projects\\Fridgehunters\\components\\MyLayout.js";



 //import indigo from '@material-ui/core/colors/violet';
//import pink from '@material-ui/core/colors/blue';
//import red from '@material-ui/core/colors/red';

var theme = Object(__WEBPACK_IMPORTED_MODULE_3__material_ui_core_styles__["createMuiTheme"])({
  palette: {
    primary: {
      // light: will be calculated from palette.primary.main,
      main: '#00cc44' // dark: will be calculated from palette.primary.main,
      // contrastText: will be calculated to contast with palette.primary.main

    },
    secondary: {
      main: '#80a2ff' // dark: will be calculated from palette.secondary.main,

    },
    tertiary: {
      main: '#33ffcc' // dark: will be calculated from palette.secondary.main,

    },
    // Used by `getContrastText()` to maximize the contrast between the background and
    // the text.
    contrastThreshold: 3,
    // Used to shift a color's luminance by approximately
    // two indexes within its tonal palette.
    // E.g., shift from Red 500 to Red 300 or Red 700.
    tonalOffset: 0.2
  },
  props: {
    // Name of the component ⚛️
    MuiButtonBase: {
      // The properties to apply
      disableRipple: true // No more ripple, on the whole application 💣!

    }
  }
});
var layoutStyle = {
  margin: 20,
  padding: 20,
  border: '1px solid #DDD'
};

var Layout = function Layout(props) {
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__material_ui_core_styles__["MuiThemeProvider"], {
    theme: theme,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 49
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__meta__["a" /* default */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 50
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__Header__["a" /* default */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 51
    }
  }), props.children);
};

/* harmony default export */ __webpack_exports__["a"] = (Layout);

/***/ }),

/***/ "./components/meta.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style__ = __webpack_require__("styled-jsx/style");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_next_head__ = __webpack_require__("next/head");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_next_head___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_next_head__);
var _jsxFileName = "C:\\Users\\Aseem\\React Projects\\Fridgehunters\\components\\meta.js";



/* harmony default export */ __webpack_exports__["a"] = (function () {
  /*background-image: url("/static/download.jpg");
        background-repeat: no-repeat;
        backgroun-attachment: fixed;
        background-position: right bottom;*/
  return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 8
    },
    className: "jsx-2117693257"
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_next_head___default.a, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 9
    }
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("meta", {
    name: "viewport",
    content: "width=device-width, initial-scale=1",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 10
    },
    className: "jsx-2117693257"
  }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("meta", {
    charSet: "utf-8",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 11
    },
    className: "jsx-2117693257"
  })), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a, {
    styleId: "2117693257",
    css: "@import url('https://fonts.googleapis.com/css?family=Gentium+Book+Basic');@fontface{font-family:'Gentium Book Basic',cursive;src:url('https://fonts.googleapis.com/css?family=Gentium+Book+Basic');}@import url('https://fonts.googleapis.com/css?family=Montserrat');@fontface{font-family:'Montserrat',cursive;src:url('https://fonts.googleapis.com/css?family=Montserrat');}@import url('https://fonts.googleapis.com/css?family=Noto+Sans');@fontface{font-family:'Noto Sans',cursive;src:url('https://fonts.googleapis.com/css?family=Noto+Sans');}@import url('https://fonts.googleapis.com/css?family=Lobster');@fontface{font-family:'Lobster',cursive;src:url('https://fonts.googleapis.com/css?family=Lobster');}body{background:#e1ffdb;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbXBvbmVudHNcXG1ldGEuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBWXVCLEFBRzRCLEFBR29ELEFBR3pCLEFBS3FCLEFBRzdCLEFBR21DLEFBR3RDLEFBSTBCLEFBRzVCLG1CQXpCbkMsV0EyQkMsRUFQQSxDQU5FLFFBUkEsZ0RBcUJELElBUEEsRUFORSxnQkFSQSIsImZpbGUiOiJjb21wb25lbnRzXFxtZXRhLmpzIiwic291cmNlUm9vdCI6IkM6XFxVc2Vyc1xcQXNlZW1cXFJlYWN0IFByb2plY3RzXFxGcmlkZ2VodW50ZXJzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEhlYWQgZnJvbSAnbmV4dC9oZWFkJ1xyXG5leHBvcnQgZGVmYXVsdCAoKSA9PiB7XHJcbiAgLypiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIvc3RhdGljL2Rvd25sb2FkLmpwZ1wiKTtcclxuICAgICAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICAgICAgIGJhY2tncm91bi1hdHRhY2htZW50OiBmaXhlZDtcclxuICAgICAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiByaWdodCBib3R0b207Ki9cclxuICByZXR1cm4oXHJcbiAgPGRpdj5cclxuICAgIDxIZWFkPlxyXG4gICAgICA8bWV0YSBuYW1lPVwidmlld3BvcnRcIiBjb250ZW50PVwid2lkdGg9ZGV2aWNlLXdpZHRoLCBpbml0aWFsLXNjYWxlPTFcIiAvPlxyXG4gICAgICA8bWV0YSBjaGFyU2V0PVwidXRmLThcIiAvPlxyXG4gICAgPC9IZWFkPlxyXG4gICAgPHN0eWxlIGpzeCBnbG9iYWw+e2BcclxuICAgICAgYm9keSB7IFxyXG4gICAgICAgIGJhY2tncm91bmQ6ICNlMWZmZGI7XHJcblxyXG4gICAgICB9XHJcbiAgICAgIEBpbXBvcnQgdXJsKCdodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9R2VudGl1bStCb29rK0Jhc2ljJyk7XHJcblxyXG4gICAgICAgICAgQGZvbnRmYWNlIHtcclxuICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdHZW50aXVtIEJvb2sgQmFzaWMnLCBjdXJzaXZlO1xyXG4gICAgICAgICAgICBzcmM6IHVybCgnaHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbS9jc3M/ZmFtaWx5PUdlbnRpdW0rQm9vaytCYXNpYycpXHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICBAaW1wb3J0IHVybCgnaHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbS9jc3M/ZmFtaWx5PU1vbnRzZXJyYXQnKTtcclxuXHJcbiAgICAgICAgICBAZm9udGZhY2Uge1xyXG4gICAgICAgICAgICBmb250LWZhbWlseTogJ01vbnRzZXJyYXQnLCBjdXJzaXZlO1xyXG4gICAgICAgICAgICBzcmM6IHVybCgnaHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbS9jc3M/ZmFtaWx5PU1vbnRzZXJyYXQnKVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgIEBpbXBvcnQgdXJsKCdodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9Tm90bytTYW5zJyk7XHJcblxyXG4gICAgICAgIEBmb250ZmFjZSB7XHJcbiAgICAgICAgICBmb250LWZhbWlseTogJ05vdG8gU2FucycsIGN1cnNpdmU7XHJcbiAgICAgICAgICBzcmM6IHVybCgnaHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbS9jc3M/ZmFtaWx5PU5vdG8rU2FucycpXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgIEBpbXBvcnQgdXJsKCdodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TG9ic3RlcicpO1xyXG5cclxuICAgICAgICBAZm9udGZhY2Uge1xyXG4gICAgICAgICAgZm9udC1mYW1pbHk6ICdMb2JzdGVyJywgY3Vyc2l2ZTtcclxuICAgICAgICAgIHNyYzogdXJsKCdodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TG9ic3RlcicpXHJcbiAgICAgICAgfVxyXG5cclxuICAgIGB9PC9zdHlsZT5cclxuICA8L2Rpdj5cclxuKX1cclxuIl19 */\n/*@ sourceURL=components\\meta.js */"
  }));
});

/***/ }),

/***/ "./components/urlname.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony default export */ __webpack_exports__["a"] = ("https://herokufhapi.herokuapp.com");

/***/ }),

/***/ "./pages/create.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style__ = __webpack_require__("styled-jsx/style");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_next_router__ = __webpack_require__("next/router");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_next_router___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_next_router__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__components_MyLayout_js__ = __webpack_require__("./components/MyLayout.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_isomorphic_unfetch__ = __webpack_require__("isomorphic-unfetch");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_isomorphic_unfetch___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_isomorphic_unfetch__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_next_link__ = __webpack_require__("next/link");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_next_link___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_next_link__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__components_urlname_js__ = __webpack_require__("./components/urlname.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__material_ui_core_Button__ = __webpack_require__("@material-ui/core/Button");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__material_ui_core_Button___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7__material_ui_core_Button__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__material_ui_core_TextField__ = __webpack_require__("@material-ui/core/TextField");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__material_ui_core_TextField___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_8__material_ui_core_TextField__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__material_ui_core_List__ = __webpack_require__("@material-ui/core/List");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__material_ui_core_List___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_9__material_ui_core_List__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__material_ui_core_ListItem__ = __webpack_require__("@material-ui/core/ListItem");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__material_ui_core_ListItem___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_10__material_ui_core_ListItem__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__material_ui_core_ListItemText__ = __webpack_require__("@material-ui/core/ListItemText");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__material_ui_core_ListItemText___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_11__material_ui_core_ListItemText__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__material_ui_core_Divider__ = __webpack_require__("@material-ui/core/Divider");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__material_ui_core_Divider___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_12__material_ui_core_Divider__);
var _jsxFileName = "C:\\Users\\Aseem\\React Projects\\Fridgehunters\\pages\\create.js";



function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }













var querystring = __webpack_require__("querystring");

var Listing =
/*#__PURE__*/
function (_React$Component) {
  _inherits(Listing, _React$Component);

  function Listing(props) {
    var _this;

    _classCallCheck(this, Listing);

    _this = _possibleConstructorReturn(this, (Listing.__proto__ || Object.getPrototypeOf(Listing)).call(this, props));
    console.log(_this.props.textValue);
    _this.state = {
      list: []
    };
    return _this;
  }

  _createClass(Listing, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var _this2 = this;

      this.setState({
        list: ["Loading..."]
      });
      __WEBPACK_IMPORTED_MODULE_4_isomorphic_unfetch___default()(__WEBPACK_IMPORTED_MODULE_6__components_urlname_js__["a" /* default */] + "/ingredients?uname=" + encodeURI(this.props.textValue)).then(function (response) {
        return response.text();
      }).then(function (data) {
        console.log("Show data fetched. Count: " + data);
        var datalist = data.split(",");

        if (data == "") {
          _this2.setState({
            list: []
          });
        } else {
          _this2.setState({
            list: datalist
          });
        }
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        align: "center",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 52
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__material_ui_core_List___default.a, {
        component: "nav",
        style: {
          width: 250
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 53
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_12__material_ui_core_Divider___default.a, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 53
        }
      }), this.state.list.map(function (ingred) {
        return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
          key: ingred,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 54
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_10__material_ui_core_ListItem___default.a, {
          button: true,
          onClick: _this3.props.onClicker,
          customtext: ingred,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 55
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_11__material_ui_core_ListItemText___default.a, {
          primary: ingred,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 56
          }
        })), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_12__material_ui_core_Divider___default.a, {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 58
          }
        }));
      })));
    }
  }]);

  return Listing;
}(__WEBPACK_IMPORTED_MODULE_1_react___default.a.Component);

var Creator =
/*#__PURE__*/
function (_React$Component2) {
  _inherits(Creator, _React$Component2);

  function Creator(props) {
    var _this4;

    _classCallCheck(this, Creator);

    _this4 = _possibleConstructorReturn(this, (Creator.__proto__ || Object.getPrototypeOf(Creator)).call(this, props));
    _this4.state = {
      listOpen: false,
      textValue: "",
      ingredtextlist: [],
      name: "",
      description: "",
      buttonInfo: "Add recipe!",
      errorInfo: ""
    };
    _this4.showMenu = _this4.showMenu.bind(_assertThisInitialized(_this4));
    _this4.closeMenu = _this4.closeMenu.bind(_assertThisInitialized(_this4));
    _this4.RemoveIngred = _this4.RemoveIngred.bind(_assertThisInitialized(_this4));
    _this4.addIngredient = _this4.addIngredient.bind(_assertThisInitialized(_this4));
    _this4.changeName = _this4.changeName.bind(_assertThisInitialized(_this4));
    _this4.changeDescription = _this4.changeDescription.bind(_assertThisInitialized(_this4));
    _this4.createRecipe = _this4.createRecipe.bind(_assertThisInitialized(_this4));
    return _this4;
  }

  _createClass(Creator, [{
    key: "showMenu",
    value: function showMenu(event) {
      var _this5 = this;

      this.setState({
        buttonInfo: "Add recipe!",
        errorInfo: ""
      });

      if (this.state.listOpen) {
        this.setState({
          textValue: event.currentTarget.value.toLowerCase(),
          listOpen: false
        }, function () {
          document.removeEventListener('click', _this5.closeMenu);
        });
      } else {
        this.setState({
          textValue: event.currentTarget.value.toLowerCase(),
          listOpen: true
        }, function () {
          document.addEventListener('click', _this5.closeMenu);
        });
      }
    }
  }, {
    key: "RemoveIngred",
    value: function RemoveIngred(event) {
      var index = +this.state.ingredtextlist.indexOf(event.target.getAttribute('key2'));
      var changedArray = this.state.ingredtextlist.slice();
      changedArray.splice(index, 1);
      this.setState(function (prevState, props) {
        return {
          ingredtextlist: changedArray
        };
      });
    }
  }, {
    key: "addIngredient",
    value: function addIngredient(event) {
      var _this6 = this;

      event.persist();
      var custom = event.currentTarget.getAttribute('customtext');
      var tmparr = this.state.ingredtextlist.slice().concat([custom]);

      if (event.currentTarget.id == "addButton") {
        if (this.state.textValue == "") {
          return;
        }

        if (this.state.ingredtextlist.findIndex(function (ing) {
          return ing == _this6.state.textValue;
        }) == -1) {
          //this.setState((prevState, props) => {return {ingredlist: prevState.ingredlist.concat([(
          //<h1 onClick={this.RemoveIngred} key={this.state.textValue}>{this.state.textValue}</h1>
          //)])}})
          tmparr = this.state.ingredtextlist.slice().concat([this.state.textValue]);
          this.setState(function (prevState, props) {
            return {
              ingredtextlist: tmparr
            };
          });
        }
      } else {
        this.setState({
          listOpen: false
        }, function () {
          document.removeEventListener('click', _this6.closeMenu);
        }); //if(this.state.ingredlist.findIndex(ing => ing.key == event.target.getAttribute('customtext')) == -1){

        if (this.state.ingredtextlist.findIndex(function (ing) {
          return ing == custom;
        }) == -1) {
          //this.setState((prevState, props) => {return {ingredlist: prevState.ingredlist.concat([(
          //<h1 onClick={this.RemoveIngred} key={event.target.getAttribute('customtext')}>{event.target.getAttribute('customtext')}</h1>
          //)])}})
          this.setState(function (prevState, props) {
            return {
              ingredtextlist: tmparr
            };
          });
        }
      }
    }
  }, {
    key: "closeMenu",
    value: function closeMenu(event) {
      var _this7 = this;

      if (!this.dropdownMenu.contains(event.target)) {
        this.setState({
          listOpen: false
        }, function () {
          document.removeEventListener('click', _this7.closeMenu);
        });
      }
    }
  }, {
    key: "changeName",
    value: function changeName(event) {
      this.setState({
        buttonInfo: "Add recipe!",
        errorInfo: "",
        name: event.currentTarget.value
      });
    }
  }, {
    key: "changeDescription",
    value: function changeDescription(event) {
      this.setState({
        buttonInfo: "Add recipe!",
        errorInfo: "",
        description: event.currentTarget.value
      });
    }
  }, {
    key: "createRecipe",
    value: function createRecipe() {
      var _this8 = this;

      if (this.state.name == "" || this.state.description == "" || this.state.ingredtextlist == []) {
        this.setState({
          errorInfo: "One or more fields is left blank. Try again."
        });
        return;
      }

      var params = {
        uname: this.state.name,
        ulist: this.state.ingredtextlist.toString(),
        udesc: this.state.description
      };
      var queryAdd = querystring.stringify(params);
      __WEBPACK_IMPORTED_MODULE_4_isomorphic_unfetch___default()(__WEBPACK_IMPORTED_MODULE_6__components_urlname_js__["a" /* default */] + "/recipes", {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(params)
      }).then(function (response) {
        return response.text();
      }).then(function (data) {
        if (data == "Recipe exists") {
          _this8.setState({
            errorInfo: "Recipe name exists. Try again."
          });
        } else {
          console.log("Added recipe " + data);

          _this8.setState({
            buttonInfo: "Recipe added!"
          });
        }
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this9 = this;

      return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 219
        },
        className: "jsx-3083821483"
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        align: "center",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 220
        },
        className: "jsx-3083821483"
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 220
        },
        className: "jsx-3083821483"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 220
        },
        className: "jsx-3083821483"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("form", {
        name: "nameForm",
        onSubmit: function onSubmit(event) {
          return _this9.showMenu(event);
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 222
        },
        className: "jsx-3083821483"
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("label", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 223
        },
        className: "jsx-3083821483"
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("h3", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 224
        },
        className: "jsx-3083821483"
      }, "Recipe name"), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__material_ui_core_TextField___default.a, {
        onKeyPress: function onKeyPress(e) {
          if (e.key === 'Enter') e.preventDefault();
        },
        onChange: function onChange(event) {
          return _this9.changeName(event);
        },
        margin: "normal",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 225
        }
      }))), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 229
        },
        className: "jsx-3083821483"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 229
        },
        className: "jsx-3083821483"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("form", {
        name: "addForm",
        onSubmit: function onSubmit(event) {
          return _this9.showMenu(event);
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 231
        },
        className: "jsx-3083821483"
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("label", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 232
        },
        className: "jsx-3083821483"
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("h3", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 233
        },
        className: "jsx-3083821483"
      }, "Add ingredients"), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__material_ui_core_TextField___default.a, {
        onKeyPress: function onKeyPress(e) {
          if (e.key === 'Enter') e.preventDefault();
        },
        onChange: function onChange(event) {
          return _this9.showMenu(event);
        },
        margin: "normal",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 234
        }
      }))), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__material_ui_core_Button___default.a, {
        variant: "contained",
        color: "secondary",
        onClick: this.addIngredient,
        id: "addButton",
        style: {
          fontFamily: "Gentium Book Basic",
          fontWeight: "bold",
          fontSize: '16px'
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 239
        }
      }, "Pick ingredient"), this.state.listOpen ? __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        ref: function ref(element) {
          _this9.dropdownMenu = element;
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 244
        },
        className: "jsx-3083821483" + " " + "menu"
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(Listing, {
        textValue: this.state.textValue,
        onClicker: this.addIngredient,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 247
        }
      })) : __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 251
        },
        className: "jsx-3083821483"
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 251
        },
        className: "jsx-3083821483"
      })), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        "class": "inline",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 257
        },
        className: "jsx-3083821483"
      }, this.state.ingredtextlist.map(function (ingred) {
        return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__material_ui_core_Button___default.a, {
          variant: "outlined",
          onClick: _this9.RemoveIngred,
          key: ingred,
          key2: ingred,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 260
          }
        }, ingred);
      })), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 264
        },
        className: "jsx-3083821483"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 264
        },
        className: "jsx-3083821483"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 264
        },
        className: "jsx-3083821483"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("h3", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 267
        },
        className: "jsx-3083821483"
      }, "Enter recipe"), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__material_ui_core_TextField___default.a, {
        style: {
          width: 300
        },
        multiline: true,
        rows: 5,
        onChange: function onChange(event) {
          return _this9.changeDescription(event);
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 268
        }
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 270
        },
        className: "jsx-3083821483"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 270
        },
        className: "jsx-3083821483"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 270
        },
        className: "jsx-3083821483"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("h4", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 271
        },
        className: "jsx-3083821483"
      }, this.state.errorInfo), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__material_ui_core_Button___default.a, {
        variant: "contained",
        style: {
          fontFamily: "Montserrat",
          fontWeight: "bold",
          fontSize: '20px'
        },
        color: "primary",
        onClick: this.createRecipe,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 273
        }
      }, this.state.buttonInfo)), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a, {
        styleId: "3083821483",
        css: "h3.jsx-3083821483{font-family:\"Gentium Book Basic\",Times,serif;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBhZ2VzXFxjcmVhdGUuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBa1J3QixBQUswRCw2Q0FDakQiLCJmaWxlIjoicGFnZXNcXGNyZWF0ZS5qcyIsInNvdXJjZVJvb3QiOiJDOlxcVXNlcnNcXEFzZWVtXFxSZWFjdCBQcm9qZWN0c1xcRnJpZGdlaHVudGVycyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHdpdGhSb3V0ZXIgfSBmcm9tICduZXh0L3JvdXRlcidcclxuaW1wb3J0IExheW91dCBmcm9tICcuLi9jb21wb25lbnRzL015TGF5b3V0LmpzJ1xyXG5pbXBvcnQgZmV0Y2ggZnJvbSAnaXNvbW9ycGhpYy11bmZldGNoJ1xyXG5pbXBvcnQgTGluayBmcm9tICduZXh0L2xpbmsnXHJcbmltcG9ydCB1cmxuYW1lIGZyb20gJy4uL2NvbXBvbmVudHMvdXJsbmFtZS5qcydcclxuaW1wb3J0IEJ1dHRvbiBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9CdXR0b24nO1xyXG5pbXBvcnQgVGV4dEZpZWxkIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL1RleHRGaWVsZCc7XHJcbmltcG9ydCBMaXN0IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0xpc3QnO1xyXG5pbXBvcnQgTGlzdEl0ZW0gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvTGlzdEl0ZW0nO1xyXG5pbXBvcnQgTGlzdEl0ZW1UZXh0IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0xpc3RJdGVtVGV4dCc7XHJcbmltcG9ydCBEaXZpZGVyIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0RpdmlkZXInO1xyXG5jb25zdCBxdWVyeXN0cmluZyA9IHJlcXVpcmUoJ3F1ZXJ5c3RyaW5nJyk7XHJcblxyXG5cclxuY2xhc3MgTGlzdGluZyBleHRlbmRzIFJlYWN0LkNvbXBvbmVudHtcclxuICBjb25zdHJ1Y3Rvcihwcm9wcyl7XHJcbiAgICAgIHN1cGVyKHByb3BzKVxyXG4gICAgICBjb25zb2xlLmxvZyh0aGlzLnByb3BzLnRleHRWYWx1ZSlcclxuICAgICAgdGhpcy5zdGF0ZSA9IHtcclxuICAgICAgICBsaXN0OiBbXSxcclxuICAgICAgfVxyXG4gIH1cclxuXHJcbiAgY29tcG9uZW50V2lsbE1vdW50KCl7XHJcbiAgICB0aGlzLnNldFN0YXRlKHtcclxuICAgICAgICBcclxuICAgICAgICBsaXN0OiBbXCJMb2FkaW5nLi4uXCJdXHJcbiAgICB9KTtcclxuICAgIGZldGNoKHVybG5hbWUgKyBcIi9pbmdyZWRpZW50cz91bmFtZT1cIiArIGVuY29kZVVSSSh0aGlzLnByb3BzLnRleHRWYWx1ZSkpLnRoZW4ocmVzcG9uc2UgPT4gcmVzcG9uc2UudGV4dCgpKS50aGVuKGRhdGEgPT4ge1xyXG4gICAgICBjb25zb2xlLmxvZyhcIlNob3cgZGF0YSBmZXRjaGVkLiBDb3VudDogXCIgKyBkYXRhKVxyXG4gICAgICB2YXIgZGF0YWxpc3QgPSBkYXRhLnNwbGl0KFwiLFwiKTtcclxuICAgICAgaWYoZGF0YSA9PSBcIlwiKXtcclxuICAgICAgICB0aGlzLnNldFN0YXRlKHtcclxuICAgICAgICBcclxuICAgICAgICAgICAgbGlzdDogW11cclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgICBlbHNle1xyXG4gICAgICAgIHRoaXMuc2V0U3RhdGUoe1xyXG4gICAgICAgIFxyXG4gICAgICAgICAgICBsaXN0OiBkYXRhbGlzdFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcblxyXG4gICAgfSlcclxuICAgIFxyXG4gICAgICBcclxuICB9XHJcblxyXG4gIHJlbmRlcigpe1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IGFsaWduPVwiY2VudGVyXCI+XHJcbiAgICAgICAgPExpc3QgY29tcG9uZW50PVwibmF2XCIgIHN0eWxlID0ge3t3aWR0aDogMjUwfX0+PERpdmlkZXIgLz5cclxuICAgICAgICAgIHt0aGlzLnN0YXRlLmxpc3QubWFwKChpbmdyZWQpID0+ICg8ZGl2IGtleT17aW5ncmVkfT5cclxuICAgICAgICAgICAgPExpc3RJdGVtIGJ1dHRvbiBvbkNsaWNrPXt0aGlzLnByb3BzLm9uQ2xpY2tlcn0gY3VzdG9tdGV4dD17aW5ncmVkfT5cclxuICAgICAgICAgICAgICAgICAgPExpc3RJdGVtVGV4dCBwcmltYXJ5PXtpbmdyZWR9IC8+XHJcbiAgICAgICAgICAgICAgPC9MaXN0SXRlbT5cclxuICAgICAgICAgICAgICA8RGl2aWRlciAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9MaXN0PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKVxyXG4gIH1cclxuICBcclxufVxyXG5cclxuY2xhc3MgQ3JlYXRvciBleHRlbmRzIFJlYWN0LkNvbXBvbmVudHtcclxuXHJcbiAgY29uc3RydWN0b3IocHJvcHMpe1xyXG4gICAgc3VwZXIocHJvcHMpO1xyXG4gICAgdGhpcy5zdGF0ZSA9IHtcclxuICAgICAgbGlzdE9wZW46IGZhbHNlLFxyXG4gICAgICB0ZXh0VmFsdWU6IFwiXCIsXHJcbiAgICAgIGluZ3JlZHRleHRsaXN0OiBbXSxcclxuICAgICAgbmFtZTogXCJcIixcclxuICAgICAgZGVzY3JpcHRpb246IFwiXCIsXHJcbiAgICAgIGJ1dHRvbkluZm86IFwiQWRkIHJlY2lwZSFcIixcclxuICAgICAgZXJyb3JJbmZvOiBcIlwiXHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy5zaG93TWVudSA9IHRoaXMuc2hvd01lbnUuYmluZCh0aGlzKTtcclxuICAgIHRoaXMuY2xvc2VNZW51ID0gdGhpcy5jbG9zZU1lbnUuYmluZCh0aGlzKTtcclxuICAgIHRoaXMuUmVtb3ZlSW5ncmVkID0gdGhpcy5SZW1vdmVJbmdyZWQuYmluZCh0aGlzKTtcclxuICAgIHRoaXMuYWRkSW5ncmVkaWVudCA9IHRoaXMuYWRkSW5ncmVkaWVudC5iaW5kKHRoaXMpO1xyXG4gICAgdGhpcy5jaGFuZ2VOYW1lID0gdGhpcy5jaGFuZ2VOYW1lLmJpbmQodGhpcyk7XHJcbiAgICB0aGlzLmNoYW5nZURlc2NyaXB0aW9uID0gdGhpcy5jaGFuZ2VEZXNjcmlwdGlvbi5iaW5kKHRoaXMpO1xyXG4gICAgdGhpcy5jcmVhdGVSZWNpcGUgPSB0aGlzLmNyZWF0ZVJlY2lwZS5iaW5kKHRoaXMpO1xyXG4gIH1cclxuXHJcbiAgc2hvd01lbnUoZXZlbnQpe1xyXG4gICAgdGhpcy5zZXRTdGF0ZSh7XHJcbiAgICAgIGJ1dHRvbkluZm86IFwiQWRkIHJlY2lwZSFcIixcclxuICAgICAgZXJyb3JJbmZvOiBcIlwiXHJcbiAgICB9KVxyXG4gICAgaWYodGhpcy5zdGF0ZS5saXN0T3Blbil7XHJcbiAgICAgIHRoaXMuc2V0U3RhdGUoeyB0ZXh0VmFsdWU6IGV2ZW50LmN1cnJlbnRUYXJnZXQudmFsdWUudG9Mb3dlckNhc2UoKSwgbGlzdE9wZW46IGZhbHNlIH0sICgpID0+IHtcclxuICAgICAgICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignY2xpY2snLCB0aGlzLmNsb3NlTWVudSk7XHJcbiAgICAgICAgfSk7ICBcclxuICAgIH1cclxuICAgIGVsc2V7XHJcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSh7XHJcbiAgICAgICAgICB0ZXh0VmFsdWU6IGV2ZW50LmN1cnJlbnRUYXJnZXQudmFsdWUudG9Mb3dlckNhc2UoKSxcclxuICAgICAgICAgIGxpc3RPcGVuOiB0cnVlXHJcbiAgICAgICAgfSwgICgpID0+IHtcclxuICAgICAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgdGhpcy5jbG9zZU1lbnUpO1xyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBSZW1vdmVJbmdyZWQoZXZlbnQpe1xyXG4gICAgdmFyIGluZGV4ID0gKyh0aGlzLnN0YXRlLmluZ3JlZHRleHRsaXN0LmluZGV4T2YoZXZlbnQudGFyZ2V0LmdldEF0dHJpYnV0ZSgna2V5MicpKSk7XHJcbiAgICB2YXIgY2hhbmdlZEFycmF5ID0gdGhpcy5zdGF0ZS5pbmdyZWR0ZXh0bGlzdC5zbGljZSgpO1xyXG4gICAgY2hhbmdlZEFycmF5LnNwbGljZShpbmRleCwgMSk7XHJcbiAgICB0aGlzLnNldFN0YXRlKChwcmV2U3RhdGUsIHByb3BzKSA9PiB7cmV0dXJuIHtpbmdyZWR0ZXh0bGlzdDogY2hhbmdlZEFycmF5fX0pXHJcbiAgfVxyXG5cclxuICBhZGRJbmdyZWRpZW50KGV2ZW50KXtcclxuICAgIGV2ZW50LnBlcnNpc3QoKTtcclxuICAgIHZhciBjdXN0b20gPSBldmVudC5jdXJyZW50VGFyZ2V0LmdldEF0dHJpYnV0ZSgnY3VzdG9tdGV4dCcpXHJcbiAgICB2YXIgdG1wYXJyID0gdGhpcy5zdGF0ZS5pbmdyZWR0ZXh0bGlzdC5zbGljZSgpLmNvbmNhdChbY3VzdG9tXSk7XHJcblxyXG4gICAgaWYoZXZlbnQuY3VycmVudFRhcmdldC5pZCA9PSBcImFkZEJ1dHRvblwiKXtcclxuICAgICAgaWYodGhpcy5zdGF0ZS50ZXh0VmFsdWUgPT0gXCJcIil7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpZih0aGlzLnN0YXRlLmluZ3JlZHRleHRsaXN0LmZpbmRJbmRleChpbmcgPT4gaW5nID09IHRoaXMuc3RhdGUudGV4dFZhbHVlKSA9PSAtMSl7XHJcbiAgICAgICAgLy90aGlzLnNldFN0YXRlKChwcmV2U3RhdGUsIHByb3BzKSA9PiB7cmV0dXJuIHtpbmdyZWRsaXN0OiBwcmV2U3RhdGUuaW5ncmVkbGlzdC5jb25jYXQoWyhcclxuICAgICAgICAgIC8vPGgxIG9uQ2xpY2s9e3RoaXMuUmVtb3ZlSW5ncmVkfSBrZXk9e3RoaXMuc3RhdGUudGV4dFZhbHVlfT57dGhpcy5zdGF0ZS50ZXh0VmFsdWV9PC9oMT5cclxuICAgICAgICAvLyldKX19KVxyXG5cclxuICAgICAgICB0bXBhcnIgPSB0aGlzLnN0YXRlLmluZ3JlZHRleHRsaXN0LnNsaWNlKCkuY29uY2F0KFt0aGlzLnN0YXRlLnRleHRWYWx1ZV0pO1xyXG5cclxuICAgICAgICB0aGlzLnNldFN0YXRlKChwcmV2U3RhdGUsIHByb3BzKSA9PiB7cmV0dXJuIHtpbmdyZWR0ZXh0bGlzdDogdG1wYXJyfX0pXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIFxyXG4gICAgfVxyXG5cclxuICAgIGVsc2V7XHJcbiAgICAgIHRoaXMuc2V0U3RhdGUoeyBsaXN0T3BlbjogZmFsc2UgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdjbGljaycsIHRoaXMuY2xvc2VNZW51KTtcclxuICAgICAgICB9KTsgIFxyXG4gICAgICAgIC8vaWYodGhpcy5zdGF0ZS5pbmdyZWRsaXN0LmZpbmRJbmRleChpbmcgPT4gaW5nLmtleSA9PSBldmVudC50YXJnZXQuZ2V0QXR0cmlidXRlKCdjdXN0b210ZXh0JykpID09IC0xKXtcclxuICAgICAgICBpZih0aGlzLnN0YXRlLmluZ3JlZHRleHRsaXN0LmZpbmRJbmRleChpbmcgPT4gaW5nID09IGN1c3RvbSkgPT0gLTEpe1xyXG4gICAgICAgIC8vdGhpcy5zZXRTdGF0ZSgocHJldlN0YXRlLCBwcm9wcykgPT4ge3JldHVybiB7aW5ncmVkbGlzdDogcHJldlN0YXRlLmluZ3JlZGxpc3QuY29uY2F0KFsoXHJcbiAgICAgICAgLy88aDEgb25DbGljaz17dGhpcy5SZW1vdmVJbmdyZWR9IGtleT17ZXZlbnQudGFyZ2V0LmdldEF0dHJpYnV0ZSgnY3VzdG9tdGV4dCcpfT57ZXZlbnQudGFyZ2V0LmdldEF0dHJpYnV0ZSgnY3VzdG9tdGV4dCcpfTwvaDE+XHJcbiAgICAgICAgLy8pXSl9fSlcclxuXHJcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSgocHJldlN0YXRlLCBwcm9wcykgPT4ge3JldHVybiB7aW5ncmVkdGV4dGxpc3Q6IHRtcGFycn19KVxyXG4gICAgICB9XHJcbiAgICAgIFxyXG4gICAgICBcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGNsb3NlTWVudShldmVudCkge1xyXG4gICAgXHJcbiAgICAgIGlmICghdGhpcy5kcm9wZG93bk1lbnUuY29udGFpbnMoZXZlbnQudGFyZ2V0KSkge1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuc2V0U3RhdGUoeyBsaXN0T3BlbjogZmFsc2UgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignY2xpY2snLCB0aGlzLmNsb3NlTWVudSk7XHJcbiAgICAgICAgfSk7ICBcclxuICAgICAgICBcclxuICAgICAgfVxyXG4gIH1cclxuXHJcbiAgY2hhbmdlTmFtZShldmVudCl7XHJcbiAgICB0aGlzLnNldFN0YXRlKHtcclxuICAgICAgYnV0dG9uSW5mbzogXCJBZGQgcmVjaXBlIVwiLFxyXG4gICAgICBlcnJvckluZm86IFwiXCIsXHJcbiAgICAgIG5hbWU6IGV2ZW50LmN1cnJlbnRUYXJnZXQudmFsdWVcclxuICAgIH0pXHJcbiAgfVxyXG5cclxuICBjaGFuZ2VEZXNjcmlwdGlvbihldmVudCl7XHJcbiAgICB0aGlzLnNldFN0YXRlKHtcclxuICAgICAgYnV0dG9uSW5mbzogXCJBZGQgcmVjaXBlIVwiLFxyXG4gICAgICBlcnJvckluZm86IFwiXCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBldmVudC5jdXJyZW50VGFyZ2V0LnZhbHVlXHJcbiAgICB9KVxyXG4gIH1cclxuXHJcbiAgY3JlYXRlUmVjaXBlKCl7XHJcbiAgICBpZih0aGlzLnN0YXRlLm5hbWUgPT0gXCJcIiB8fCB0aGlzLnN0YXRlLmRlc2NyaXB0aW9uID09IFwiXCIgfHwgdGhpcy5zdGF0ZS5pbmdyZWR0ZXh0bGlzdCA9PSBbXSl7XHJcbiAgICAgIHRoaXMuc2V0U3RhdGUoe1xyXG4gICAgICAgIGVycm9ySW5mbzogXCJPbmUgb3IgbW9yZSBmaWVsZHMgaXMgbGVmdCBibGFuay4gVHJ5IGFnYWluLlwiXHJcbiAgICAgIH0pXHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICB2YXIgcGFyYW1zID0ge1xyXG4gICAgICB1bmFtZTogdGhpcy5zdGF0ZS5uYW1lLFxyXG4gICAgICB1bGlzdDogdGhpcy5zdGF0ZS5pbmdyZWR0ZXh0bGlzdC50b1N0cmluZygpLFxyXG4gICAgICB1ZGVzYzogdGhpcy5zdGF0ZS5kZXNjcmlwdGlvblxyXG4gICAgfVxyXG5cclxuICAgIHZhciBxdWVyeUFkZCA9IHF1ZXJ5c3RyaW5nLnN0cmluZ2lmeShwYXJhbXMpO1xyXG5cclxuICAgIGZldGNoKHVybG5hbWUgKyBcIi9yZWNpcGVzXCIsIHttZXRob2Q6ICdQT1NUJywgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nfSwgYm9keTogSlNPTi5zdHJpbmdpZnkocGFyYW1zKX0pLnRoZW4ocmVzcG9uc2UgPT4gcmVzcG9uc2UudGV4dCgpKS50aGVuKGRhdGEgPT4ge1xyXG4gICAgICBpZihkYXRhID09IFwiUmVjaXBlIGV4aXN0c1wiKXtcclxuICAgICAgICB0aGlzLnNldFN0YXRlKHtcclxuICAgICAgICAgIGVycm9ySW5mbzogXCJSZWNpcGUgbmFtZSBleGlzdHMuIFRyeSBhZ2Fpbi5cIlxyXG4gICAgICAgIH0pXHJcbiAgICAgIH1cclxuICAgICAgZWxzZXtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIkFkZGVkIHJlY2lwZSBcIiArIGRhdGEpXHJcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSh7XHJcbiAgICAgICAgICBidXR0b25JbmZvOiBcIlJlY2lwZSBhZGRlZCFcIlxyXG4gICAgICAgIH0pXHJcbiAgICAgIH1cclxuICAgICAgXHJcbiAgICB9KVxyXG4gIH1cclxuXHJcbiAgcmVuZGVyKCl7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2PlxyXG4gICAgICA8ZGl2IGFsaWduPVwiY2VudGVyXCI+PGJyLz48YnIvPlxyXG5cclxuICAgICAgPGZvcm0gbmFtZT1cIm5hbWVGb3JtXCIgb25TdWJtaXQ9eyhldmVudCkgPT4gdGhpcy5zaG93TWVudShldmVudCl9PlxyXG4gICAgICAgIDxsYWJlbD5cclxuICAgICAgICAgIDxoMz5SZWNpcGUgbmFtZTwvaDM+IFxyXG4gICAgICAgICAgPFRleHRGaWVsZCAgb25LZXlQcmVzcz17ZSA9PiB7aWYgKGUua2V5ID09PSAnRW50ZXInKSBlLnByZXZlbnREZWZhdWx0KCk7fX0gb25DaGFuZ2U9eyhldmVudCkgPT4gdGhpcy5jaGFuZ2VOYW1lKGV2ZW50KX0gbWFyZ2luPVwibm9ybWFsXCIgLz5cclxuICAgICAgICA8L2xhYmVsPlxyXG4gICAgICA8L2Zvcm0+XHJcblxyXG4gICAgICA8YnIvPjxici8+XHJcblxyXG4gICAgICA8Zm9ybSBuYW1lPVwiYWRkRm9ybVwiIG9uU3VibWl0PXsoZXZlbnQpID0+IHRoaXMuc2hvd01lbnUoZXZlbnQpfT5cclxuICAgICAgICA8bGFiZWw+XHJcbiAgICAgICAgICAgIDxoMz5BZGQgaW5ncmVkaWVudHM8L2gzPlxyXG4gICAgICAgICAgICA8VGV4dEZpZWxkICBvbktleVByZXNzPXtlID0+IHtpZiAoZS5rZXkgPT09ICdFbnRlcicpIGUucHJldmVudERlZmF1bHQoKTt9fSBvbkNoYW5nZT17KGV2ZW50KSA9PiB0aGlzLnNob3dNZW51KGV2ZW50KX0gbWFyZ2luPVwibm9ybWFsXCIgLz5cclxuICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICBcclxuICAgICAgPC9mb3JtPlxyXG5cclxuICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiY29udGFpbmVkXCIgY29sb3I9XCJzZWNvbmRhcnlcIiBvbkNsaWNrPXt0aGlzLmFkZEluZ3JlZGllbnR9IGlkPVwiYWRkQnV0dG9uXCIgIHN0eWxlPXt7IGZvbnRGYW1pbHk6IFwiR2VudGl1bSBCb29rIEJhc2ljXCIsIGZvbnRXZWlnaHQ6IFwiYm9sZFwiLCBmb250U2l6ZTogJzE2cHgnIH19PlBpY2sgaW5ncmVkaWVudDwvQnV0dG9uPlxyXG4gICAgICBcclxuICAgICAgeyBcclxuICAgICAgICB0aGlzLnN0YXRlLmxpc3RPcGVuIFxyXG4gICAgICAgID8oXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZW51XCIgcmVmPXsoZWxlbWVudCkgPT4ge1xyXG4gICAgICAgICAgdGhpcy5kcm9wZG93bk1lbnUgPSBlbGVtZW50O1xyXG4gICAgICAgIH19PlxyXG4gICAgICAgICAgPExpc3RpbmcgdGV4dFZhbHVlPXt0aGlzLnN0YXRlLnRleHRWYWx1ZX0gb25DbGlja2VyPXt0aGlzLmFkZEluZ3JlZGllbnR9Lz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICApXHJcbiAgICAgICAgOihcclxuICAgICAgICA8ZGl2Pjxici8+PC9kaXY+XHJcbiAgICAgICAgKVxyXG4gICAgICB9XHJcblxyXG4gICAgICBcclxuICAgICAgXHJcbiAgICAgIDxkaXYgY2xhc3M9XCJpbmxpbmVcIj5cclxuICAgICAge1xyXG4gICAgICAgIHRoaXMuc3RhdGUuaW5ncmVkdGV4dGxpc3QubWFwKGluZ3JlZCA9PiAoXHJcbiAgICAgICAgICA8QnV0dG9uICB2YXJpYW50PVwib3V0bGluZWRcIiBvbkNsaWNrPXt0aGlzLlJlbW92ZUluZ3JlZH0ga2V5PXtpbmdyZWR9IGtleTI9e2luZ3JlZH0+e2luZ3JlZH08L0J1dHRvbj5cclxuICAgICAgICApXHJcbiAgICAgICAgKVxyXG4gICAgICB9XHJcbiAgICAgIDwvZGl2Pjxici8+PGJyLz48YnIvPlxyXG5cclxuXHJcbiAgICAgIDxoMz5FbnRlciByZWNpcGU8L2gzPiBcclxuICAgICAgPFRleHRGaWVsZCAgc3R5bGU9e3t3aWR0aDogMzAwfX0gbXVsdGlsaW5lPXt0cnVlfSByb3dzPXs1fSBvbkNoYW5nZT17KGV2ZW50KSA9PiB0aGlzLmNoYW5nZURlc2NyaXB0aW9uKGV2ZW50KX0gLz5cclxuXHJcbiAgICAgIDxici8+PGJyLz48YnIvPlxyXG4gICAgICA8aDQ+e3RoaXMuc3RhdGUuZXJyb3JJbmZvfTwvaDQ+XHJcblxyXG4gICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJjb250YWluZWRcIiBzdHlsZT17e2ZvbnRGYW1pbHk6IFwiTW9udHNlcnJhdFwiLCBmb250V2VpZ2h0OiBcImJvbGRcIiwgZm9udFNpemU6ICcyMHB4JyB9fSBjb2xvcj1cInByaW1hcnlcIiBvbkNsaWNrPXt0aGlzLmNyZWF0ZVJlY2lwZX0+e3RoaXMuc3RhdGUuYnV0dG9uSW5mb308L0J1dHRvbj5cclxuXHJcbiAgICAgIDwvZGl2PjxzdHlsZSBqc3g+e2BcclxuIFxyXG5cclxuICAgICAgICBoMyB7XHJcbiAgICAgICAgICBmb250LWZhbWlseTogXCJHZW50aXVtIEJvb2sgQmFzaWNcIiwgVGltZXMsIHNlcmlmO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgYH08L3N0eWxlPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIClcclxuICB9XHJcbn1cclxuXHJcbmNvbnN0IEZpcnN0ID0gIChwcm9wcykgPT4gKFxyXG4gIDxMYXlvdXQ+XHJcbiAgICA8Q3JlYXRvci8+XHJcbiAgPC9MYXlvdXQ+XHJcbilcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEZpcnN0Il19 */\n/*@ sourceURL=pages\\create.js */"
      }));
    }
  }]);

  return Creator;
}(__WEBPACK_IMPORTED_MODULE_1_react___default.a.Component);

var First = function First(props) {
  return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__components_MyLayout_js__["a" /* default */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 289
    }
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(Creator, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 290
    }
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (First);

/***/ }),

/***/ 5:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("./pages/create.js");


/***/ }),

/***/ "@material-ui/core/AppBar":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/AppBar");

/***/ }),

/***/ "@material-ui/core/Button":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Button");

/***/ }),

/***/ "@material-ui/core/Divider":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Divider");

/***/ }),

/***/ "@material-ui/core/List":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/List");

/***/ }),

/***/ "@material-ui/core/ListItem":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/ListItem");

/***/ }),

/***/ "@material-ui/core/ListItemText":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/ListItemText");

/***/ }),

/***/ "@material-ui/core/TextField":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/TextField");

/***/ }),

/***/ "@material-ui/core/Toolbar":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Toolbar");

/***/ }),

/***/ "@material-ui/core/styles":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ "isomorphic-unfetch":
/***/ (function(module, exports) {

module.exports = require("isomorphic-unfetch");

/***/ }),

/***/ "next/head":
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "next/link":
/***/ (function(module, exports) {

module.exports = require("next/link");

/***/ }),

/***/ "next/router":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "querystring":
/***/ (function(module, exports) {

module.exports = require("querystring");

/***/ }),

/***/ "react":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "styled-jsx/style":
/***/ (function(module, exports) {

module.exports = require("styled-jsx/style");

/***/ })

/******/ });
//# sourceMappingURL=create.js.map