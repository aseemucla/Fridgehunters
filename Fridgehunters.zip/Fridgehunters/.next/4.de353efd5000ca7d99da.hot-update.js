webpackHotUpdate(4,{

/***/ "./pages/hot.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style__ = __webpack_require__("./node_modules/styled-jsx/style.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__("./node_modules/react/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_next_router__ = __webpack_require__("./node_modules/next/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_next_router___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_next_router__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__components_MyLayout_js__ = __webpack_require__("./components/MyLayout.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_isomorphic_unfetch__ = __webpack_require__("./node_modules/isomorphic-unfetch/browser.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_isomorphic_unfetch___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_isomorphic_unfetch__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_next_link__ = __webpack_require__("./node_modules/next/link.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_next_link___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_next_link__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__components_urlname_js__ = __webpack_require__("./components/urlname.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__material_ui_core_Button__ = __webpack_require__("./node_modules/@material-ui/core/Button/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__material_ui_core_Button___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7__material_ui_core_Button__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__material_ui_core_Chip__ = __webpack_require__("./node_modules/@material-ui/core/Chip/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__material_ui_core_Chip___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_8__material_ui_core_Chip__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__material_ui_core_Card__ = __webpack_require__("./node_modules/@material-ui/core/Card/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__material_ui_core_Card___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_9__material_ui_core_Card__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__material_ui_core_CardActions__ = __webpack_require__("./node_modules/@material-ui/core/CardActions/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__material_ui_core_CardActions___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_10__material_ui_core_CardActions__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__material_ui_core_CardContent__ = __webpack_require__("./node_modules/@material-ui/core/CardContent/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__material_ui_core_CardContent___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_11__material_ui_core_CardContent__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__material_ui_core_Typography__ = __webpack_require__("./node_modules/@material-ui/core/Typography/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__material_ui_core_Typography___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_12__material_ui_core_Typography__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__material_ui_core_Badge__ = __webpack_require__("./node_modules/@material-ui/core/Badge/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__material_ui_core_Badge___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_13__material_ui_core_Badge__);
var _jsxFileName = "C:\\Users\\Aseem\\React Projects\\Fridgehunters\\pages\\hot.js";



function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }














var RecipeList =
/*#__PURE__*/
function (_React$Component) {
  _inherits(RecipeList, _React$Component);

  function RecipeList(props) {
    var _this;

    _classCallCheck(this, RecipeList);

    _this = _possibleConstructorReturn(this, (RecipeList.__proto__ || Object.getPrototypeOf(RecipeList)).call(this, props));
    _this.addEndorsement = _this.addEndorsement.bind(_assertThisInitialized(_this));
    _this.state = {
      recipes: [],
      endorsedrecipes: []
    };
    __WEBPACK_IMPORTED_MODULE_4_isomorphic_unfetch___default()(__WEBPACK_IMPORTED_MODULE_6__components_urlname_js__["a" /* default */] + "/?desiredMethod=HOTALLTIME").then(function (response) {
      return response.text();
    }).then(function (datas) {
      var data = JSON.parse("[" + datas + "]"); //console.log("Show data fetched. Count: " + JSON.stringify(data))

      _this.setState({
        recipes: data
      });
    });
    return _this;
  }

  _createClass(RecipeList, [{
    key: "addEndorsement",
    value: function addEndorsement(event) {
      var _this2 = this;

      var index = this.state.endorsedrecipes.indexOf(event.currentTarget.getAttribute('key2'));
      var temprec = event.currentTarget.getAttribute('key2');
      var tempendorselist = this.state.endorsedrecipes.slice().concat([temprec]);

      if (index == -1) {
        this.setState(function (prevState, props) {
          return {
            endorsedrecipes: tempendorselist
          };
        });
        __WEBPACK_IMPORTED_MODULE_4_isomorphic_unfetch___default()(__WEBPACK_IMPORTED_MODULE_6__components_urlname_js__["a" /* default */] + "/?desiredMethod=ENDORSE&uname=" + temprec).then(function (response) {
          return response.text();
        }).then(function (data) {
          console.log(data);
          return 1;
        }).then(function (useless) {
          __WEBPACK_IMPORTED_MODULE_4_isomorphic_unfetch___default()(__WEBPACK_IMPORTED_MODULE_6__components_urlname_js__["a" /* default */] + "/?desiredMethod=HOTALLTIME").then(function (response) {
            return response.text();
          }).then(function (datas) {
            var data = JSON.parse("[" + datas + "]");
            console.log("Coming second"); //console.log("Show data fetched. Count: " + JSON.stringify(data))

            _this2.setState({
              recipes: data
            });
          });
        });
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 58
        },
        className: "jsx-429575055"
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        align: "center",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 59
        },
        className: "jsx-429575055"
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 59
        },
        className: "jsx-429575055"
      }), this.state.recipes.map(function (recipe) {
        return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 62
          },
          className: "jsx-429575055"
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__material_ui_core_Card___default.a, {
          style: {
            maxWidth: 450,
            backgroundColor: '#b3ffb3'
          },
          __source: {
            fileName: _jsxFileName,
            lineNumber: 62
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_11__material_ui_core_CardContent___default.a, {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 63
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_12__material_ui_core_Typography___default.a, {
          gutterBottom: true,
          variant: "headline",
          component: "h1",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 64
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("h2", {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 65
          },
          className: "jsx-429575055"
        }, recipe.name)), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_12__material_ui_core_Typography___default.a, {
          component: "p",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 67
          }
        }, recipe.ingredients.map(function (ingred) {
          return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__material_ui_core_Chip___default.a, {
            label: ingred,
            __source: {
              fileName: _jsxFileName,
              lineNumber: 69
            }
          });
        })), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_12__material_ui_core_Typography___default.a, {
          component: "p",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 72
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 72
          },
          className: "jsx-429575055"
        }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("p", {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 73
          },
          className: "jsx-429575055"
        }, recipe.description)), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_12__material_ui_core_Typography___default.a, {
          component: "p",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 76
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 76
          },
          className: "jsx-429575055"
        }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 76
          },
          className: "jsx-429575055"
        }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_13__material_ui_core_Badge___default.a, {
          color: "secondary",
          badgeContent: recipe.endorse,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 77
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__material_ui_core_Button___default.a, {
          size: "small",
          variant: "contained",
          color: "primary",
          key2: recipe.name,
          style: {
            fontFamily: "Gentium Book Basic",
            fontWeight: "bold",
            fontSize: '15px'
          },
          onClick: _this3.addEndorsement,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 78
          }
        }, _this3.state.endorsedrecipes.indexOf(recipe.name) == -1 ? "Endorse" : "Added endorsement")))), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_10__material_ui_core_CardActions___default.a, {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 84
          }
        })), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 86
          },
          className: "jsx-429575055"
        }));
      })), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a, {
        styleId: "429575055",
        css: "h2.jsx-429575055{font-family:\"Gentium Book Basic\",Times,serif;}p.jsx-429575055{font-family:\"Noto Sans\",Times,serif;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBhZ2VzXFxob3QuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBeUZ3QixBQUswRCxBQUlULG9DQUN4QyxTQUpBIiwiZmlsZSI6InBhZ2VzXFxob3QuanMiLCJzb3VyY2VSb290IjoiQzpcXFVzZXJzXFxBc2VlbVxcUmVhY3QgUHJvamVjdHNcXEZyaWRnZWh1bnRlcnMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB3aXRoUm91dGVyIH0gZnJvbSAnbmV4dC9yb3V0ZXInXHJcbmltcG9ydCBMYXlvdXQgZnJvbSAnLi4vY29tcG9uZW50cy9NeUxheW91dC5qcydcclxuaW1wb3J0IGZldGNoIGZyb20gJ2lzb21vcnBoaWMtdW5mZXRjaCdcclxuaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJ1xyXG5pbXBvcnQgdXJsbmFtZSBmcm9tICcuLi9jb21wb25lbnRzL3VybG5hbWUuanMnXHJcbmltcG9ydCBCdXR0b24gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvQnV0dG9uJztcclxuaW1wb3J0IENoaXAgZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvQ2hpcCc7XHJcbmltcG9ydCBDYXJkIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0NhcmQnO1xyXG5pbXBvcnQgQ2FyZEFjdGlvbnMgZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvQ2FyZEFjdGlvbnMnO1xyXG5pbXBvcnQgQ2FyZENvbnRlbnQgZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvQ2FyZENvbnRlbnQnO1xyXG5pbXBvcnQgVHlwb2dyYXBoeSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9UeXBvZ3JhcGh5JztcclxuaW1wb3J0IEJhZGdlIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0JhZGdlJztcclxuXHJcbmNsYXNzIFJlY2lwZUxpc3QgZXh0ZW5kcyBSZWFjdC5Db21wb25lbnR7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByb3BzKXtcclxuICAgIHN1cGVyKHByb3BzKTtcclxuICAgIHRoaXMuYWRkRW5kb3JzZW1lbnQgPSB0aGlzLmFkZEVuZG9yc2VtZW50LmJpbmQodGhpcyk7XHJcbiAgICB0aGlzLnN0YXRlID0ge1xyXG4gICAgICByZWNpcGVzOiBbXSxcclxuICAgICAgZW5kb3JzZWRyZWNpcGVzOiBbXVxyXG4gICAgfVxyXG5cclxuICAgIGZldGNoKHVybG5hbWUgKyBcIi8/ZGVzaXJlZE1ldGhvZD1IT1RBTExUSU1FXCIpLnRoZW4ocmVzcG9uc2UgPT4gcmVzcG9uc2UudGV4dCgpKS50aGVuKGRhdGFzID0+IHtcclxuICAgICAgdmFyIGRhdGEgPSBKU09OLnBhcnNlKFwiW1wiICsgZGF0YXMgICsgXCJdXCIpXHJcbiAgICAgIC8vY29uc29sZS5sb2coXCJTaG93IGRhdGEgZmV0Y2hlZC4gQ291bnQ6IFwiICsgSlNPTi5zdHJpbmdpZnkoZGF0YSkpXHJcbiAgICAgIHRoaXMuc2V0U3RhdGUoe1xyXG4gICAgICAgIHJlY2lwZXM6IGRhdGFcclxuICAgICAgfSlcclxuICAgIH0pXHJcbiAgfVxyXG5cclxuICBhZGRFbmRvcnNlbWVudChldmVudCl7XHJcbiAgICB2YXIgaW5kZXggPSB0aGlzLnN0YXRlLmVuZG9yc2VkcmVjaXBlcy5pbmRleE9mKGV2ZW50LmN1cnJlbnRUYXJnZXQuZ2V0QXR0cmlidXRlKCdrZXkyJykpO1xyXG4gICAgdmFyIHRlbXByZWMgPSBldmVudC5jdXJyZW50VGFyZ2V0LmdldEF0dHJpYnV0ZSgna2V5MicpO1xyXG4gICAgdmFyIHRlbXBlbmRvcnNlbGlzdCA9IHRoaXMuc3RhdGUuZW5kb3JzZWRyZWNpcGVzLnNsaWNlKCkuY29uY2F0KFt0ZW1wcmVjXSlcclxuXHJcbiAgICBpZihpbmRleCA9PSAtMSl7XHJcbiAgICAgIFxyXG4gICAgICB0aGlzLnNldFN0YXRlKChwcmV2U3RhdGUsIHByb3BzKSA9PiB7cmV0dXJuIHtlbmRvcnNlZHJlY2lwZXM6IHRlbXBlbmRvcnNlbGlzdH19KVxyXG4gICAgICBmZXRjaCh1cmxuYW1lICsgXCIvP2Rlc2lyZWRNZXRob2Q9RU5ET1JTRSZ1bmFtZT1cIiArIHRlbXByZWMpLnRoZW4ocmVzcG9uc2UgPT4gcmVzcG9uc2UudGV4dCgpKS50aGVuKGRhdGEgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGRhdGEpXHJcbiAgICAgICAgcmV0dXJuIDE7XHJcbiAgICAgIH0pLnRoZW4odXNlbGVzcyA9PiB7ZmV0Y2godXJsbmFtZSArIFwiLz9kZXNpcmVkTWV0aG9kPUhPVEFMTFRJTUVcIikudGhlbihyZXNwb25zZSA9PiByZXNwb25zZS50ZXh0KCkpLnRoZW4oZGF0YXMgPT4ge1xyXG4gICAgICAgIHZhciBkYXRhID0gSlNPTi5wYXJzZShcIltcIiArIGRhdGFzICArIFwiXVwiKVxyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiQ29taW5nIHNlY29uZFwiKVxyXG4gICAgICAgIC8vY29uc29sZS5sb2coXCJTaG93IGRhdGEgZmV0Y2hlZC4gQ291bnQ6IFwiICsgSlNPTi5zdHJpbmdpZnkoZGF0YSkpXHJcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSh7XHJcbiAgICAgICAgICByZWNpcGVzOiBkYXRhXHJcbiAgICAgICAgfSlcclxuICAgICAgfSlcclxuICAgICAgfSlcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHJlbmRlcigpe1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdj5cclxuICAgICAgPGRpdiBhbGlnbj1cImNlbnRlclwiPjxici8+XHJcblxyXG4gICAgICB7XHJcbiAgICAgICAgdGhpcy5zdGF0ZS5yZWNpcGVzLm1hcChyZWNpcGUgPT4gKDxkaXY+PENhcmQgc3R5bGU9e3ttYXhXaWR0aDogNDUwLCAgYmFja2dyb3VuZENvbG9yOiAnI2IzZmZiMyd9fSA+XHJcbiAgICAgICAgICA8Q2FyZENvbnRlbnQ+XHJcbiAgICAgICAgICAgIDxUeXBvZ3JhcGh5IGd1dHRlckJvdHRvbSB2YXJpYW50PVwiaGVhZGxpbmVcIiBjb21wb25lbnQ9XCJoMVwiPlxyXG4gICAgICAgICAgICAgIDxoMj57cmVjaXBlLm5hbWV9PC9oMj5cclxuICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICA8VHlwb2dyYXBoeSBjb21wb25lbnQ9XCJwXCI+XHJcbiAgICAgICAgICAgICAge3JlY2lwZS5pbmdyZWRpZW50cy5tYXAoaW5ncmVkID0+IChcclxuICAgICAgICAgICAgICAgIDxDaGlwIGxhYmVsPXtpbmdyZWR9IC8+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgPFR5cG9ncmFwaHkgY29tcG9uZW50PVwicFwiPjxici8+XHJcbiAgICAgICAgICAgICAgPHA+e3JlY2lwZS5kZXNjcmlwdGlvbn08L3A+XHJcbiAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICBcclxuICAgICAgICAgICAgPFR5cG9ncmFwaHkgY29tcG9uZW50PVwicFwiPjxici8+PGJyLz5cclxuICAgICAgICAgICAgICA8QmFkZ2UgY29sb3I9XCJzZWNvbmRhcnlcIiBiYWRnZUNvbnRlbnQ9e3JlY2lwZS5lbmRvcnNlfT5cclxuICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbWFsbFwiICB2YXJpYW50PVwiY29udGFpbmVkXCIgIGNvbG9yPVwicHJpbWFyeVwiIGtleTI9e3JlY2lwZS5uYW1lfSAgc3R5bGU9e3sgZm9udEZhbWlseTogXCJHZW50aXVtIEJvb2sgQmFzaWNcIiwgZm9udFdlaWdodDogXCJib2xkXCIsIGZvbnRTaXplOiAnMTVweCcgfX0gb25DbGljaz17dGhpcy5hZGRFbmRvcnNlbWVudH0+XHJcbiAgICAgICAgICAgICAgICB7KHRoaXMuc3RhdGUuZW5kb3JzZWRyZWNpcGVzLmluZGV4T2YocmVjaXBlLm5hbWUpID09IC0xKSA/IFwiRW5kb3JzZVwiIDogXCJBZGRlZCBlbmRvcnNlbWVudFwifVxyXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvQmFkZ2U+XHJcbiAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgIDwvQ2FyZENvbnRlbnQ+XHJcbiAgICAgICAgICA8Q2FyZEFjdGlvbnM+XHJcbiAgICAgICAgICA8L0NhcmRBY3Rpb25zPlxyXG4gICAgICAgIDwvQ2FyZD48YnIvPjwvZGl2PilcclxuICAgICAgICApXHJcbiAgICAgIH1cclxuICAgICAgXHJcbiAgICAgIDwvZGl2PjxzdHlsZSBqc3g+e2BcclxuICAgICAgICBcclxuXHJcbiAgICAgICAgaDIge1xyXG4gICAgICAgICAgZm9udC1mYW1pbHk6IFwiR2VudGl1bSBCb29rIEJhc2ljXCIsIFRpbWVzLCBzZXJpZjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHAge1xyXG4gICAgICAgICAgZm9udC1mYW1pbHk6IFwiTm90byBTYW5zXCIsIFRpbWVzLCBzZXJpZjtcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgIGB9PC9zdHlsZT5cclxuICAgICAgPC9kaXY+XHJcbiAgICApXHJcbiAgfVxyXG59XHJcblxyXG5jb25zdCBGaXJzdCA9ICAocHJvcHMpID0+IChcclxuICA8TGF5b3V0PlxyXG4gICAgPFJlY2lwZUxpc3QgLz5cclxuICA8L0xheW91dD5cclxuKVxyXG5leHBvcnQgZGVmYXVsdCBGaXJzdCJdfQ== */\n/*@ sourceURL=pages\\hot.js */"
      }));
    }
  }]);

  return RecipeList;
}(__WEBPACK_IMPORTED_MODULE_1_react___default.a.Component);

var First = function First(props) {
  return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__components_MyLayout_js__["a" /* default */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 108
    }
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(RecipeList, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 109
    }
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (First);
    (function (Component, route) {
      if(!Component) return
      if (false) return
      module.hot.accept()
      Component.__route = route

      if (module.hot.status() === 'idle') return

      var components = next.router.components
      for (var r in components) {
        if (!components.hasOwnProperty(r)) continue

        if (components[r].Component.__route === route) {
          next.router.update(r, Component)
        }
      }
    })(typeof __webpack_exports__ !== 'undefined' ? __webpack_exports__.default : (module.exports.default || module.exports), "/hot")
  
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__("./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=4.de353efd5000ca7d99da.hot-update.js.map