webpackHotUpdate(5,{

/***/ "./components/Header.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style__ = __webpack_require__("./node_modules/styled-jsx/style.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__("./node_modules/react/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_next_link__ = __webpack_require__("./node_modules/next/link.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_next_link___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_next_link__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__material_ui_core_AppBar__ = __webpack_require__("./node_modules/@material-ui/core/AppBar/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__material_ui_core_AppBar___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3__material_ui_core_AppBar__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__material_ui_core_Toolbar__ = __webpack_require__("./node_modules/@material-ui/core/Toolbar/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__material_ui_core_Toolbar___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4__material_ui_core_Toolbar__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__material_ui_core_Button__ = __webpack_require__("./node_modules/@material-ui/core/Button/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__material_ui_core_Button___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5__material_ui_core_Button__);
var _jsxFileName = "C:\\Users\\Aseem\\React Projects\\Fridgehunters\\components\\Header.js";





 //import "typeface-lobster";

var linkStyle = {
  marginRight: 15,
  border: '2px solid #DDD'
};

var Header = function Header() {
  return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 14
    },
    className: "jsx-187386659"
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("h1", {
    align: "center",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 15
    },
    className: "jsx-187386659"
  }, "Fridgehunters"), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a, {
    styleId: "187386659",
    css: "@import url('https://fonts.googleapis.com/css?family=Lobster');@fontface{font-family:'Lobster',cursive;src:url('https://fonts.googleapis.com/css?family=Lobster');}h1.jsx-187386659{font-family:\"Lobster\",Times,serif;font-size:54px;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbXBvbmVudHNcXEhlYWRlci5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFjc0QsQUFFdUUsQUFHN0IsQUFLSyw4QkFIdkMsSUFLQSxlQUFDLHdDQUxBIiwiZmlsZSI6ImNvbXBvbmVudHNcXEhlYWRlci5qcyIsInNvdXJjZVJvb3QiOiJDOlxcVXNlcnNcXEFzZWVtXFxSZWFjdCBQcm9qZWN0c1xcRnJpZGdlaHVudGVycyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluaydcclxuaW1wb3J0IEFwcEJhciBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9BcHBCYXInO1xyXG5pbXBvcnQgVG9vbGJhciBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9Ub29sYmFyJztcclxuaW1wb3J0IEJ1dHRvbiBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9CdXR0b24nO1xyXG4vL2ltcG9ydCBcInR5cGVmYWNlLWxvYnN0ZXJcIjtcclxuXHJcbmNvbnN0IGxpbmtTdHlsZSA9IHtcclxuICBtYXJnaW5SaWdodDogMTUsXHJcbiAgYm9yZGVyOiAnMnB4IHNvbGlkICNEREQnXHJcbn1cclxuXHJcbmNvbnN0IEhlYWRlciA9ICgpID0+IHtcclxuICAgIHJldHVybihcclxuICAgIDxkaXY+XHJcbiAgICBcdDxoMSBhbGlnbj1cImNlbnRlclwiPkZyaWRnZWh1bnRlcnM8L2gxPjxzdHlsZSBqc3g+e2BcclxuICAgICAgICBAaW1wb3J0IHVybCgnaHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbS9jc3M/ZmFtaWx5PUxvYnN0ZXInKTtcclxuXHJcbiAgICAgICAgQGZvbnRmYWNlIHtcclxuICAgICAgICAgIGZvbnQtZmFtaWx5OiAnTG9ic3RlcicsIGN1cnNpdmU7XHJcbiAgICAgICAgICBzcmM6IHVybCgnaHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbS9jc3M/ZmFtaWx5PUxvYnN0ZXInKVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaDEge1xyXG4gICAgICAgICAgZm9udC1mYW1pbHk6IFwiTG9ic3RlclwiLCBUaW1lcywgc2VyaWY7XHJcbiAgICAgICAgICBmb250LXNpemU6IDU0cHhcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgIGB9PC9zdHlsZT5cclxuICAgICAgPEFwcEJhciBwb3NpdGlvbj1cInN0YXRpY1wiPlxyXG4gICAgICAgIDxUb29sYmFyICBzdHlsZT17e2p1c3RpZnlDb250ZW50OiAnY2VudGVyJ319PlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8TGluayBocmVmPVwiL2hvdFwiPlxyXG4gICAgICAgICAgICA8QnV0dG9uIHN0eWxlPXt7IGZvbnRXZWlnaHQ6IFwiYm9sZFwiLCBmb250U2l6ZTogXCIxNnB4XCIgIH19PkhPVDwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG5cclxuICAgICAgICAgIDxMaW5rIGhyZWY9XCIvXCI+XHJcbiAgICAgICAgICAgIDxCdXR0b24gc3R5bGU9e3sgZm9udFdlaWdodDogXCJib2xkXCIsIGZvbnRTaXplOiBcIjE2cHhcIiAgfX0+SE9NRTwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG5cclxuICAgICAgICAgIDxMaW5rIGhyZWY9XCIvY3JlYXRlXCI+XHJcbiAgICAgICAgICAgIDxCdXR0b24gc3R5bGU9e3sgZm9udFdlaWdodDogXCJib2xkXCIsIGZvbnRTaXplOiBcIjE2cHhcIiB9fT5DUkVBVEU8L0J1dHRvbj5cclxuICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvVG9vbGJhcj5cclxuICAgICAgPC9BcHBCYXI+XHJcbiAgICAgICAgXHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEhlYWRlciJdfQ== */\n/*@ sourceURL=components\\Header.js */"
  }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__material_ui_core_AppBar___default.a, {
    position: "static",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    }
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__material_ui_core_Toolbar___default.a, {
    style: {
      justifyContent: 'center'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 30
    }
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31
    },
    className: "jsx-187386659"
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_next_link___default.a, {
    href: "/hot",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 32
    }
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__material_ui_core_Button___default.a, {
    style: {
      fontWeight: "bold",
      fontSize: "16px"
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 33
    }
  }, "HOT")), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_next_link___default.a, {
    href: "/",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 36
    }
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__material_ui_core_Button___default.a, {
    style: {
      fontWeight: "bold",
      fontSize: "16px"
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 37
    }
  }, "HOME")), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_next_link___default.a, {
    href: "/create",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 40
    }
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__material_ui_core_Button___default.a, {
    style: {
      fontWeight: "bold",
      fontSize: "16px"
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    }
  }, "CREATE"))))));
};

/* harmony default export */ __webpack_exports__["a"] = (Header);

/***/ }),

/***/ "./node_modules/@material-ui/core/Button/index.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__("./node_modules/@babel/runtime/helpers/builtin/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function get() {
    return _Button.default;
  }
});

var _Button = _interopRequireDefault(__webpack_require__("./node_modules/@material-ui/core/Button/Button.js"));

/***/ }),

/***/ "./pages/index.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style__ = __webpack_require__("./node_modules/styled-jsx/style.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__("./node_modules/react/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__components_MyLayout_js__ = __webpack_require__("./components/MyLayout.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__components_WrapLayout_js__ = __webpack_require__("./components/WrapLayout.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_next_link__ = __webpack_require__("./node_modules/next/link.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_next_link___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_next_link__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_isomorphic_unfetch__ = __webpack_require__("./node_modules/isomorphic-unfetch/browser.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_isomorphic_unfetch___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_isomorphic_unfetch__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__components_urlname_js__ = __webpack_require__("./components/urlname.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__material_ui_core_Button__ = __webpack_require__("./node_modules/@material-ui/core/Button/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__material_ui_core_Button___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7__material_ui_core_Button__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__material_ui_core_TextField__ = __webpack_require__("./node_modules/@material-ui/core/TextField/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__material_ui_core_TextField___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_8__material_ui_core_TextField__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__material_ui_core_List__ = __webpack_require__("./node_modules/@material-ui/core/List/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__material_ui_core_List___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_9__material_ui_core_List__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__material_ui_core_ListItem__ = __webpack_require__("./node_modules/@material-ui/core/ListItem/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__material_ui_core_ListItem___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_10__material_ui_core_ListItem__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__material_ui_core_ListItemText__ = __webpack_require__("./node_modules/@material-ui/core/ListItemText/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__material_ui_core_ListItemText___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_11__material_ui_core_ListItemText__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__material_ui_core_Divider__ = __webpack_require__("./node_modules/@material-ui/core/Divider/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__material_ui_core_Divider___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_12__material_ui_core_Divider__);
var _jsxFileName = "C:\\Users\\Aseem\\React Projects\\Fridgehunters\\pages\\index.js";



function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }













var Listing =
/*#__PURE__*/
function (_React$Component) {
  _inherits(Listing, _React$Component);

  function Listing(props) {
    var _this;

    _classCallCheck(this, Listing);

    _this = _possibleConstructorReturn(this, (Listing.__proto__ || Object.getPrototypeOf(Listing)).call(this, props));
    console.log(_this.props.textValue);
    _this.state = {
      list: []
    };
    return _this;
  }

  _createClass(Listing, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var _this2 = this;

      __WEBPACK_IMPORTED_MODULE_5_isomorphic_unfetch___default()(__WEBPACK_IMPORTED_MODULE_6__components_urlname_js__["a" /* default */] + "/?desiredMethod=SUGGEST&uname=" + this.props.textValue).then(function (response) {
        return response.text();
      }).then(function (data) {
        console.log("Show data fetched. Count: " + data);
        var datalist = data.split(",");

        if (data == "") {
          _this2.setState({
            list: []
          });
        } else {
          _this2.setState({
            list: datalist
          });
        }
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        align: "center",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 47
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__material_ui_core_List___default.a, {
        component: "nav",
        style: {
          width: 250
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 48
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_12__material_ui_core_Divider___default.a, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 48
        }
      }), this.state.list.map(function (ingred) {
        return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
          key: ingred,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 49
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_10__material_ui_core_ListItem___default.a, {
          button: true,
          onClick: _this3.props.onClicker,
          customtext: ingred,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 50
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_11__material_ui_core_ListItemText___default.a, {
          primary: ingred,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 51
          }
        })), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_12__material_ui_core_Divider___default.a, {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 53
          }
        }));
      })));
    }
  }]);

  return Listing;
}(__WEBPACK_IMPORTED_MODULE_1_react___default.a.Component);

var Dropdown =
/*#__PURE__*/
function (_React$Component2) {
  _inherits(Dropdown, _React$Component2);

  function Dropdown(props) {
    var _this4;

    _classCallCheck(this, Dropdown);

    _this4 = _possibleConstructorReturn(this, (Dropdown.__proto__ || Object.getPrototypeOf(Dropdown)).call(this, props));
    _this4.state = {
      listOpen: false,
      title: _this4.props.title,
      textValue: "",
      ingredtextlist: []
    };
    _this4.showMenu = _this4.showMenu.bind(_assertThisInitialized(_this4));
    _this4.closeMenu = _this4.closeMenu.bind(_assertThisInitialized(_this4));
    _this4.RemoveIngred = _this4.RemoveIngred.bind(_assertThisInitialized(_this4));
    _this4.addIngredient = _this4.addIngredient.bind(_assertThisInitialized(_this4));
    return _this4;
  }

  _createClass(Dropdown, [{
    key: "showMenu",
    value: function showMenu(event) {
      var _this5 = this;

      if (this.state.listOpen) {
        this.setState({
          textValue: event.target.value,
          listOpen: false
        }, function () {
          document.removeEventListener('click', _this5.closeMenu);
        });
      } else {
        this.setState({
          textValue: event.target.value,
          listOpen: true
        }, function () {
          document.addEventListener('click', _this5.closeMenu);
        });
      }
    }
  }, {
    key: "RemoveIngred",
    value: function RemoveIngred(event) {
      var index = +this.state.ingredtextlist.indexOf(event.target.getAttribute('key2'));
      console.log(index);
      var changedArray = this.state.ingredtextlist.slice();
      changedArray.splice(index, 1);
      this.setState(function (prevState, props) {
        return {
          ingredtextlist: changedArray
        };
      });
    }
  }, {
    key: "addIngredient",
    value: function addIngredient(event) {
      var _this6 = this;

      event.persist();

      if (event.currentTarget.id == "addButton") {
        if (this.state.textValue == "") {
          return;
        }

        if (this.state.ingredtextlist.findIndex(function (ing) {
          return ing == _this6.state.textValue;
        }) == -1) {
          //this.setState((prevState, props) => {return {ingredlist: prevState.ingredlist.concat([(
          //<h1 onClick={this.RemoveIngred} key={this.state.textValue}>{this.state.textValue}</h1>
          //)])}})
          this.setState(function (prevState, props) {
            return {
              ingredtextlist: prevState.ingredtextlist.concat([_this6.state.textValue])
            };
          });
        }
      } else {
        var custom = event.currentTarget.getAttribute('customtext');
        this.setState({
          listOpen: false
        }, function () {
          document.removeEventListener('click', _this6.closeMenu);
        }); //if(this.state.ingredlist.findIndex(ing => ing.key == event.target.getAttribute('customtext')) == -1){

        if (this.state.ingredtextlist.findIndex(function (ing) {
          return ing == custom;
        }) == -1) {
          //this.setState((prevState, props) => {return {ingredlist: prevState.ingredlist.concat([(
          //<h1 onClick={this.RemoveIngred} key={event.target.getAttribute('customtext')}>{event.target.getAttribute('customtext')}</h1>
          //)])}})
          this.setState(function (prevState, props) {
            return {
              ingredtextlist: prevState.ingredtextlist.concat([custom])
            };
          });
        }
      }
    }
  }, {
    key: "closeMenu",
    value: function closeMenu(event) {
      var _this7 = this;

      if (!this.dropdownMenu.contains(event.target)) {
        this.setState({
          listOpen: false
        }, function () {
          document.removeEventListener('click', _this7.closeMenu);
        });
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this8 = this;

      return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 153
        },
        className: "jsx-404019787"
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        align: "center",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 154
        },
        className: "jsx-404019787"
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 155
        },
        className: "jsx-404019787"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 155
        },
        className: "jsx-404019787"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 155
        },
        className: "jsx-404019787"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("form", {
        name: "addForm",
        onSubmit: function onSubmit(event) {
          return _this8.showMenu(event);
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 156
        },
        className: "jsx-404019787"
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("label", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 157
        },
        className: "jsx-404019787"
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("h2", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 158
        },
        className: "jsx-404019787"
      }, "What's in your fridge? "), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__material_ui_core_TextField___default.a, {
        onKeyPress: function onKeyPress(e) {
          if (e.key === 'Enter') e.preventDefault();
        },
        onChange: function onChange(event) {
          return _this8.showMenu(event);
        },
        margin: "normal",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 159
        }
      }))), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__material_ui_core_Button___default.a, {
        variant: "contained",
        color: "secondary",
        onClick: this.addIngredient,
        id: "addButton",
        style: {
          fontFamily: "Gentium Book Basic",
          fontWeight: "bold",
          fontSize: '16px'
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 164
        }
      }, "Pick ingredient"), this.state.listOpen ? __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        ref: function ref(element) {
          _this8.dropdownMenu = element;
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 169
        },
        className: "jsx-404019787" + " " + "menu"
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(Listing, {
        textValue: this.state.textValue,
        onClicker: this.addIngredient,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 172
        }
      })) : __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 176
        },
        className: "jsx-404019787"
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 176
        },
        className: "jsx-404019787"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 176
        },
        className: "jsx-404019787"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 176
        },
        className: "jsx-404019787"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 176
        },
        className: "jsx-404019787"
      })), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        "class": "inline",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 182
        },
        className: "jsx-404019787"
      }, this.state.ingredtextlist.map(function (ingred) {
        return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__material_ui_core_Button___default.a, {
          variant: "outlined",
          onClick: _this8.RemoveIngred,
          key: ingred,
          key2: ingred,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 185
          }
        }, ingred);
      })), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 191
        },
        className: "jsx-404019787"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 191
        },
        className: "jsx-404019787"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 191
        },
        className: "jsx-404019787"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 191
        },
        className: "jsx-404019787"
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4_next_link___default.a, {
        href: {
          pathname: '/recipelist',
          query: {
            ingredlist: this.state.ingredtextlist.toString()
          }
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 192
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__material_ui_core_Button___default.a, {
        variant: "contained",
        style: {
          fontFamily: "Montserrat",
          fontWeight: "bold",
          fontSize: '20px'
        },
        color: "primary",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 193
        }
      }, "FIND RECIPES"))), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a, {
        styleId: "404019787",
        css: "h2.jsx-404019787{font-family:\"Gentium Book Basic\",Times,serif;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBhZ2VzXFxpbmRleC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFtTXFCLEFBSzJELDZDQUNqRCIsImZpbGUiOiJwYWdlc1xcaW5kZXguanMiLCJzb3VyY2VSb290IjoiQzpcXFVzZXJzXFxBc2VlbVxcUmVhY3QgUHJvamVjdHNcXEZyaWRnZWh1bnRlcnMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgTGF5b3V0IGZyb20gJy4uL2NvbXBvbmVudHMvTXlMYXlvdXQuanMnXHJcbmltcG9ydCBXcmFwTGF5b3V0IGZyb20gJy4uL2NvbXBvbmVudHMvV3JhcExheW91dC5qcydcclxuaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJ1xyXG5pbXBvcnQgZmV0Y2ggZnJvbSAnaXNvbW9ycGhpYy11bmZldGNoJ1xyXG5pbXBvcnQgdXJsbmFtZSBmcm9tICcuLi9jb21wb25lbnRzL3VybG5hbWUuanMnXHJcbmltcG9ydCBCdXR0b24gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvQnV0dG9uJztcclxuaW1wb3J0IFRleHRGaWVsZCBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9UZXh0RmllbGQnO1xyXG5pbXBvcnQgTGlzdCBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9MaXN0JztcclxuaW1wb3J0IExpc3RJdGVtIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0xpc3RJdGVtJztcclxuaW1wb3J0IExpc3RJdGVtVGV4dCBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9MaXN0SXRlbVRleHQnO1xyXG5pbXBvcnQgRGl2aWRlciBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9EaXZpZGVyJztcclxuXHJcblxyXG5jbGFzcyBMaXN0aW5nIGV4dGVuZHMgUmVhY3QuQ29tcG9uZW50e1xyXG5cdGNvbnN0cnVjdG9yKHByb3BzKXtcclxuXHQgIFx0c3VwZXIocHJvcHMpXHJcblx0ICBcdGNvbnNvbGUubG9nKHRoaXMucHJvcHMudGV4dFZhbHVlKVxyXG5cdCAgXHR0aGlzLnN0YXRlID0ge1xyXG5cdCAgXHRcdGxpc3Q6IFtdLFxyXG5cdCAgXHR9XHJcblx0fVxyXG5cclxuXHRjb21wb25lbnRXaWxsTW91bnQoKXtcclxuXHRcdGZldGNoKHVybG5hbWUgKyBcIi8/ZGVzaXJlZE1ldGhvZD1TVUdHRVNUJnVuYW1lPVwiICsgdGhpcy5wcm9wcy50ZXh0VmFsdWUpLnRoZW4ocmVzcG9uc2UgPT4gcmVzcG9uc2UudGV4dCgpKS50aGVuKGRhdGEgPT4ge1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIlNob3cgZGF0YSBmZXRjaGVkLiBDb3VudDogXCIgKyBkYXRhKVxyXG5cdFx0XHR2YXIgZGF0YWxpc3QgPSBkYXRhLnNwbGl0KFwiLFwiKTtcclxuXHRcdFx0aWYoZGF0YSA9PSBcIlwiKXtcclxuXHRcdFx0XHR0aGlzLnNldFN0YXRlKHtcclxuXHRcdFx0XHRcclxuXHRcdFx0XHQgICAgbGlzdDogW11cclxuXHRcdFx0XHR9KTtcclxuXHRcdFx0fVxyXG5cdFx0XHRlbHNle1xyXG5cdFx0XHRcdHRoaXMuc2V0U3RhdGUoe1xyXG5cdFx0XHRcdFxyXG5cdFx0XHRcdCAgICBsaXN0OiBkYXRhbGlzdFxyXG5cdFx0XHRcdH0pO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0fSlcclxuXHRcdFxyXG5cdCAgXHRcclxuXHR9XHJcblxyXG5cdHJlbmRlcigpe1xyXG5cdFx0cmV0dXJuIChcclxuXHRcdCAgXHQ8ZGl2IGFsaWduPVwiY2VudGVyXCI+XHJcblx0XHQgIFx0PExpc3QgY29tcG9uZW50PVwibmF2XCIgIHN0eWxlID0ge3t3aWR0aDogMjUwfX0+PERpdmlkZXIgLz5cclxuXHRcdCAgXHRcdHt0aGlzLnN0YXRlLmxpc3QubWFwKChpbmdyZWQpID0+ICg8ZGl2IGtleT17aW5ncmVkfT5cclxuXHRcdCAgXHRcdFx0PExpc3RJdGVtIGJ1dHRvbiBvbkNsaWNrPXt0aGlzLnByb3BzLm9uQ2xpY2tlcn0gY3VzdG9tdGV4dD17aW5ncmVkfT5cclxuXHRcdFx0ICAgICAgICAgIFx0PExpc3RJdGVtVGV4dCBwcmltYXJ5PXtpbmdyZWR9IC8+XHJcblx0XHRcdCAgICAgICAgPC9MaXN0SXRlbT5cclxuXHRcdFx0ICAgICAgICA8RGl2aWRlciAvPlxyXG5cdFx0XHQgICAgICAgIDwvZGl2PlxyXG5cdFx0ICBcdFx0KSl9XHJcblx0XHQgIFx0PC9MaXN0PlxyXG5cdFx0ICBcdDwvZGl2PlxyXG5cclxuXHRcdClcclxuXHR9XHJcblx0XHJcbn1cclxuXHJcblxyXG5jbGFzcyBEcm9wZG93biBleHRlbmRzIFJlYWN0LkNvbXBvbmVudHtcclxuXHRjb25zdHJ1Y3Rvcihwcm9wcyl7XHJcblx0ICBzdXBlcihwcm9wcylcclxuXHQgIHRoaXMuc3RhdGUgPSB7XHJcblx0ICAgIGxpc3RPcGVuOiBmYWxzZSxcclxuXHQgICAgdGl0bGU6IHRoaXMucHJvcHMudGl0bGUsXHJcblx0ICAgIHRleHRWYWx1ZTogXCJcIixcclxuXHQgICAgaW5ncmVkdGV4dGxpc3Q6IFtdXHJcblx0ICB9XHJcblxyXG5cdCAgdGhpcy5zaG93TWVudSA9IHRoaXMuc2hvd01lbnUuYmluZCh0aGlzKTtcclxuXHQgIHRoaXMuY2xvc2VNZW51ID0gdGhpcy5jbG9zZU1lbnUuYmluZCh0aGlzKTtcclxuXHQgIHRoaXMuUmVtb3ZlSW5ncmVkID0gdGhpcy5SZW1vdmVJbmdyZWQuYmluZCh0aGlzKTtcclxuXHQgIHRoaXMuYWRkSW5ncmVkaWVudCA9IHRoaXMuYWRkSW5ncmVkaWVudC5iaW5kKHRoaXMpO1xyXG5cdH1cclxuXHJcblx0c2hvd01lbnUoZXZlbnQpe1xyXG5cdFx0aWYodGhpcy5zdGF0ZS5saXN0T3Blbil7XHJcblx0XHRcdHRoaXMuc2V0U3RhdGUoeyB0ZXh0VmFsdWU6IGV2ZW50LnRhcmdldC52YWx1ZSwgbGlzdE9wZW46IGZhbHNlIH0sICgpID0+IHtcclxuXHRcdCAgICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignY2xpY2snLCB0aGlzLmNsb3NlTWVudSk7XHJcblx0XHQgICAgfSk7ICBcclxuXHRcdH1cclxuXHRcdGVsc2V7XHJcblx0ICBcdFx0dGhpcy5zZXRTdGF0ZSh7XHJcblx0ICBcdFx0XHR0ZXh0VmFsdWU6IGV2ZW50LnRhcmdldC52YWx1ZSxcclxuXHQgICAgXHRcdGxpc3RPcGVuOiB0cnVlXHJcblx0ICBcdFx0fSwgICgpID0+IHtcclxuICAgICAgXHRcdGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgdGhpcy5jbG9zZU1lbnUpO1xyXG4gICAgXHRcdH0pXHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHRSZW1vdmVJbmdyZWQoZXZlbnQpe1xyXG5cdFx0dmFyIGluZGV4ID0gKyh0aGlzLnN0YXRlLmluZ3JlZHRleHRsaXN0LmluZGV4T2YoZXZlbnQudGFyZ2V0LmdldEF0dHJpYnV0ZSgna2V5MicpKSk7XHJcblx0XHRjb25zb2xlLmxvZyhpbmRleClcclxuXHRcdHZhciBjaGFuZ2VkQXJyYXkgPSB0aGlzLnN0YXRlLmluZ3JlZHRleHRsaXN0LnNsaWNlKCk7XHJcblx0XHRjaGFuZ2VkQXJyYXkuc3BsaWNlKGluZGV4LCAxKTtcclxuXHRcdHRoaXMuc2V0U3RhdGUoKHByZXZTdGF0ZSwgcHJvcHMpID0+IHtyZXR1cm4ge2luZ3JlZHRleHRsaXN0OiBjaGFuZ2VkQXJyYXl9fSlcclxuXHR9XHJcblxyXG5cdGFkZEluZ3JlZGllbnQoZXZlbnQpe1xyXG5cdFx0ZXZlbnQucGVyc2lzdCgpO1xyXG5cclxuXHRcdGlmKGV2ZW50LmN1cnJlbnRUYXJnZXQuaWQgPT0gXCJhZGRCdXR0b25cIil7XHJcblx0XHRcdGlmKHRoaXMuc3RhdGUudGV4dFZhbHVlID09IFwiXCIpe1xyXG5cdFx0XHRcdHJldHVybjtcclxuXHRcdFx0fVxyXG5cdFx0XHRpZih0aGlzLnN0YXRlLmluZ3JlZHRleHRsaXN0LmZpbmRJbmRleChpbmcgPT4gaW5nID09IHRoaXMuc3RhdGUudGV4dFZhbHVlKSA9PSAtMSl7XHJcblx0XHRcdFx0Ly90aGlzLnNldFN0YXRlKChwcmV2U3RhdGUsIHByb3BzKSA9PiB7cmV0dXJuIHtpbmdyZWRsaXN0OiBwcmV2U3RhdGUuaW5ncmVkbGlzdC5jb25jYXQoWyhcclxuXHRcdFx0XHRcdC8vPGgxIG9uQ2xpY2s9e3RoaXMuUmVtb3ZlSW5ncmVkfSBrZXk9e3RoaXMuc3RhdGUudGV4dFZhbHVlfT57dGhpcy5zdGF0ZS50ZXh0VmFsdWV9PC9oMT5cclxuXHRcdFx0XHQvLyldKX19KVxyXG5cclxuXHRcdFx0XHR0aGlzLnNldFN0YXRlKChwcmV2U3RhdGUsIHByb3BzKSA9PiB7cmV0dXJuIHtpbmdyZWR0ZXh0bGlzdDogcHJldlN0YXRlLmluZ3JlZHRleHRsaXN0LmNvbmNhdChbdGhpcy5zdGF0ZS50ZXh0VmFsdWVdKX19KVxyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHRcclxuXHRcdH1cclxuXHRcdGVsc2V7XHJcblx0XHRcdHZhciBjdXN0b20gPSBldmVudC5jdXJyZW50VGFyZ2V0LmdldEF0dHJpYnV0ZSgnY3VzdG9tdGV4dCcpXHJcblx0XHRcdHRoaXMuc2V0U3RhdGUoeyBsaXN0T3BlbjogZmFsc2UgfSwgKCkgPT4ge1xyXG5cdFx0ICAgICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdjbGljaycsIHRoaXMuY2xvc2VNZW51KTtcclxuXHRcdCAgICB9KTsgIFxyXG5cdFx0ICAgIC8vaWYodGhpcy5zdGF0ZS5pbmdyZWRsaXN0LmZpbmRJbmRleChpbmcgPT4gaW5nLmtleSA9PSBldmVudC50YXJnZXQuZ2V0QXR0cmlidXRlKCdjdXN0b210ZXh0JykpID09IC0xKXtcclxuXHRcdCAgICBpZih0aGlzLnN0YXRlLmluZ3JlZHRleHRsaXN0LmZpbmRJbmRleChpbmcgPT4gaW5nID09IGN1c3RvbSkgPT0gLTEpe1xyXG5cdFx0XHRcdC8vdGhpcy5zZXRTdGF0ZSgocHJldlN0YXRlLCBwcm9wcykgPT4ge3JldHVybiB7aW5ncmVkbGlzdDogcHJldlN0YXRlLmluZ3JlZGxpc3QuY29uY2F0KFsoXHJcblx0XHRcdFx0Ly88aDEgb25DbGljaz17dGhpcy5SZW1vdmVJbmdyZWR9IGtleT17ZXZlbnQudGFyZ2V0LmdldEF0dHJpYnV0ZSgnY3VzdG9tdGV4dCcpfT57ZXZlbnQudGFyZ2V0LmdldEF0dHJpYnV0ZSgnY3VzdG9tdGV4dCcpfTwvaDE+XHJcblx0XHRcdFx0Ly8pXSl9fSlcclxuXHJcblx0XHRcdFx0dGhpcy5zZXRTdGF0ZSgocHJldlN0YXRlLCBwcm9wcykgPT4ge3JldHVybiB7aW5ncmVkdGV4dGxpc3Q6IHByZXZTdGF0ZS5pbmdyZWR0ZXh0bGlzdC5jb25jYXQoW2N1c3RvbV0pfX0pXHJcblx0XHRcdH1cclxuXHRcdFx0XHJcblx0XHRcdFxyXG5cdFx0fVxyXG5cdH1cclxuXHJcblx0IGNsb3NlTWVudShldmVudCkge1xyXG4gICAgXHJcblx0ICAgIGlmICghdGhpcy5kcm9wZG93bk1lbnUuY29udGFpbnMoZXZlbnQudGFyZ2V0KSkge1xyXG5cdCAgICAgIFxyXG5cdCAgICAgIHRoaXMuc2V0U3RhdGUoeyBsaXN0T3BlbjogZmFsc2UgfSwgKCkgPT4ge1xyXG5cdCAgICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignY2xpY2snLCB0aGlzLmNsb3NlTWVudSk7XHJcblx0ICAgICAgfSk7ICBcclxuXHQgICAgICBcclxuXHQgICAgfVxyXG5cdH1cclxuXHJcblx0cmVuZGVyKCl7XHJcblx0XHRyZXR1cm4oXHJcblx0XHRcdDxkaXY+XHJcblx0XHRcdDxkaXYgYWxpZ249XCJjZW50ZXJcIiA+XHJcblx0XHRcdDxici8+PGJyLz48YnIvPlxyXG5cdFx0XHQ8Zm9ybSBuYW1lPVwiYWRkRm9ybVwiIG9uU3VibWl0PXsoZXZlbnQpID0+IHRoaXMuc2hvd01lbnUoZXZlbnQpfT5cclxuXHRcdCAgICAgICAgPGxhYmVsPlxyXG5cdFx0ICAgICAgICAgIFx0PGgyPldoYXQncyBpbiB5b3VyIGZyaWRnZT8gPC9oMj5cclxuXHRcdCAgICAgICAgICBcdDxUZXh0RmllbGQgIG9uS2V5UHJlc3M9e2UgPT4ge2lmIChlLmtleSA9PT0gJ0VudGVyJykgZS5wcmV2ZW50RGVmYXVsdCgpO319IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHRoaXMuc2hvd01lbnUoZXZlbnQpfSBtYXJnaW49XCJub3JtYWxcIiAvPlxyXG5cdFx0ICAgICAgICA8L2xhYmVsPlxyXG5cdFx0ICAgICAgICBcclxuXHRcdCAgICA8L2Zvcm0+XHJcblxyXG5cdFx0ICAgIDxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIGNvbG9yPVwic2Vjb25kYXJ5XCIgb25DbGljaz17dGhpcy5hZGRJbmdyZWRpZW50fSBpZD1cImFkZEJ1dHRvblwiICBzdHlsZT17eyBmb250RmFtaWx5OiBcIkdlbnRpdW0gQm9vayBCYXNpY1wiLCBmb250V2VpZ2h0OiBcImJvbGRcIiwgZm9udFNpemU6ICcxNnB4JyB9fT5QaWNrIGluZ3JlZGllbnQ8L0J1dHRvbj5cclxuXHRcdFx0XHJcblx0XHRcdHsgXHJcblx0XHRcdFx0dGhpcy5zdGF0ZS5saXN0T3BlbiBcclxuXHRcdFx0XHQ/KFxyXG5cdFx0XHRcdDxkaXYgY2xhc3NOYW1lPVwibWVudVwiIHJlZj17KGVsZW1lbnQpID0+IHtcclxuXHRcdFx0XHRcdHRoaXMuZHJvcGRvd25NZW51ID0gZWxlbWVudDtcclxuXHRcdFx0XHR9fT5cclxuXHRcdFx0XHRcdDxMaXN0aW5nIHRleHRWYWx1ZT17dGhpcy5zdGF0ZS50ZXh0VmFsdWV9IG9uQ2xpY2tlcj17dGhpcy5hZGRJbmdyZWRpZW50fS8+XHJcblx0XHRcdFx0PC9kaXY+XHJcblx0XHRcdFx0KVxyXG5cdFx0XHRcdDooXHJcblx0XHRcdFx0PGRpdj48YnIvPjxici8+PGJyLz48YnIvPjwvZGl2PlxyXG5cdFx0XHRcdClcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0XHJcblx0XHRcdFxyXG5cdFx0XHQ8ZGl2IGNsYXNzPVwiaW5saW5lXCI+XHJcblx0XHRcdHtcclxuXHRcdFx0XHR0aGlzLnN0YXRlLmluZ3JlZHRleHRsaXN0Lm1hcChpbmdyZWQgPT4gKFxyXG5cdFx0XHRcdFx0PEJ1dHRvbiAgdmFyaWFudD1cIm91dGxpbmVkXCIgb25DbGljaz17dGhpcy5SZW1vdmVJbmdyZWR9IGtleT17aW5ncmVkfSBrZXkyPXtpbmdyZWR9PntpbmdyZWR9PC9CdXR0b24+XHJcblx0XHRcdFx0KVxyXG5cdFx0XHRcdClcclxuXHRcdFx0fVxyXG5cdFx0XHQ8L2Rpdj5cclxuXHJcblx0XHRcdDxici8+PGJyLz48YnIvPjxici8+XHJcblx0XHRcdDxMaW5rICBocmVmPXt7IHBhdGhuYW1lOiAnL3JlY2lwZWxpc3QnLCBxdWVyeTogeyBpbmdyZWRsaXN0OiB0aGlzLnN0YXRlLmluZ3JlZHRleHRsaXN0LnRvU3RyaW5nKCkgfSB9fT5cclxuXHQgICAgICAgIFx0PEJ1dHRvbiB2YXJpYW50PVwiY29udGFpbmVkXCIgc3R5bGU9e3tmb250RmFtaWx5OiBcIk1vbnRzZXJyYXRcIiwgZm9udFdlaWdodDogXCJib2xkXCIsIGZvbnRTaXplOiAnMjBweCcgfX0gY29sb3I9XCJwcmltYXJ5XCI+RklORCBSRUNJUEVTPC9CdXR0b24+XHJcblx0ICAgICAgICA8L0xpbms+XHJcblx0XHRcdFxyXG5cdFx0XHQ8L2Rpdj48c3R5bGUganN4PntgXHJcblx0ICAgICAgICBcclxuXHJcblx0ICAgICAgICBoMiB7XHJcblx0ICAgICAgICAgIGZvbnQtZmFtaWx5OiBcIkdlbnRpdW0gQm9vayBCYXNpY1wiLCBUaW1lcywgc2VyaWY7XHJcblx0ICAgICAgICB9XHJcblx0ICAgICAgICBcclxuXHQgICAgICBgfTwvc3R5bGU+XHJcblx0ICAgICAgPC9kaXY+XHJcblx0XHRcdFxyXG5cdFx0XHRcclxuXHJcblx0XHQpO1xyXG5cdH1cclxufVxyXG5cclxuXHJcblxyXG5jb25zdCBJbmRleCA9ICgpID0+IChcclxuICA8TGF5b3V0PlxyXG4gIFx0PERyb3Bkb3duIHRpdGxlPVwiUGljayBhbiBpbmdyZWRpZW50XCIvPlxyXG4gIDwvTGF5b3V0PlxyXG4pXHJcblxyXG5leHBvcnQgZGVmYXVsdCBJbmRleCJdfQ== */\n/*@ sourceURL=pages\\index.js */"
      }));
    }
  }]);

  return Dropdown;
}(__WEBPACK_IMPORTED_MODULE_1_react___default.a.Component);

var Index = function Index() {
  return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__components_MyLayout_js__["a" /* default */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 215
    }
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(Dropdown, {
    title: "Pick an ingredient",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 216
    }
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (Index);
    (function (Component, route) {
      if(!Component) return
      if (false) return
      module.hot.accept()
      Component.__route = route

      if (module.hot.status() === 'idle') return

      var components = next.router.components
      for (var r in components) {
        if (!components.hasOwnProperty(r)) continue

        if (components[r].Component.__route === route) {
          next.router.update(r, Component)
        }
      }
    })(typeof __webpack_exports__ !== 'undefined' ? __webpack_exports__.default : (module.exports.default || module.exports), "/")
  
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__("./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=5.ec4f1f000ba4fa9339b0.hot-update.js.map