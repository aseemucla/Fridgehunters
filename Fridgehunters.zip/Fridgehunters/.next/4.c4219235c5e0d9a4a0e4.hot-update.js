webpackHotUpdate(4,{

/***/ "./node_modules/@material-ui/core/Typography/index.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__("./node_modules/@babel/runtime/helpers/builtin/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function get() {
    return _Typography.default;
  }
});

var _Typography = _interopRequireDefault(__webpack_require__("./node_modules/@material-ui/core/Typography/Typography.js"));

/***/ }),

/***/ "./pages/hot.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style__ = __webpack_require__("./node_modules/styled-jsx/style.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__("./node_modules/react/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_next_router__ = __webpack_require__("./node_modules/next/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_next_router___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_next_router__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__components_MyLayout_js__ = __webpack_require__("./components/MyLayout.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_isomorphic_unfetch__ = __webpack_require__("./node_modules/isomorphic-unfetch/browser.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_isomorphic_unfetch___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_isomorphic_unfetch__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_next_link__ = __webpack_require__("./node_modules/next/link.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_next_link___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_next_link__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__components_urlname_js__ = __webpack_require__("./components/urlname.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__material_ui_core_Button__ = __webpack_require__("./node_modules/@material-ui/core/Button/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__material_ui_core_Button___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7__material_ui_core_Button__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__material_ui_core_Chip__ = __webpack_require__("./node_modules/@material-ui/core/Chip/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__material_ui_core_Chip___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_8__material_ui_core_Chip__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__material_ui_core_Card__ = __webpack_require__("./node_modules/@material-ui/core/Card/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__material_ui_core_Card___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_9__material_ui_core_Card__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__material_ui_core_CardActions__ = __webpack_require__("./node_modules/@material-ui/core/CardActions/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__material_ui_core_CardActions___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_10__material_ui_core_CardActions__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__material_ui_core_CardContent__ = __webpack_require__("./node_modules/@material-ui/core/CardContent/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__material_ui_core_CardContent___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_11__material_ui_core_CardContent__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__material_ui_core_Typography__ = __webpack_require__("./node_modules/@material-ui/core/Typography/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__material_ui_core_Typography___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_12__material_ui_core_Typography__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__material_ui_core_Badge__ = __webpack_require__("./node_modules/@material-ui/core/Badge/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__material_ui_core_Badge___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_13__material_ui_core_Badge__);
var _jsxFileName = "C:\\Users\\Aseem\\React Projects\\Fridgehunters\\pages\\hot.js";



function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }














var RecipeList =
/*#__PURE__*/
function (_React$Component) {
  _inherits(RecipeList, _React$Component);

  function RecipeList(props) {
    var _this;

    _classCallCheck(this, RecipeList);

    _this = _possibleConstructorReturn(this, (RecipeList.__proto__ || Object.getPrototypeOf(RecipeList)).call(this, props));
    _this.addEndorsement = _this.addEndorsement.bind(_assertThisInitialized(_this));
    _this.state = {
      recipes: [],
      endorsedrecipes: []
    };
    __WEBPACK_IMPORTED_MODULE_4_isomorphic_unfetch___default()(__WEBPACK_IMPORTED_MODULE_6__components_urlname_js__["a" /* default */] + "/?desiredMethod=HOTALLTIME").then(function (response) {
      return response.text();
    }).then(function (datas) {
      var data = JSON.parse("[" + datas + "]"); //console.log("Show data fetched. Count: " + JSON.stringify(data))

      _this.setState({
        recipes: data
      });
    });
    return _this;
  }

  _createClass(RecipeList, [{
    key: "addEndorsement",
    value: function addEndorsement(event) {
      var _this2 = this;

      var index = this.state.endorsedrecipes.indexOf(event.currentTarget.getAttribute('key2'));
      var temprec = event.currentTarget.getAttribute('key2');
      var tempendorselist = this.state.endorsedrecipes.slice().concat([temprec]);

      if (index == -1) {
        this.setState(function (prevState, props) {
          return {
            endorsedrecipes: tempendorselist
          };
        });
        __WEBPACK_IMPORTED_MODULE_4_isomorphic_unfetch___default()(__WEBPACK_IMPORTED_MODULE_6__components_urlname_js__["a" /* default */] + "/?desiredMethod=ENDORSE&uname=" + temprec).then(function (response) {
          return response.text();
        }).then(function (data) {
          console.log(data);
          return 1;
        }).then(function (useless) {
          __WEBPACK_IMPORTED_MODULE_4_isomorphic_unfetch___default()(__WEBPACK_IMPORTED_MODULE_6__components_urlname_js__["a" /* default */] + "/?desiredMethod=HOTALLTIME").then(function (response) {
            return response.text();
          }).then(function (datas) {
            var data = JSON.parse("[" + datas + "]");
            console.log("Coming second"); //console.log("Show data fetched. Count: " + JSON.stringify(data))

            _this2.setState({
              recipes: data
            });
          });
        });
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 58
        },
        className: "jsx-4101515491"
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        align: "center",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 59
        },
        className: "jsx-4101515491"
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 59
        },
        className: "jsx-4101515491"
      }), this.state.recipes.map(function (recipe) {
        return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 62
          },
          className: "jsx-4101515491"
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__material_ui_core_Card___default.a, {
          style: {
            maxWidth: 450,
            backgroundColor: '#b3ffb3'
          },
          __source: {
            fileName: _jsxFileName,
            lineNumber: 62
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_11__material_ui_core_CardContent___default.a, {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 63
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_12__material_ui_core_Typography___default.a, {
          gutterBottom: true,
          variant: "headline",
          component: "h1",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 64
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("h2", {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 65
          },
          className: "jsx-4101515491"
        }, recipe.name)), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_12__material_ui_core_Typography___default.a, {
          component: "p",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 67
          }
        }, recipe.ingredients.map(function (ingred) {
          return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__material_ui_core_Chip___default.a, {
            label: ingred,
            __source: {
              fileName: _jsxFileName,
              lineNumber: 69
            }
          });
        })), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_12__material_ui_core_Typography___default.a, {
          component: "p",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 72
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 72
          },
          className: "jsx-4101515491"
        }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("p", {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 73
          },
          className: "jsx-4101515491"
        }, recipe.description)), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_12__material_ui_core_Typography___default.a, {
          component: "p",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 76
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 76
          },
          className: "jsx-4101515491"
        }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 76
          },
          className: "jsx-4101515491"
        }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_13__material_ui_core_Badge___default.a, {
          color: "secondary",
          badgeContent: recipe.endorse,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 77
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__material_ui_core_Button___default.a, {
          size: "small",
          variant: "contained",
          color: "primary",
          key2: recipe.name,
          style: {
            fontFamily: "Gentium Book Basic",
            fontWeight: "bold",
            fontSize: '15px'
          },
          onClick: _this3.addEndorsement,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 78
          }
        }, _this3.state.endorsedrecipes.indexOf(recipe.name) == -1 ? "Endorse" : "Added endorsement")))), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_10__material_ui_core_CardActions___default.a, {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 84
          }
        })), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("br", {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 86
          },
          className: "jsx-4101515491"
        }));
      })), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a, {
        styleId: "4101515491",
        css: "@import url('https://fonts.googleapis.com/css?family=Gentium+Book+Basic');@fontface{font-family:'Gentium Book Basic',cursive;src:url('https://fonts.googleapis.com/css?family=Gentium+Book+Basic');}@import url('https://fonts.googleapis.com/css?family=Noto+Sans');@fontface{font-family:'Noto Sans',cursive;src:url('https://fonts.googleapis.com/css?family=Noto+Sans');}h2.jsx-4101515491{font-family:\"Gentium Book Basic\",Times,serif;}p.jsx-4101515491{font-family:\"Noto Sans\",Times,serif;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBhZ2VzXFxob3QuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBeUZ3QixBQUVrRixBQUc3QixBQUtvQixBQUc3QixBQUtjLEFBSVQsZ0NBUHpDLElBUUMsS0FoQkQsSUFZQyxnREFKQSxrQkFSQSIsImZpbGUiOiJwYWdlc1xcaG90LmpzIiwic291cmNlUm9vdCI6IkM6XFxVc2Vyc1xcQXNlZW1cXFJlYWN0IFByb2plY3RzXFxGcmlkZ2VodW50ZXJzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgd2l0aFJvdXRlciB9IGZyb20gJ25leHQvcm91dGVyJ1xyXG5pbXBvcnQgTGF5b3V0IGZyb20gJy4uL2NvbXBvbmVudHMvTXlMYXlvdXQuanMnXHJcbmltcG9ydCBmZXRjaCBmcm9tICdpc29tb3JwaGljLXVuZmV0Y2gnXHJcbmltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluaydcclxuaW1wb3J0IHVybG5hbWUgZnJvbSAnLi4vY29tcG9uZW50cy91cmxuYW1lLmpzJ1xyXG5pbXBvcnQgQnV0dG9uIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0J1dHRvbic7XHJcbmltcG9ydCBDaGlwIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0NoaXAnO1xyXG5pbXBvcnQgQ2FyZCBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9DYXJkJztcclxuaW1wb3J0IENhcmRBY3Rpb25zIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0NhcmRBY3Rpb25zJztcclxuaW1wb3J0IENhcmRDb250ZW50IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0NhcmRDb250ZW50JztcclxuaW1wb3J0IFR5cG9ncmFwaHkgZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvVHlwb2dyYXBoeSc7XHJcbmltcG9ydCBCYWRnZSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9CYWRnZSc7XHJcblxyXG5jbGFzcyBSZWNpcGVMaXN0IGV4dGVuZHMgUmVhY3QuQ29tcG9uZW50e1xyXG5cclxuICBjb25zdHJ1Y3Rvcihwcm9wcyl7XHJcbiAgICBzdXBlcihwcm9wcyk7XHJcbiAgICB0aGlzLmFkZEVuZG9yc2VtZW50ID0gdGhpcy5hZGRFbmRvcnNlbWVudC5iaW5kKHRoaXMpO1xyXG4gICAgdGhpcy5zdGF0ZSA9IHtcclxuICAgICAgcmVjaXBlczogW10sXHJcbiAgICAgIGVuZG9yc2VkcmVjaXBlczogW11cclxuICAgIH1cclxuXHJcbiAgICBmZXRjaCh1cmxuYW1lICsgXCIvP2Rlc2lyZWRNZXRob2Q9SE9UQUxMVElNRVwiKS50aGVuKHJlc3BvbnNlID0+IHJlc3BvbnNlLnRleHQoKSkudGhlbihkYXRhcyA9PiB7XHJcbiAgICAgIHZhciBkYXRhID0gSlNPTi5wYXJzZShcIltcIiArIGRhdGFzICArIFwiXVwiKVxyXG4gICAgICAvL2NvbnNvbGUubG9nKFwiU2hvdyBkYXRhIGZldGNoZWQuIENvdW50OiBcIiArIEpTT04uc3RyaW5naWZ5KGRhdGEpKVxyXG4gICAgICB0aGlzLnNldFN0YXRlKHtcclxuICAgICAgICByZWNpcGVzOiBkYXRhXHJcbiAgICAgIH0pXHJcbiAgICB9KVxyXG4gIH1cclxuXHJcbiAgYWRkRW5kb3JzZW1lbnQoZXZlbnQpe1xyXG4gICAgdmFyIGluZGV4ID0gdGhpcy5zdGF0ZS5lbmRvcnNlZHJlY2lwZXMuaW5kZXhPZihldmVudC5jdXJyZW50VGFyZ2V0LmdldEF0dHJpYnV0ZSgna2V5MicpKTtcclxuICAgIHZhciB0ZW1wcmVjID0gZXZlbnQuY3VycmVudFRhcmdldC5nZXRBdHRyaWJ1dGUoJ2tleTInKTtcclxuICAgIHZhciB0ZW1wZW5kb3JzZWxpc3QgPSB0aGlzLnN0YXRlLmVuZG9yc2VkcmVjaXBlcy5zbGljZSgpLmNvbmNhdChbdGVtcHJlY10pXHJcblxyXG4gICAgaWYoaW5kZXggPT0gLTEpe1xyXG4gICAgICBcclxuICAgICAgdGhpcy5zZXRTdGF0ZSgocHJldlN0YXRlLCBwcm9wcykgPT4ge3JldHVybiB7ZW5kb3JzZWRyZWNpcGVzOiB0ZW1wZW5kb3JzZWxpc3R9fSlcclxuICAgICAgZmV0Y2godXJsbmFtZSArIFwiLz9kZXNpcmVkTWV0aG9kPUVORE9SU0UmdW5hbWU9XCIgKyB0ZW1wcmVjKS50aGVuKHJlc3BvbnNlID0+IHJlc3BvbnNlLnRleHQoKSkudGhlbihkYXRhID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhkYXRhKVxyXG4gICAgICAgIHJldHVybiAxO1xyXG4gICAgICB9KS50aGVuKHVzZWxlc3MgPT4ge2ZldGNoKHVybG5hbWUgKyBcIi8/ZGVzaXJlZE1ldGhvZD1IT1RBTExUSU1FXCIpLnRoZW4ocmVzcG9uc2UgPT4gcmVzcG9uc2UudGV4dCgpKS50aGVuKGRhdGFzID0+IHtcclxuICAgICAgICB2YXIgZGF0YSA9IEpTT04ucGFyc2UoXCJbXCIgKyBkYXRhcyAgKyBcIl1cIilcclxuICAgICAgICBjb25zb2xlLmxvZyhcIkNvbWluZyBzZWNvbmRcIilcclxuICAgICAgICAvL2NvbnNvbGUubG9nKFwiU2hvdyBkYXRhIGZldGNoZWQuIENvdW50OiBcIiArIEpTT04uc3RyaW5naWZ5KGRhdGEpKVxyXG4gICAgICAgIHRoaXMuc2V0U3RhdGUoe1xyXG4gICAgICAgICAgcmVjaXBlczogZGF0YVxyXG4gICAgICAgIH0pXHJcbiAgICAgIH0pXHJcbiAgICAgIH0pXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICByZW5kZXIoKXtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXY+XHJcbiAgICAgIDxkaXYgYWxpZ249XCJjZW50ZXJcIj48YnIvPlxyXG5cclxuICAgICAge1xyXG4gICAgICAgIHRoaXMuc3RhdGUucmVjaXBlcy5tYXAocmVjaXBlID0+ICg8ZGl2PjxDYXJkIHN0eWxlPXt7bWF4V2lkdGg6IDQ1MCwgIGJhY2tncm91bmRDb2xvcjogJyNiM2ZmYjMnfX0gPlxyXG4gICAgICAgICAgPENhcmRDb250ZW50PlxyXG4gICAgICAgICAgICA8VHlwb2dyYXBoeSBndXR0ZXJCb3R0b20gdmFyaWFudD1cImhlYWRsaW5lXCIgY29tcG9uZW50PVwiaDFcIj5cclxuICAgICAgICAgICAgICA8aDI+e3JlY2lwZS5uYW1lfTwvaDI+XHJcbiAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgPFR5cG9ncmFwaHkgY29tcG9uZW50PVwicFwiPlxyXG4gICAgICAgICAgICAgIHtyZWNpcGUuaW5ncmVkaWVudHMubWFwKGluZ3JlZCA9PiAoXHJcbiAgICAgICAgICAgICAgICA8Q2hpcCBsYWJlbD17aW5ncmVkfSAvPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgIDxUeXBvZ3JhcGh5IGNvbXBvbmVudD1cInBcIj48YnIvPlxyXG4gICAgICAgICAgICAgIDxwPntyZWNpcGUuZGVzY3JpcHRpb259PC9wPlxyXG4gICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDxUeXBvZ3JhcGh5IGNvbXBvbmVudD1cInBcIj48YnIvPjxici8+XHJcbiAgICAgICAgICAgICAgPEJhZGdlIGNvbG9yPVwic2Vjb25kYXJ5XCIgYmFkZ2VDb250ZW50PXtyZWNpcGUuZW5kb3JzZX0+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21hbGxcIiAgdmFyaWFudD1cImNvbnRhaW5lZFwiICBjb2xvcj1cInByaW1hcnlcIiBrZXkyPXtyZWNpcGUubmFtZX0gIHN0eWxlPXt7IGZvbnRGYW1pbHk6IFwiR2VudGl1bSBCb29rIEJhc2ljXCIsIGZvbnRXZWlnaHQ6IFwiYm9sZFwiLCBmb250U2l6ZTogJzE1cHgnIH19IG9uQ2xpY2s9e3RoaXMuYWRkRW5kb3JzZW1lbnR9PlxyXG4gICAgICAgICAgICAgICAgeyh0aGlzLnN0YXRlLmVuZG9yc2VkcmVjaXBlcy5pbmRleE9mKHJlY2lwZS5uYW1lKSA9PSAtMSkgPyBcIkVuZG9yc2VcIiA6IFwiQWRkZWQgZW5kb3JzZW1lbnRcIn1cclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICA8L0JhZGdlPlxyXG4gICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICA8L0NhcmRDb250ZW50PlxyXG4gICAgICAgICAgPENhcmRBY3Rpb25zPlxyXG4gICAgICAgICAgPC9DYXJkQWN0aW9ucz5cclxuICAgICAgICA8L0NhcmQ+PGJyLz48L2Rpdj4pXHJcbiAgICAgICAgKVxyXG4gICAgICB9XHJcbiAgICAgIFxyXG4gICAgICA8L2Rpdj48c3R5bGUganN4PntgXHJcbiAgICAgICAgQGltcG9ydCB1cmwoJ2h0dHBzOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzP2ZhbWlseT1HZW50aXVtK0Jvb2srQmFzaWMnKTtcclxuXHJcbiAgICAgICAgQGZvbnRmYWNlIHtcclxuICAgICAgICAgIGZvbnQtZmFtaWx5OiAnR2VudGl1bSBCb29rIEJhc2ljJywgY3Vyc2l2ZTtcclxuICAgICAgICAgIHNyYzogdXJsKCdodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9R2VudGl1bStCb29rK0Jhc2ljJylcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIFxyXG4gICAgICAgIEBpbXBvcnQgdXJsKCdodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9Tm90bytTYW5zJyk7XHJcblxyXG4gICAgICAgIEBmb250ZmFjZSB7XHJcbiAgICAgICAgICBmb250LWZhbWlseTogJ05vdG8gU2FucycsIGN1cnNpdmU7XHJcbiAgICAgICAgICBzcmM6IHVybCgnaHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbS9jc3M/ZmFtaWx5PU5vdG8rU2FucycpXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBoMiB7XHJcbiAgICAgICAgICBmb250LWZhbWlseTogXCJHZW50aXVtIEJvb2sgQmFzaWNcIiwgVGltZXMsIHNlcmlmO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcCB7XHJcbiAgICAgICAgICBmb250LWZhbWlseTogXCJOb3RvIFNhbnNcIiwgVGltZXMsIHNlcmlmO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgYH08L3N0eWxlPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIClcclxuICB9XHJcbn1cclxuXHJcbmNvbnN0IEZpcnN0ID0gIChwcm9wcykgPT4gKFxyXG4gIDxMYXlvdXQ+XHJcbiAgICA8UmVjaXBlTGlzdCAvPlxyXG4gIDwvTGF5b3V0PlxyXG4pXHJcbmV4cG9ydCBkZWZhdWx0IEZpcnN0Il19 */\n/*@ sourceURL=pages\\hot.js */"
      }));
    }
  }]);

  return RecipeList;
}(__WEBPACK_IMPORTED_MODULE_1_react___default.a.Component);

var First = function First(props) {
  return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__components_MyLayout_js__["a" /* default */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 121
    }
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(RecipeList, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 122
    }
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (First);
    (function (Component, route) {
      if(!Component) return
      if (false) return
      module.hot.accept()
      Component.__route = route

      if (module.hot.status() === 'idle') return

      var components = next.router.components
      for (var r in components) {
        if (!components.hasOwnProperty(r)) continue

        if (components[r].Component.__route === route) {
          next.router.update(r, Component)
        }
      }
    })(typeof __webpack_exports__ !== 'undefined' ? __webpack_exports__.default : (module.exports.default || module.exports), "/hot")
  
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__("./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=4.c4219235c5e0d9a4a0e4.hot-update.js.map