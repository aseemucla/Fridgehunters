import Link from 'next/link'
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Button from '@material-ui/core/Button';
//import "typeface-lobster";

const linkStyle = {
  marginRight: 15,
  border: '2px solid #DDD'
}

const Header = () => (
    <div>
    	<h1 align="center">Fridgebuilders</h1><style jsx>{`
        @import url('https://fonts.googleapis.com/css?family=Lobster');

        @fontface {
          font-family: 'Lobster', cursive;
          src: url('https://fonts.googleapis.com/css?family=Lobster')
        }

        h1 {
          font-family: "Lobster", Times, serif;
          font-size: 48px
        }
        
      `}</style>
      <AppBar position="static">
        <Toolbar>
          <Link href="/hot">
            <Button>HOT</Button>
          </Link>

          <Link href="/">
            <Button>HOME</Button>
          </Link>

          <Link href="/create">
            <Button>CREATE</Button>
          </Link>
        </Toolbar>
      </AppBar>
        
    </div>
)

export default Header