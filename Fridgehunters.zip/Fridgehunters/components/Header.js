import Link from 'next/link'

const linkStyle = {
  marginRight: 15,
  border: '2px solid #DDD'
}

const Header = () => (
    <div>
    	<h1>Fridgebuilders</h1>
        <Link href="/">
          <a style={linkStyle}>Home</a>
        </Link>

        <Link href="/hot">
          <a style={linkStyle}>Hot</a>
        </Link>

        <Link href="/create">
          <a style={linkStyle}>Create</a>
        </Link>
    </div>
)

export default Header