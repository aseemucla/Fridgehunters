import Layout from '../components/MyLayout.js'
import WrapLayout from '../components/WrapLayout.js'
import Link from 'next/link'

//var querystring = require('querystring');
//var querystring = require('querystring')
//var data = { key: 'value' }
//querystring.stringify(data)

class Listing extends React.Component{
	constructor(props){
	  	super(props)
		getInitialListing = async function() {
		  	const res = await fetch("https://apimicroservicefh-yhanjlctbr.now.sh/?desiredMethod=SUGGEST&uname=" + props.textValue);
		  	const data = await res.json()

		  	console.log("Show data fetched. Count: ${data.length}")

		  	this.state = {
			    list: data
			}
		}

		getInitialListing.bind(this);
		getInitialListing();
	}

	render(){
		return (
		  	<div>
		  		{this.state.list.map(({ingred}) => (
		  			<button onClick={props.onClicker}>{ingred}</button>
		  		))}
		  	</div>
		)
	}
	
}




/*
const Listing = (props) => (
  <Layout>
      {props.shows.map(({show}) => (
        <li key={show.id}>
          <Link as={`/p/${show.id}`} href={`/post?id=${show.id}`}>
            <a>{show.name}</a>
          </Link>
        </li>
      ))}
  </Layout>
)



Index.getInitialProps = async function() {
  const res = await fetch('https://api.tvmaze.com/search/shows?q=batman')
  const data = await res.json()

  console.log(`Show data fetched. Count: ${data.length}`)

  return {
    shows: data
  }
}
*/


class Dropdown extends React.Component{
	constructor(props){
	  super(props)
	  this.state = {
	    listOpen: false,
	    title: this.props.title,
	    textValue: "",
	    ingredlist: [] //populate this with boxes that depict ingredients selected
	  }

	  this.showMenu = this.showMenu.bind(this);
	  this.closeMenu = this.closeMenu.bind(this);
	  this.addIngredient = this.addIngredient.bind(this);
	}

	showMenu(){
	  this.setState({
	  	textValue: event.target.value,
	    listOpen: true
	  },  () => {
      document.addEventListener('click', this.closeMenu);
    })
	}

	addIngredient(event){
		if(event.target.name == "form"){
			this.setState({ingredlist: ingredlist.push(
			<WrapLayout>{textValue}</WrapLayout>
			)})
		}
		else{
			this.setState({ingredlist: ingredlist.push(
				<WrapLayout>{event.target.value}</WrapLayout>
			)})
		}
	}

	 closeMenu(event) {
    
	    if (!this.dropdownMenu.contains(event.target)) {
	      
	      this.setState({ listOpen: false }, () => {
	        document.removeEventListener('click', this.closeMenu);
	      });  
	      
	    }
	}

	render(){
		return(
			<div>
			<form name="form" onSubmit={this.addIngredient}>
		        <label>
		          	Name:
		          	<input type="text" value={this.state.value} onChange={this.showMenu} />
		        </label>
		        <input type="submit" value="Pick ingredient" />
		    </form>
			
			{ 
				this.state.listOpen 
				?(
				<div classname="menu" ref={(element) => {
					this.dropdownMenu = element;
				}}>
					<Listing textValue={this.state.textValue} onClicker={this.addIngredient}/>
				</div>
				)
				:(
				null
				)
			}
			
			{this.state.ingredlist}


			<button href="/recipefound">FIND!</button>
			</div>
			
			

		);
	}
}



const Index = () => (
  <Layout>
  	<Dropdown title="Pick an ingredient"/>
  </Layout>
)

export default Index