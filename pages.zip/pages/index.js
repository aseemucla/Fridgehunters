import Layout from '../components/MyLayout.js'
import WrapLayout from '../components/WrapLayout.js'
import Link from 'next/link'


//var querystring = require('querystring');
//var querystring = require('querystring')
//var data = { key: 'value' }
//querystring.stringify(data)

class Listing extends React.Component{
	constructor(props){
	  	super(props)

	  	this.state = {
	  		list: ["boi", "girl"],
	  	}
		/*async function getInitialListing() {
		  	const res = await fetch("https://apimicroservicefh-yhanjlctbr.now.sh/?desiredMethod=SUGGEST&uname=" + props.textValue);
		  	const data = await res.json()

		  	console.log("Show data fetched. Count: ${data.length}")

		  	this.setState({
			    list: data
			});
		}

		getInitialListing.bind(this);
		getInitialListing();*/
	}

	render(){
		return (
		  	<div>
		  		{this.state.list.map((ingred) => (
		  			<button key={ingred} onClick={this.props.onClicker} customtext={ingred}>{ingred}</button>
		  		))}
		  	</div>
		)
	}
	
}

/*
const Listing = (props) => (
  <div>
      {props.textValue}
  </div>
)


const Listing = (props) => (
  <Layout>
      {props.shows.map(({show}) => (
        <li key={show.id}>
          <Link as={`/p/${show.id}`} href={`/post?id=${show.id}`}>
            <a>{show.name}</a>
          </Link>
        </li>
      ))}
  </Layout>
)



Index.getInitialProps = async function() {
  const res = await fetch('https://api.tvmaze.com/search/shows?q=batman')
  const data = await res.json()

  console.log(`Show data fetched. Count: ${data.length}`)

  return {
    shows: data
  }
}
*/


class Dropdown extends React.Component{
	constructor(props){
	  super(props)
	  this.state = {
	    listOpen: false,
	    title: this.props.title,
	    textValue: "",
	    ingredlist: [] //populate this with boxes that depict ingredients selected
	  }

	  this.showMenu = this.showMenu.bind(this);
	  this.closeMenu = this.closeMenu.bind(this);
	  this.addIngredient = this.addIngredient.bind(this);
	}

	showMenu(event){
	  this.setState({
	  	textValue: event.target.value,
	    listOpen: true
	  },  () => {
      document.addEventListener('click', this.closeMenu);
    })
	}

	addIngredient(event){
		event.persist();
		if(event.target.name == "addButton"){
			this.setState((prevState, props) => {return {ingredlist: prevState.ingredlist.concat([(
			<h1 key={this.state.textValue}>{this.state.textValue}</h1>
			)])}})
		}
		else{
			this.setState((prevState, props) => {return {ingredlist: prevState.ingredlist.concat([(
			<h1 key={this.state.textValue}>{event.target.getAttribute('customtext')}</h1>
			)])}})
			
			
		}
	}

	 closeMenu(event) {
    
	    if (!this.dropdownMenu.contains(event.target)) {
	      
	      this.setState({ listOpen: false }, () => {
	        document.removeEventListener('click', this.closeMenu);
	      });  
	      
	    }
	}

	render(){
		return(
			<div>
			<form name="addForm" onSubmit={(event) => this.showMenu(event)}>
		        <label>
		          	Name:
		          	<input type="text" onKeyPress={e => {if (e.key === 'Enter') e.preventDefault();}} onChange={(event) => this.showMenu(event)} />
		        </label>
		        
		    </form>

		    <button onClick={this.addIngredient} name="addButton">Pick ingredient</button>
			
			{ 
				this.state.listOpen 
				?(
				<div className="menu" ref={(element) => {
					this.dropdownMenu = element;
				}}>
					<Listing textValue={this.state.textValue} onClicker={this.addIngredient}/>
				</div>
				)
				:(
				null
				)
			}
			
			{this.state.ingredlist}

			<Link href="/recipefound">
	        	<button>FIND!</button>
	        </Link>
			
			</div>
			
			

		);
	}
}



const Index = () => (
  <Layout>
  	<Dropdown title="Pick an ingredient"/>
  </Layout>
)

export default Index