import Layout from '../components/MyLayout.js'
import WrapLayout from '../components/WrapLayout.js'
import Link from 'next/link'
import fetch from 'isomorphic-unfetch'
import urlname from '../components/urlname.js'


class Listing extends React.Component{
	constructor(props){
	  	super(props)
	  	console.log(this.props.textValue)
	  	this.state = {
	  		list: [],
	  	}
	}

	componentWillMount(){
		fetch(urlname + "/?desiredMethod=SUGGEST&uname=" + this.props.textValue).then(response => response.text()).then(data => {
			console.log("Show data fetched. Count: " + data)
			var datalist = data.split(",");
			if(data == ""){
				this.setState({
				
				    list: []
				});
			}
			else{
				this.setState({
				
				    list: datalist
				});
			}

		})
		
	  	
	}

	render(){
		return (
		  	<div>
		  		{this.state.list.map((ingred) => (
		  			<button key={ingred} onClick={this.props.onClicker} customtext={ingred}>{ingred}</button>
		  		))}
		  	</div>

		)
	}
	
}


class Dropdown extends React.Component{
	constructor(props){
	  super(props)
	  this.state = {
	    listOpen: false,
	    title: this.props.title,
	    textValue: "",
	    ingredtextlist: []
	  }

	  this.showMenu = this.showMenu.bind(this);
	  this.closeMenu = this.closeMenu.bind(this);
	  this.RemoveIngred = this.RemoveIngred.bind(this);
	  this.addIngredient = this.addIngredient.bind(this);
	}

	showMenu(event){
		if(this.state.listOpen){
			this.setState({ listOpen: false }, () => {
		        document.removeEventListener('click', this.closeMenu);
		    });  
		}
		else{
	  		this.setState({
	  			textValue: event.target.value,
	    		listOpen: true
	  		},  () => {
      		document.addEventListener('click', this.closeMenu);
    		})
		}
	}

	RemoveIngred(event){
		var index = +(this.state.ingredtextlist.indexOf(event.target.getAttribute('key2')));
		var changedArray = this.state.ingredtextlist.slice();
		changedArray.splice(index, 1);
		this.setState((prevState, props) => {return {ingredtextlist: changedArray}})
	}

	addIngredient(event){
		event.persist();
		if(event.target.name == "addButton"){
			if(this.state.ingredtextlist.findIndex(ing => ing == this.state.textValue) == -1){
				//this.setState((prevState, props) => {return {ingredlist: prevState.ingredlist.concat([(
					//<h1 onClick={this.RemoveIngred} key={this.state.textValue}>{this.state.textValue}</h1>
				//)])}})

				this.setState((prevState, props) => {return {ingredtextlist: prevState.ingredtextlist.concat([this.state.textValue])}})
			}

			
		}
		else{
			this.setState({ listOpen: false }, () => {
		        document.removeEventListener('click', this.closeMenu);
		    });  
		    //if(this.state.ingredlist.findIndex(ing => ing.key == event.target.getAttribute('customtext')) == -1){
		    if(this.state.ingredtextlist.findIndex(ing => ing == event.target.getAttribute('customtext')) == -1){
				//this.setState((prevState, props) => {return {ingredlist: prevState.ingredlist.concat([(
				//<h1 onClick={this.RemoveIngred} key={event.target.getAttribute('customtext')}>{event.target.getAttribute('customtext')}</h1>
				//)])}})

				this.setState((prevState, props) => {return {ingredtextlist: prevState.ingredtextlist.concat([event.target.getAttribute('customtext')])}})
			}
			
			
		}
	}

	 closeMenu(event) {
    
	    if (!this.dropdownMenu.contains(event.target)) {
	      
	      this.setState({ listOpen: false }, () => {
	        document.removeEventListener('click', this.closeMenu);
	      });  
	      
	    }
	}

	render(){
		return(
			<div>
			<form name="addForm" onSubmit={(event) => this.showMenu(event)}>
		        <label>
		          	Name:
		          	<input type="text" onKeyPress={e => {if (e.key === 'Enter') e.preventDefault();}} onChange={(event) => this.showMenu(event)} />
		        </label>
		        
		    </form>

		    
			
			{ 
				this.state.listOpen 
				?(
				<div className="menu" ref={(element) => {
					this.dropdownMenu = element;
				}}>
					<Listing textValue={this.state.textValue} onClicker={this.addIngredient}/>
				</div>
				)
				:(
				null
				)
			}

			<button onClick={this.addIngredient} name="addButton">Pick ingredient</button>
			
			{
				this.state.ingredtextlist.map(ingred => (
					<h1 onClick={this.RemoveIngred} key={ingred} key2={ingred}>{ingred}</h1>
				)
				)
			}

			<Link  href={{ pathname: '/recipelist', query: { ingredlist: this.state.ingredtextlist.toString() } }}>
	        	<button>FIND!</button>
	        </Link>
			
			</div>
			
			

		);
	}
}



const Index = () => (
  <Layout>
  	<Dropdown title="Pick an ingredient"/>
  </Layout>
)

export default Index