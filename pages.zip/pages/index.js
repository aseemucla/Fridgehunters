import Layout from '../components/MyLayout.js'
import Link from 'next/link'


//var mysql = require('mysql');


const Listing = (props) => (
  <div>
      <button>YEET</button>
  </div>

)


/*
const Listing = (props) => (
  <Layout>
      {props.shows.map(({show}) => (
        <li key={show.id}>
          <Link as={`/p/${show.id}`} href={`/post?id=${show.id}`}>
            <a>{show.name}</a>
          </Link>
        </li>
      ))}
  </Layout>
)



Index.getInitialProps = async function() {
  const res = await fetch('https://api.tvmaze.com/search/shows?q=batman')
  const data = await res.json()

  console.log(`Show data fetched. Count: ${data.length}`)

  return {
    shows: data
  }
}

var con = mysql.createConnection({
  host: "localhost",
  user: "yourusername",
  password: "yourpassword"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
});*/


class Dropdown extends React.Component{
	constructor(props){
	  super(props)
	  this.state = {
	    listOpen: false,
	    title: this.props.title
	  }

	  this.showMenu = this.showMenu.bind(this);
	  this.closeMenu = this.closeMenu.bind(this);
	}

	showMenu(){
	  this.setState({
	    listOpen: true
	  },  () => {
      document.addEventListener('click', this.closeMenu);
    })
	}

	 closeMenu(event) {
    
	    if (!this.dropdownMenu.contains(event.target)) {
	      
	      this.setState({ listOpen: false }, () => {
	        document.removeEventListener('click', this.closeMenu);
	      });  
	      
	    }
	}

	render(){
		return(
			<div>
			<button onClick={this.showMenu}>
				{this.state.title}
			</button>
			
			{ 
				this.state.listOpen 
				?(
				<div classname="menu" ref={(element) => {
					this.dropdownMenu = element;
				}}>
					<Listing/>
				</div>
				)
				:(
				null
				)
			}
			</div>
			
			

		);
	}
}



const Index = () => (
  <Layout>
  	<Dropdown title="Pick an ingredient"/>
  </Layout>
)

export default Index