/*import fetch from 'isomorphic-unfetch'


const Listing = (props) => (
  <div>
		  		{props.list.map(({ingred}) => (
		  			<button onClick={props.onClicker}>{ingred}</button>
		  		))}
		  	</div>
)*/

import Layout from '../components/MyLayout.js'
import Link from 'next/link'
import fetch from 'isomorphic-unfetch'

const Listing = (props) => (
  <Layout>
    <h1>Batman TV Shows</h1>
    <ul>
      {props.shows.map(({show}) => (
        <li key={show.id}>
          <Link as={`/p/${show.id}`} href={`/post?id=${show.id}`}>
            <a>{show.name}</a>
          </Link>
        </li>
      ))}
    </ul>
  </Layout>
)

Listing.getInitialProps = async function() {
  /*const res = await fetch('https://apimicroservicefh-yhanjlctbr.now.sh/?desiredMethod=SUGGEST&uname=fish')
  const data = await res.json()

  console.log(`Show data fetched. Count: ${data.length}`)

  return {
    list: data
  }*/

  /*return {
    list: ["fish", "water"]
  }*/

    const res = await fetch('https://api.tvmaze.com/search/shows?q=batman')
  const data = await res.json()

  console.log(`Show data fetched. Count: ${data.length}`)

  return {
    list: data
  }
}

export default Listing