const Listing = (props) => (
  <div>
		  		{props.list.map(({ingred}) => (
		  			<button onClick={props.onClicker}>{ingred}</button>
		  		))}
		  	</div>
)


Listing.getInitialProps = async function() {
  const res = await fetch('https://apimicroservicefh-yhanjlctbr.now.sh/?desiredMethod=SUGGEST&uname=fish')
  const data = await res.json()

  console.log(`Show data fetched. Count: ${data.length}`)

  return {
    list: data
  }
}

export default Listing