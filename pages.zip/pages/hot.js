import { withRouter } from 'next/router'
import Layout from '../components/MyLayout.js'
import fetch from 'isomorphic-unfetch'
import Link from 'next/link'
import urlname from '../components/urlname.js'

class RecipeList extends React.Component{

  constructor(props){
    super(props);
    this.addEndorsement = this.addEndorsement.bind(this);
    this.state = {
      recipes: [],
      endorsedrecipes: []
    }

    fetch(urlname + "/?desiredMethod=HOTALLTIME").then(response => response.text()).then(datas => {
      var data = JSON.parse("[" + datas  + "]")
      //console.log("Show data fetched. Count: " + JSON.stringify(data))
      this.setState({
        recipes: data
      })
    })
  }

  addEndorsement(event){
    var index = this.state.endorsedrecipes.indexOf(event.target.getAttribute('key2'));
    var tempendorselist = this.state.endorsedrecipes.slice().concat([event.target.getAttribute('key2')])

    if(index == -1){
      
      this.setState((prevState, props) => {return {endorsedrecipes: tempendorselist}})
      fetch(urlname + "/?desiredMethod=ENDORSE&uname=" + event.target.getAttribute('key2')).then(response => response.text()).then(data => {
        console.log(data)
        return 1;
      }).then(useless => {fetch(urlname + "/?desiredMethod=FIND&ulist=" + this.state.listtext).then(response => response.text()).then(datas => {
        var data = JSON.parse("[" + datas  + "]")
        console.log("Coming second")
        //console.log("Show data fetched. Count: " + JSON.stringify(data))
        this.setState({
          recipes: data
        })
      })
      })
    }
  }

  render(){
    return (
      <div>

      {
        this.state.recipes.map(recipe => ( <div key={recipe.name}>
          <h1>{recipe.name}</h1>
          <h2>{recipe.ingredients}</h2>
          <h3>{recipe.description}</h3>
          <h4>{recipe.endorse}</h4>
          <button key2={recipe.name} onClick={this.addEndorsement}>{(this.state.endorsedrecipes.indexOf(recipe.name) == -1) ? "Add endorsement!" : "Added endorsement"}</button>
          </div>)
        )
      }
      
      </div>
    )
  }
}

const First =  (props) => (
  <Layout>
    <RecipeList />
  </Layout>
)
export default First