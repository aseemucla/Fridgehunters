import { withRouter } from 'next/router'
import Layout from '../components/MyLayout.js'
import fetchh from 'isomorphic-unfetch'
import Link from 'next/link'
import urlname from '../components/urlname.js'

class Creator extends React.Component{

  constructor(props){
    super(props);
    
  }

  render(){
    return (
      <div>
      
      </div>
    )
  }
}

const First =  (props) => (
  <Layout>
    <Creator/>
  </Layout>
)

export default First