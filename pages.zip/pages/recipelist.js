import { withRouter } from 'next/router'
import Layout from '../components/MyLayout.js'
import fetch from 'isomorphic-unfetch'
import Link from 'next/link'
import urlname from '../components/urlname.js'
import Button from '@material-ui/core/Button';
import Chip from '@material-ui/core/Chip';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Typography from '@material-ui/core/Typography';
import Badge from '@material-ui/core/Badge';

class RecipeList extends React.Component{

  constructor(props){
    super(props);
    this.addEndorsement = this.addEndorsement.bind(this);
    this.removeIngred = this.removeIngred.bind(this);

    var listtext = this.props.listtext;
    var ingredlist = [];
    if(listtext != ""){
      ingredlist = listtext.split(",");
    }
    this.state = {
      listtext: listtext,
      ingredlist: ingredlist,
      recipes: [],
      endorsedrecipes: []
    }

    fetch(urlname + "/?desiredMethod=FIND&ulist=" + this.state.listtext).then(response => response.text()).then(datas => {
      var data = JSON.parse("[" + datas  + "]")
      //console.log("Show data fetched. Count: " + JSON.stringify(data))
      this.setState({
        recipes: data
      })
    })
  }

  addEndorsement(event){
    var index = this.state.endorsedrecipes.indexOf(event.target.getAttribute('key2'));
    var tempendorselist = this.state.endorsedrecipes.slice().concat([event.target.getAttribute('key2')])

    if(index == -1){
      
      this.setState((prevState, props) => {return {endorsedrecipes: tempendorselist}})
      fetch(urlname + "/?desiredMethod=ENDORSE&uname=" + event.target.getAttribute('key2')).then(response => response.text()).then(data => {
        console.log(data)
        return 1;
      }).then(useless => {fetch(urlname + "/?desiredMethod=FIND&ulist=" + this.state.listtext).then(response => response.text()).then(datas => {
        var data = JSON.parse("[" + datas  + "]")
        console.log("Coming second")
        //console.log("Show data fetched. Count: " + JSON.stringify(data))
        this.setState({
          recipes: data
        })
      })
      })
    }
  }

  removeIngred(event){
    var index = this.state.ingredlist.indexOf(event.target.getAttribute('key2'))
    var tempingreds = this.state.ingredlist.slice();
    tempingreds.splice(index, 1);
    var templist = tempingreds.toString();

    this.setState({
      listtext: templist,
      ingredlist: tempingreds
    })

    fetch(urlname + "/?desiredMethod=FIND&ulist=" + templist).then(response => response.text()).then(datas => {
      var data = JSON.parse("[" + datas  + "]")
      //console.log("Show data fetched. Count: " + JSON.stringify(data))
      this.setState({
        recipes: data
      })
    })
  }

  render(){
    return (
      <div align="center"><br/>
      {
        this.state.ingredlist.length == 0
        ? (null) : 
        (this.state.ingredlist.map(ingred => (
          <Button  variant="outlined"  onClick={this.removeIngred} key={ingred} key2={ingred}>{ingred}</Button>
        )))
      }

      <br/><br/>

      {
        this.state.recipes.map(recipe => (<div><Card style={{maxWidth: 345,  backgroundColor: '#66ff99'}} >
          <CardContent>
            <Typography gutterBottom variant="headline" component="h1">
              {recipe.name}
            </Typography>
            <Typography component="p">
              {recipe.ingredients.map(ingred => (
                <Chip label={ingred} />
              ))}
            </Typography>
            <Typography component="p"><br/>
              {recipe.description}
            </Typography>
           
            <Typography component="p"><br/>
              <Badge color="secondary" badgeContent={recipe.endorse}>
              <Button size="small"  variant="contained"  color="primary" key2={recipe.name} onClick={this.addEndorsement}>
                {(this.state.endorsedrecipes.indexOf(recipe.name) == -1) ? "Endorse" : "Added endorsement"}
              </Button>
              </Badge>
            </Typography>
          </CardContent>
          <CardActions>
          </CardActions>
        </Card><br/></div>)
        )
      }
      
      <Link  href={{ pathname: '/create', query: {} }}>
        <Button variant="contained"  color="secondary" ><b>Make your own recipe!</b></Button>
      </Link>
      </div>
    )
  }
}

const First =  (props) => (
  <Layout>
    <RecipeList listtext={props.listtext} />
  </Layout>
)

First.getInitialProps = async function (context) {
  const listtext = context.query.ingredlist
  console.log(listtext)
  return {listtext: listtext}
}

export default First