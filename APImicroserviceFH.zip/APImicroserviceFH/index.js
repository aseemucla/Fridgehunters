const http = require("http");
var mysql = require("mysql2");
var url = require("url");
var Request = require('tedious').Request;
var Connection = require('tedious').Connection;  
var config = {  
    userName: 'aseem',  
    password: 'Secure123',  
    server: 'aseemserver.database.windows.net',  
    // If you are on Microsoft Azure, you need this:  
    options: {encrypt: true, database: 'mydb'}  
};  



module.exports = (req, res) => {

  var parsed = url.parse(req.url, true);
  var desiredMethod = parsed.query.desiredMethod;

  if(req.method == "GET"){
  	var con = new Connection(config);
	con.on('connect', function(error) {
    	if (error) throw error;
    	console.log("Connected!");

    	var sql = "CREATE TABLE recipe (name VARCHAR(255), endorse int, ingredients TEXT)";
    	var request = new Request(sql, function(err) {  
       		if (err) {  
          		console.log(err);
        	}  
      	})

      	request.on('doneInProc', function(rowCount, moore, roows){
	        res.end("Made TABLE");
	    });

	    con.execSql(request);

    })
    	
  }

  else if(req.method == "POST"){
  	
  }



  /*if(Object.keys(parsed.query).length === 0){
    res.end("No queries");
  }*/

  
}
