const http = require("http");
var mysql = require("mysql2");
var url = require("url");
var Request = require('tedious').Request;
var Connection = require('tedious').Connection;  
var config = {  
    userName: 'aseem',  
    password: 'Secure123',  
    server: 'aseemserver.database.windows.net',  
    // If you are on Microsoft Azure, you need this:  
    options: {encrypt: true, database: 'mydb', rowCollectionOnDone: true}  
};  



module.exports = (req, res) => {

  var parsed = url.parse(req.url, true);
  var desiredMethod = parsed.query.desiredMethod;

  if(Object.keys(parsed.query).length === 0){
    res.end("No queries");
  }

  if(req.method == "GET"){

  	if(desiredMethod == "SUGGEST"){
  		var uname = parsed.query.uname;
  		var con = new Connection(config);
  		var overallist = [];
  		var suggested = 0;
  		var checked = 0;
  		var broke = false;

		con.on('connect', function(error) {
	    	if (error) throw error;
	    	console.log("Connected!");

	    	var sql = "SELECT name FROM ingredients ORDER BY recipes DESC";
	    	var request = new Request(sql, function(err) {  
	       		if (err) {  
	          		console.log(err);
	        	}  
	      	})

	    	request.on('row', function(columns){
	    	})

	      	request.on('doneInProc', function(rowCount, more, rows){
	      		for(var i = 0; i < rows.length; i++){
	      			var size = 0;
	    			if(uname.length < rows[i][0].value.length){
	    				size = uname.length;
	    			}
	    			else{
	    				size = rows[i][0].value.length;
	    			}
	    			broke = false;
	    			for(var j = 0; j < size; j++){
	    				if(rows[i][0].value.charAt(j) != uname.charAt(j)){
	    					broke = true;
	    					break;
	    				}
	    			}

	    			if(broke == false && suggested < 5){
	    				overallist.push(rows[i][0].value);
	    				suggested++;
	    			}
	    			checked++;

	    			if(checked == rowCount){
	    				res.end(overallist.toString());
	    			}
	      		}
	      		
		    });

		    con.execSql(request);

  		})
  	}


  	else if(desiredMethod == "FIND"){
  		var ingredlist = parsed.query.ulist.split(",");
  		var namelist = [];
  		var con = new Connection(config);
  		var overallist = [];
  		var suggested = 0;
  		var broke = false;
  		var valid = false;

		con.on('connect', function(error) {
	    	if (error) throw error;
	    	console.log("Connected!");

	    	var sql = "SELECT name, ingredients, description FROM recipe ORDER BY endorse DESC";
	    	var request = new Request(sql, function(err) {  
	       		if (err) {  
	          		console.log(err);
	        	}  
	      	})

	    	request.on('row', function(columns){
	    	})

	      	request.on('doneInProc', function(rowCount, more, rows){
	      		for(var i = 0; i < rows.length; i++){
	      			namelist = rows[i][1].value.split(",");

	    			if(ingredlist.length > namelist.length){
	    				continue;
	    			}

	    			valid = true;
	      			for(var j = 0; j < ingredlist.length; j++){
	      				broke = false;
	      				for(var k = 0; k < namelist.length; k++){
	      					if(namelist[k] == ingredlist[j]){
	      						broke = true;
	      						break;
	      					}
	      				}

	      				if(broke == false){
	      					valid = false;
	      				}
	      			}

	      			if(valid == true){
	      				overallist.push({
	      					name: rows[i][0].value,
	      					ingredients: namelist,
	      					description: rows[i][2].value
	      				})
	      			}
	      		}

	      		res.end(overallist.toString());
	      		
		    });

		    con.execSql(request);

  		})
  	}

  	else if(desiredMethod == "ADDRECIPE"){
  		var uname = parsed.query.uname;
  		var ingredlist = parsed.query.ulist;
  		var udesc = parsed.query.udesc;

  		var con = new Connection(config);

		con.on('connect', function(error) {
	    	if (error) throw error;
	    	console.log("Connected!");

	    	var sql = "INSERT INTO recipe VALUES ('" + uname + "', 0, '" + ingredlist + "', '" + udesc + "', 0) ON DUPLICATE KEY UPDATE endorse = endorse";
	    	var request = new Request(sql, function(err) {  
	       		if (err) {  
	          		console.log(err);
	        	}  
	      	})

	    	request.on('row', function(columns){
	    	})

	      	request.on('doneInProc', function(rowCount, more, rows){
	      		//res.end("Added recipe");
	      		var ulist = ingredlist.split(",");
	      		var valuelist = ""

	      		for(var i = 0; i < ulist.length; i++){
	      			if(i == 0){
	      				valuelist += "(" + ulist[i] + ", 1)"
	      			}
	      			else{
	      				valuelist += ", (" + ulist[i] + ", 1)"
	      			}
	      			
	      		}

      			var con2 = new Connection(config);

	      		con2.on('connect', function(error) {
			    	if (error) throw error;
			    	console.log("Connected!");

			    	var sql = "INSERT INTO ingredients VALUES " + valuelist + "ON DUPLICATE KEY UPDATE recipes = recipes + 1;";
			    	var request2 = new Request(sql, function(err) {  
			       		if (err) {  
			          		console.log(err);
			        	}  
			      	})

			    	request2.on('row', function(columns){
			    	})

			      	request2.on('doneInProc', function(rowCount, more, rows){
			      		res.end("Added recipe");
				    });

				    con2.execSql(request2);

		  		})
	      		

	      		
		    });

		    con.execSql(request);

  		})
  	}


  	else if(desiredMethod == "HOTALLTIME"){
  		var con = new Connection(config);
  		var overallist = [];

		con.on('connect', function(error) {
	    	if (error) throw error;
	    	console.log("Connected!");

	    	var sql = "SELECT name, ingredients, description FROM recipe ORDER BY endorse DESC";
	    	var request = new Request(sql, function(err) {  
	       		if (err) {  
	          		console.log(err);
	        	}  
	      	})

	    	request.on('row', function(columns){
	    	})

	      	request.on('doneInProc', function(rowCount, more, rows){
	      		for(var i = 0; i < rows.length; i++){
	      			namelist = rows[i][1].value.split(",");

	    			if(i > 10){
	    				break;
	    			}

	    			
      				overallist.push({
      					name: rows[i][0].value,
      					ingredients: namelist,
      					description: rows[i][2].value
      				})
	      			
	      		}

	      		res.end(overallist.toString());
	      		
		    });

		    con.execSql(request);

  		})
  	}


  	else if(desiredMethod == "HOTWEEKLY"){
  		var con = new Connection(config);
  		var overallist = [];

		con.on('connect', function(error) {
	    	if (error) throw error;
	    	console.log("Connected!");

	    	var sql = "SELECT name, ingredients, description FROM recipe ORDER BY weeklyendorse DESC";
	    	var request = new Request(sql, function(err) {  
	       		if (err) {  
	          		console.log(err);
	        	}  
	      	})

	    	request.on('row', function(columns){
	    	})

	      	request.on('doneInProc', function(rowCount, more, rows){
	      		for(var i = 0; i < rows.length; i++){
	      			namelist = rows[i][1].value.split(",");

	    			if(i > 10){
	    				break;
	    			}

	    			
      				overallist.push({
      					name: rows[i][0].value,
      					ingredients: namelist,
      					description: rows[i][2].value
      				})
	      			
	      		}

	      		res.end(overallist.toString());
	      		
		    });

		    con.execSql(request);

  		})
  	}


  	else if(desiredMethod == "ENDORSE"){
  		var uname = parsed.query.uname;
  		var con = new Connection(config);

		con.on('connect', function(error) {
	    	if (error) throw error;
	    	console.log("Connected!");

	    	var sql = "UPDATE recipe SET endorse = endorse + 1 WHERE name='" + uname + "'";
	    	var request = new Request(sql, function(err) {  
	       		if (err) {  
	          		console.log(err);
	        	}  
	      	})

	    	request.on('row', function(columns){
	    	})

	      	request.on('doneInProc', function(rowCount, more, rows){

	      		res.end("Added endorsement");
	      		
		    });

		    con.execSql(request);

  		})
  	}


  	else if(desiredMethod == "TEST"){
  		var con = new Connection(config);
  		var overallist = [];

		con.on('connect', function(error) {
	    	if (error) throw error;
	    	console.log("Connected!");

	    	var sql = "SELECT name FROM recipe";
	    	var request = new Request(sql, function(err) {  
	       		if (err) {  
	          		console.log(err);
	        	}  
	      	})

	    	request.on('row', function(columns){
	    	})

	      	request.on('doneInProc', function(rowCount, more, rows){
	      		for(var i = 0; i < rows.length; i++){
	      			

	    			
      				overallist.push(rows[i][0].value);
	      			
	      		}

	      		res.end(overallist.toString());
	      		
		    });

		    con.execSql(request);

  		})
  	}
  	
    	
  }

  else if(req.method == "POST"){

  }



  

  
}
