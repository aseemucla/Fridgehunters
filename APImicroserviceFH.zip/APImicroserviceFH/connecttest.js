var http = require('http');
var bl = require('bl');
const request = require("request")
var props = {desiredMethod: "ADDRECIPE", uname: "Fishing", ulist: "fish,water", udesc: "Fish for fish, then eat."}

request.get({url: "https://apimicroservicefh-ycgysfdoam.now.sh/", qs: props}, function(err, response, body) {
	var str3 = "";
	response.pipe(bl(function (err, dataa) { 
		str3 += dataa.toString();
		console.log(str3);
	}))

	console.log(response)
	response.on("end", function(){
		console.log("YEET")
	})
})